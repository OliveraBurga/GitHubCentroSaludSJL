<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Document</title>
   </head>
   <body>
      <div>
         <style>
         </style>
         <div class="rps_b894">
            <div>
               <table
                  border="0"
                  cellpadding="0"
                  cellspacing="0"
                  width="100%"
                  bgcolor="#ffffff"
                  align="center"
                  style="
                  font-family: Helvetica neue, Helvetica, Arial, Verdana, sans-serif;
                  "
                  >
                  <tbody>
                     <tr>
                        <td rowspan="1" colspan="1">
                           <table
                              width="520px"
                              cellpadding="0"
                              cellspacing="0"
                              border="0"
                              bgcolor="#ffffff"
                              align="center"
                              >
                              <tbody>
                                 <tr>
                                    <td valign="top" rowspan="1" colspan="1">
                                       <table
                                          width="100%"
                                          cellpadding="0"
                                          cellspacing="0"
                                          border="0"
                                          bgcolor="#ffffff"
                                          >
                                          <tbody>
                                             <tr>
                                                <td
                                                   valign="top"
                                                   align="left"
                                                   rowspan="1"
                                                   colspan="1"
                                                   style="
                                                   color: #007be8;
                                                   font-size: 20px;
                                                   line-height: 32px;
                                                   text-align: left;
                                                   font-weight: bold;
                                                   "
                                                   >
                                                   <span
                                                      > ACTIVAR CUENTA</span
                                                      >
                                                </td>
                                             </tr>
                                             <tr>
                                                <td
                                                   valign="top"
                                                   rowspan="1"
                                                   colspan="1"
                                                   style="color: #cccccc; padding-bottom: 15px"
                                                   >
                                                   <hr color="#cccccc" size="1" />
                                                </td>
                                             </tr>
                                             <tr
                                                valign="top"
                                                align="left"
                                                rowspan="1"
                                                colspan="1"
                                                >
                                                <td>
                                                   <div style="padding: 10px 0">
                                                      Hola   <?= $data->nombre; ?>, Te damos las gracias por ponetye en contacto con nosotros prontamente recibiras una llamada de nuesatros ejecutivos para ayudarte
                                                   </div>
                                                </td>
                                             </tr>
                                             <tr
                                                valign="top"
                                                align="left"
                                                rowspan="1"
                                                colspan="1"
                                                >
                                               
                                             </tr>
                                             <tr
                                                valign="top"
                                                align="left"
                                                rowspan="1"
                                                colspan="1"
                                                >
                                                <td>
                                                   
                                                   <div style="padding: 5px 0"></div>
                                                  
                                                   <div style="padding: 5px 0">
                                                      <a
                                                         href="#"
                                                         target="_blank"
                                                         rel="noopener noreferrer"
                                                         data-auth="NotApplicable"
                                                         style="
                                                         padding: 15px;
                                                         background: #007be8;
                                                         color: #ffffff;
                                                         text-align: center;
                                                         text-decoration: none;
                                                         display: inline-block;
                                                         border-radius: 25px;
                                                         "
                                                         data-linkindex="0"
                                                         >CLICK   ACTIVAR CUENTA</a
                                                         >
                                                   </div>
                                                   <div style="padding: 5px 0">
                                                      Descargar Bloshure:
                                                   </div>
                                                   <div
                                                      style="
                                                      margin: 15px 0;
                                                      padding: 10px;
                                                      text-align: center;
                                                      background: #ffffff;
                                                      border: 1px solid #dddddd;
                                                      "
                                                      >
                                                      <a
                                                         href="#"
                                                         target="_blank"
                                                         rel="noopener noreferrer"
                                                         data-auth="NotApplicable"
                                                     
                                                         data-linkindex="1"
                                                         >Descargar</a
                                                         >
                                                   </div>

                                                   <div style="padding: 5px 0">
                                                      Te dejamos un video para saber como funciona:
                                                   </div>

                                                </td>
                                             </tr>
                                             <tr
                                                valign="top"
                                                align="left"
                                                rowspan="1"
                                                colspan="1"
                                                >
                                                <td>
                                                  
                                                </td>
                                             </tr>
                                             <tr>
                                                <td rowspan="1" colspan="1">
                                                   <table
                                                      width="100%"
                                                      cellpadding="0"
                                                      cellspacing="0"
                                                      border="0"
                                                      bgcolor="#ffffff"
                                                      align="center"
                                                      >
                                                      <tbody>
                                                         <tr>
                                                            <td
                                                               valign="top"
                                                               width="100%"
                                                               rowspan="1"
                                                               colspan="1"
                                                               style="color: #cccccc"
                                                               >
                                                               <hr color="#cccccc" size="1" />
                                                            </td>
                                                         </tr>
                                                         <tr>
                                                            <td rowspan="1" colspan="1">
                                                               <div>
                                                                  <table
                                                                     width="100%"
                                                                     cellpadding="0"
                                                                     cellspacing="0"
                                                                     border="0"
                                                                     bgcolor="#ffffff"
                                                                     align="center"
                                                                     >
                                                                     <tbody>
                                                                        <tr>
                                                                           <td
                                                                              valign="top"
                                                                              align="left"
                                                                              rowspan="1"
                                                                              colspan="1"
                                                                              style="
                                                                              padding-top: 10px;
                                                                              color: #707070;
                                                                              font-size: 12px;
                                                                              line-height: 14px;
                                                                              text-align: left;
                                                                              "
                                                                              >
                                                                              <span
                                                                                 style="
                                                                                 width: 100px !important;
                                                                                 "
                                                                                 ><a
                                                                                 href="
                                                                                 target="_blank"
                                                                                 rel="noopener noreferrer"
                                                                                 data-auth="NotApplicable"
                                                                                 data-linkindex="2"
                                                                                 ><img
                                                                                 src="<?= $_ENV['BASE_URL_FRONTEND']; ?>assets/images/logo_login.png"
                                                                                 alt=""
                                                                                 style="width: 100px"></a
                                                                                 ></span>
                                                                              <br clear="none" />
                                                                              <div style="color: #828282">
                                                                                 <b
                                                                                    >Software para transporte de carga pesada y Courier</b
                                                                                    >
                                                                              </div>
                                                                              <div>
                                                                                 <a
                                                                                    href=""
                                                                                    target="_blank"
                                                                                    rel="noopener noreferrer"
                                                                                    data-auth="NotApplicable"
                                                                                    style="color: #828282"
                                                                                    data-linkindex="3"
                                                                                    ></a
                                                                                    >
                                                                              </div>
                                                                              <br clear="none" />
                                                                           </td>
                                                                        </tr>
                                                                     </tbody>
                                                                  </table>
                                                               </div>
                                                            </td>
                                                         </tr>
                                                      </tbody>
                                                   </table>
                                                </td>
                                             </tr>
                                          </tbody>
                                       </table>
                                    </td>
                                 </tr>
                              </tbody>
                           </table>
                        </td>
                     </tr>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </body>
</html>