<?php namespace App\Models\Facturacion_electronica;

use CodeIgniter\Model;
use App\Models\Facturacion_electronica\Nubefact_model;
use App\Models\Facturacion_electronica\Jdm_model;
use App\Models\Facturacion_electronica\Mifact_model;
use App\Models\Configuracion\Empresa_model;

class Emision_model
{
    public function conexion($data)
    {
        $Empresa_m = new Empresa_model();

        $Nubefact_m = new Nubefact_model();
        $Jdm_m = new Jdm_model();
        $Mifact_m = new Mifact_model();

        $this->session = \Config\Services::session();

        $empresa = $Empresa_m->find(ID_EMPRESA);

        if($empresa->tipo_proveedor_electronico == 'NUBEFACT')
        {
            $response = $Nubefact_m->conexion($data);
        }
        else if($empresa->tipo_proveedor_electronico == 'MIFACT')
        {
            if(USUARIO == 'soporte')
            {
                $response = $Mifact_m->conexion($data);
            }
            else
            {
                $response = array(
                    'tipo'      => 'danger',
                    'mensaje'   => 'La emisión por MIFACT aún está en prueba',
                );

                return $response;
            }            
        }
        else if($empresa->tipo_proveedor_electronico == 'JDM')
        {
            $response = array(
                'tipo'      => 'danger',
                'mensaje'   => 'La emisión por JDM aún está en construcción',
            );    
            
            return $response;
        }
        else
        {
            $response = array(
                'tipo'      => 'danger',
                'mensaje'   => 'No se ah configurado el tipo de proveedor electrónico',
            );

            return $response;
        }


        return $response;
    }  
}
