<?php namespace App\Models\Facturacion_electronica;

use CodeIgniter\Model;
use App\Models\Courier\Facturacion_model;
use App\Models\Courier\Facturacion_detalle_model;
use App\Models\Courier\Sucursal_model;

class Jdm_model extends Model
{
    public function conexion($tipo_operacion, $id_facturacion)
    {      
      $Facturacion_m = new Facturacion_model();
      $Facturacion_detalle_m = new Facturacion_detalle_model();

      $comprobante = $Facturacion_m->select('courier_facturacion.*')
      ->select('empresa.ruc as ruc_empresa')
      ->select('courier_cliente.id_documento, courier_cliente.numero_documento as numero_documento_cliente, courier_cliente.razon_social as razon_social_cliente')
      ->join('courier_cliente', 'courier_cliente.id_cliente = courier_facturacion.id_cliente')
      ->join('empresa', 'empresa.id_membresia = courier_facturacion.id_membresia')
      ->where('courier_facturacion.id_facturacion', $id_facturacion)->first();
      
      $detalle_comprobante = $Facturacion_detalle_m->where('id_facturacion', $id_facturacion)->findAll();

      $array_detalle_factura = [];
      
      foreach ($detalle_comprobante as $row) {
        $array_detalle_factura[] = [
          "unidad_de_medida"          => $row->codigo_unidad_medida,
          "codigo"                    => $row->codigo_producto,
          "descripcion"               => $row->descripcion,
          "cantidad"                  => $row->cantidad,
          "valor_unitario"            => $row->valor_unitario,
          "precio_unitario"           => $row->precio_unitario,
          "descuento"                 => "",
          "subtotal"                  => $row->subtotal,
          "tipo_de_igv"               => $row->tipo_igv, // 1 GRAVADA
          "igv"                       => $row->igv,
          "total"                     => $row->total,
          "anticipo_regularizacion"   => "false",
          "anticipo_documento_serie"  => "",
          "anticipo_documento_numero" => ""
        ];
      }

      /** CREDENCIALES NUBEFACT */
      $Sucursal_m = new Sucursal_model();
      $sucursal = $Sucursal_m->select('courier_sucursal.token_nubefact, empresa.url_nubefact, courier_sucursal.correlativo_nubefact, empresa.origen_factura, empresa.formato_factura')
      ->join('empresa', 'empresa.id_empresa = courier_sucursal.id_empresa')
      ->where('courier_sucursal.id_sucursal', $comprobante->id_sucursal)
      ->first();

      /** CABECERA FACTURA */
      $data = array(
          "operacion"				                  => $tipo_operacion,
          "tipo_de_comprobante"               => $comprobante->id_comprobante,
          "serie"                             => $comprobante->serie,
          "numero"				                    => $comprobante->numero,
          "sunat_transaction"			            => "1",
          "cliente_tipo_de_documento"		      => $comprobante->id_documento,
          "cliente_numero_de_documento"	      => $comprobante->numero_documento_cliente,
          "cliente_denominacion"              => $comprobante->razon_social_cliente,
          "cliente_direccion"                 => $comprobante->direccion, /** REGISTRADO AL FACTURAR */
          "cliente_email"                     => $comprobante->email, /** REGISTRADO AL FACTURAR */
          "cliente_email_1"                   => "",
          "cliente_email_2"                   => "",
          "fecha_de_emision"                  => date('d-m-Y'),
          "fecha_de_vencimiento"              => "",
          "moneda"                            => "1",
          "tipo_de_cambio"                    => "",
          "porcentaje_de_igv"                 => "18",
          "descuento_global"                  => "",
          "descuento_global"                  => "",
          "total_descuento"                   => "",
          "total_anticipo"                    => "",
          "total_gravada"                     => $comprobante->total_gravada,
          "total_inafecta"                    => "",
          "total_exonerada"                   => "",
          "total_igv"                         => $comprobante->total_igv,
          "total_gratuita"                    => "",
          "total_otros_cargos"                => "",
          "total"                             => $comprobante->total_importe,
          "percepcion_tipo"                   => "",
          "percepcion_base_imponible"         => "",
          "total_percepcion"                  => "",
          "total_incluido_percepcion"         => "",
          "detraccion"                        => "false",
          "observaciones"                     => '',
          "documento_que_se_modifica_tipo"    => ($comprobante->afectado_id_comprobante != null) ? $comprobante->afectado_id_comprobante : '',
          "documento_que_se_modifica_serie"   => ($comprobante->afectado_serie != null) ? $comprobante->afectado_serie : '',
          "documento_que_se_modifica_numero"  => ($comprobante->afectado_numero != null) ? $comprobante->afectado_numero : '',
          "tipo_de_nota_de_credito"           => ($comprobante->tipo_nota_credito != null) ? $comprobante->tipo_nota_credito : '',
          "tipo_de_nota_de_debito"            => ($comprobante->tipo_nota_debito != null) ? $comprobante->tipo_nota_debito : '',
          "enviar_automaticamente_a_la_sunat" => "true",
          "enviar_automaticamente_al_cliente" => ($comprobante->email != '') ? "true" : "false",
          "codigo_unico"                      => "",
          "condiciones_de_pago"               => $comprobante->condicion_pago,
          "medio_de_pago"                     => "",
          "placa_vehiculo"                    => "",
          "orden_compra_servicio"             => "",
          "tabla_personalizada_codigo"        => "",
          "formato_de_pdf"                    => $sucursal->formato_factura,
          "items"                             => $array_detalle_factura
      );

      $data_comprobante = $data;
      $data_json = json_encode($data);      

      //Invocamos el servicio de NUBEFACT
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $sucursal->url_nubefact);
      curl_setopt(
        $ch, CURLOPT_HTTPHEADER, array(
        'Authorization: Token token="'.$sucursal->token_nubefact.'"',
        'Content-Type: application/json',
        )
      );
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($ch, CURLOPT_POSTFIELDS,$data_json);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      $respuesta  = curl_exec($ch);
      curl_close($ch);
      
      
      $leer_respuesta = json_decode($respuesta, true);
      $data_post = $this->request->getPost();

      /*** MAPEAR ID SERIES */
      if(isset($data_post["id_serie_nota_credito"]))
      {
        $data_post["id_serie"] = $data_post["id_serie_nota_credito"];
      }
      else if(isset($data_post["id_serie_masivo"]))
      {
        $data_post["id_serie"] = $data_post["id_serie_masivo"];
      }

      /*** MAPEAR ID CLIENTE */
      if(isset($data_post["id_cliente_masivo"]))
      {
        $data_post["id_cliente"] = $data_post["id_cliente_masivo"];
      }
      
      if (isset($leer_respuesta["errors"])) {

        $codigo_error = $leer_respuesta["codigo"];

        /** ERROR 23: DOCUMENTO YA EXISTE EN NUBEFACT */
        if($codigo_error == 23 and $tipo_operacion == 'generar_comprobante' and $sucursal->correlativo_nubefact == 1)
        {
          /** INCREMENTAR SECUENCIA **/
          $secuencia = $Facturacion_m->numero_secuencia($data_post["id_serie"]);

          $data_update = [
            'numero'          => strval($secuencia->numero),
            'id_facturacion'  => $comprobante->id_facturacion
          ];

          $Facturacion_m->save($data_update);
          $comprobante->numero_comprobante = $secuencia->numero;
          
          /*** VOLVER A ENVIAR A NUBEFACT */
          return $this->conexion('generar_comprobante', $id_facturacion);
         
        }
        else
        {
          $response = array(
            'tipo'                => 'danger',
            'mensaje'             => $leer_respuesta["errors"],
            'nubefact'            => $leer_respuesta,
            'comprobante_data'    => $data_comprobante,            
          );

          return $response;
        }
      }
      else
      {
        if (isset($leer_respuesta["codigo_hash"])) {

          if(isset($data_post["correo_enviar"]))
          {
            /*** GAURDA EMAIL */
            if (filter_var($data_post["correo_enviar"], FILTER_VALIDATE_EMAIL)) {
              $Email_m = new Email_model();
              
              $email_save = [
                'email'       => $data_post["correo_enviar"],
                'id_cliente'  => $data_post["id_cliente"]
              ];

              $Email_m->save($email_save);
            }
          }
          

          $codigo_unico = $comprobante->ruc_empresa.'-'.$comprobante->id_comprobante.'-'.$comprobante->serie.'-'.$comprobante->numero;

          /** GUARDAR QR */
          require_once APPPATH."/Libraries/phpqrcode/qrlib.php"; 

          $ruta_qr = ROOT_PUBLIC_WRITABLE.'images/qr_'.$codigo_unico.'.png';       
          \QRcode::png($leer_respuesta['cadena_para_codigo_qr'], $ruta_qr, 'Q', 2, 0);
              
          /* ACTUALIZAR ESTADO */
          $data_update = array(
              'codigo_error_sunat'        => $leer_respuesta['sunat_responsecode'],
              'sunat_soap_error'          => $leer_respuesta['sunat_soap_error'],
              'enlace'                    => $leer_respuesta['enlace'],
              'hash'                      => $leer_respuesta['codigo_hash'],
              'codigo_unico'              => $codigo_unico,
              'qr'                        => $leer_respuesta['cadena_para_codigo_qr'],
              'estado'                    => 'ACEPTADO',
              'id_facturacion'            => $comprobante->id_facturacion,                      
          );

          /** MENSAJES SEGÚN CONDICIONES */
          if($comprobante->id_comprobante == 1 or $comprobante->afectado_id_comprobante == 1)
          {
            if($leer_respuesta['aceptada_por_sunat'] == true)
            {
              $mensaje = $leer_respuesta['sunat_description'];
              $data_update["estado_sunat"] = 'ACEPTADO_SUNAT';     
              $tipo_respuesta = 'success';         
            }
            else
            {
              $codigo_error_sunat = intval($leer_respuesta['sunat_responsecode']);
              $mensaje = $leer_respuesta['sunat_soap_error'];
 
              if($codigo_error_sunat >= 2000 and $codigo_error_sunat <= 3999)
              {
                $data_update["estado_sunat"] = 'ANULADO';
                $tipo_respuesta = 'warning';
              }
              else
              {
                $data_update["estado_sunat"] = 'PENDIENTE_SUNAT';
                $tipo_respuesta = 'warning';
              }   
            }     
          }
          else
          {
            $mensaje = 'Comprobante electrónico enviado a Nubefact';

            if($tipo_operacion == 'consultar_comprobante')
            {
              $mensaje = 'Comprobante Aceptado por Nubefact';
            }
              
            $data_update["estado_sunat"] = 'ENVIADO_NUBEFACT';
            $tipo_respuesta = 'success';
          }

          $Facturacion_m->save($data_update);

          /* RESPUESTA */                  
            $response = array(
              'enlace'              => $leer_respuesta['enlace'],
              'nubefact_data'       => $leer_respuesta,
              'comprobante_data'    => $data_comprobante,
              'tipo'                => $tipo_respuesta,
              'estado_sunat'        => $data_update["estado_sunat"],
              'mensaje'             => $mensaje,
              'nubefact'            => true,
              'id_facturacion'      => $comprobante->id_facturacion,
              'origen_factura'      => $sucursal->origen_factura,
              'formato_factura'     => $sucursal->formato_factura
          );

          return $response;
        }
        else
        {
          /** NUBEFACT NO RESPONDE ERROR CONEXIÓN */
          $response = array(
              'tipo'      => 'danger',
              'mensaje'   => 'El servidor de Nubefact no responde, inténtelo nuevamente en un momento',
          );

          return $response;
        }
      }
      
    }
}
