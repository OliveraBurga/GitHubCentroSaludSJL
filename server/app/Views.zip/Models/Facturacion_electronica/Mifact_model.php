<?php namespace App\Models\Facturacion_electronica;

use CodeIgniter\Model;
use App\Models\Facturacion\Factura_model;
use App\Models\Facturacion\Factura_detalle_model;
use App\Models\Configuracion\Empresa_model;

class Mifact_model
{
    public function conexion($data)
    {      
      $tipo_operacion = $data["tipo_operacion"];
      $id_factura = $data["id_factura"];

      $Empresa_m = new Empresa_model();
      $Factura_m = new Factura_model();
      $Factura_detalle_m = new Factura_detalle_model();

      $empresa = $Empresa_m->find(ID_EMPRESA);

      $comprobante = $Factura_m->select('factura.*')
      ->select('static_documento.codigo_sunat as cliente_codigo_sunat_documento')
      ->select('static_comprobante.codigo_sunat as codigo_sunat_comprobante')
      
      ->join('static_documento', 'static_documento.id = factura.cliente_id_documento')
      ->join('static_comprobante', 'static_comprobante.id = factura.id_comprobante')

      ->where('factura.id', $id_factura)
      ->first();


      /** GET TIPO NOTA DE CREDITO */
      if($comprobante->id_tipo_nota_credito != null)
      {
        $nota_credito = $Factura_m->select('static_tipo_nota.codigo_mifact')      
        ->join('static_tipo_nota', 'static_tipo_nota.id = factura.id_tipo_nota_credito')
        ->where('factura.id', $id_factura)
        ->first();

        $comprobante->nota_credito_codigo_mifact = $nota_credito->codigo_mifact;
      }

      /** GET TIPO NOTA DE DEBITO */
      if($comprobante->id_tipo_nota_debito != null)
      {
        $nota_debito = $Factura_m->select('static_tipo_nota.codigo_mifact')      
        ->join('static_tipo_nota', 'static_tipo_nota.id = factura.id_tipo_nota_debito')
        ->where('factura.id', $id_factura)
        ->first();

        $comprobante->nota_debito_codigo_mifact = $nota_debito->codigo_mifact;
      }     

      
      /** GET COMPROBANTE AFECTADO */
      $comprobante_afectado = $Factura_m->select('static_comprobante.codigo_sunat as afectado_codigo_sunat_comprobante')      
      ->join('static_comprobante', 'static_comprobante.id = factura.afectado_id_comprobante')
      ->where('factura.id', $id_factura)
      ->first();


      
      $detalle_comprobante = $Factura_detalle_m->where('id_factura', $id_factura)->findAll();

      $array_detalle_factura = [];
      
      foreach ($detalle_comprobante as $row) {
        $array_detalle_factura[] = [

          "COD_ITEM"                  =>  $row->codigo_producto,
          "COD_UNID_ITEM"             =>  $row->codigo_unidad_medida,
          "CANT_UNID_ITEM"            =>  $row->cantidad,
          "VAL_UNIT_ITEM"             =>  $row->valor_unitario,      
          "PRC_VTA_UNIT_ITEM"         =>  $row->precio_unitario,
          "VAL_VTA_ITEM"              =>  $row->subtotal,
          "MNT_BRUTO"                 =>  $row->subtotal,
          "MNT_PV_ITEM"               =>  $row->importe,
          "COD_TIP_PRC_VTA"           =>  "01", //01 es para la mayoria de casos y 02 es para venta por transferencia gratuita
          "COD_TIP_AFECT_IGV_ITEM"    =>  "10", //valor 10 en caso sea afecto a igv, caso contrario ver el catalogo 07
          "COD_TRIB_IGV_ITEM"         =>  "1000", //codigo de tributo IGV Catalogo 05 SUNAT
          "POR_IGV_ITEM"              =>  $row->porcentaje_igv,
          "MNT_IGV_ITEM"              =>  $row->igv,  
          "TXT_DESC_ITEM"             =>  $row->descripcion
          
        ];
      }


      /** TIPO FORMATO IMPRESION */
      $codigo_impresion = '001';

      if($empresa->formato_factura == 'TICKET')
      {
        $codigo_impresion = '004';
      }
      

      /** CABECERA FACTURA */
      $data = array(
          "TOKEN"                             =>  "gN8zNRBV+/FVxTLwdaZx0w==",
          "COD_TIP_NIF_EMIS"                  =>  "6",
          "NUM_NIF_EMIS"                      =>  $empresa->numero_documento,
          "NOM_RZN_SOC_EMIS"                  =>  $empresa->razon_social,
          "NOM_COMER_EMIS"                    =>  $empresa->nombre_comercial,
          "COD_UBI_EMIS"                      =>  $empresa->id_ubigeo,
          "TXT_DMCL_FISC_EMIS"                =>  $empresa->direccion,

          "COD_TIP_NIF_RECP"                  =>  $comprobante->cliente_codigo_sunat_documento, // CLIENTE
          "NUM_NIF_RECP"                      =>  $comprobante->cliente_numero_documento,
          "NOM_RZN_SOC_RECP"                  =>  $comprobante->cliente_razon_social,
          "TXT_DMCL_FISC_RECEP"               =>  $comprobante->cliente_direccion,
          "FEC_EMIS"                          =>  date('Y-m-d'),
          "FEC_VENCIMIENTO"                   =>  date('Y-m-d'),
          "COD_TIP_CPE"                       =>  $comprobante->codigo_sunat_comprobante,
          "NUM_SERIE_CPE"                     =>  $comprobante->serie,
          "NUM_CORRE_CPE"                     =>  $comprobante->numero,
          "COD_MND"                           =>  "PEN",
          "MailEnvio"                         =>  $comprobante->cliente_email,
          "COD_PRCD_CARGA"                    =>  "001", //procedencia de carga para web service y apis es 001 CORRELATIVO PROPIO | 002 para CORRELATIVO SEGÚN MIFACT
          "MNT_TOT_GRAVADO"                   =>  $comprobante->total_gravada, 
          "MNT_TOT_TRIB_IGV"                  =>  $comprobante->total_igv, 
          "MNT_TOT"                           =>  $comprobante->total_importe, 
          "COD_PTO_VENTA"                     =>  'USUARIO SYSTEM',
          "TXT_DESC_MTVO"                     =>  "Error de Digitación",
          "ENVIAR_A_SUNAT"                    =>  "true",
          "RETORNA_XML_ENVIO"                 =>  "false",
          "RETORNA_XML_CDR"                   =>  "false",
          "RETORNA_PDF"                       =>  "false",
          "COD_FORM_IMPR"                     =>  $codigo_impresion,
          "TXT_VERS_UBL"                      =>  "2.1", //version de UBL SUNAT version 2.1 desde octubre 2018 y 2.0 antes de octubre 2018
          "TXT_VERS_ESTRUCT_UBL"              =>  "2.0", //version de la estructura XML SUNAT version 2.0 para el UBL 2.1 y 1.0 para el UBL 2.0
          "COD_ANEXO_EMIS"                    =>  '0000',
          "COD_TIP_OPE_SUNAT"                 =>  "0101", //codigo de operación de la operación o transaccion, este codigo debera ser según el catalogo 51, ejemplo 0101 es venta interna

          /** NOTA DE CRÉDITO */
          "COD_TIP_NC"                        => ($comprobante->id_tipo_nota_credito != null) ? $comprobante->nota_credito_codigo_mifact : '',         

          "items"                             =>  $array_detalle_factura,

          "docs_referenciado"                 =>  [
                                                    [
                                                      "COD_TIP_DOC_REF"     =>  (is_object($comprobante_afectado)) ? $comprobante_afectado->afectado_codigo_sunat_comprobante : '',
                                                      "NUM_SERIE_CPE_REF"   =>  (is_object($comprobante_afectado)) ? $comprobante->afectado_serie : '',
                                                      "NUM_CORRE_CPE_REF"   =>  (is_object($comprobante_afectado)) ? $comprobante->afectado_numero : '',
                                                      "FEC_DOC_REF"         =>  (is_object($comprobante_afectado)) ? date("Y-m-d", strtotime($comprobante->afectado_fecha)) : '',
                                                    ]
                                                  ],
      );

      $data_comprobante = $data;

      $data_json = json_encode($data);    

      /**** URL DE SERVICIOS */

      if($empresa->estado_facturacion == 'PRODUCCION')
      {
        switch ($tipo_operacion) {
          case 'generar_comprobante':
            $url_service = 'https://demo.mifact.net.pe/api/invoiceService.svc/SendInvoice';
          break;
          
          case 'generar_anulacion':
            $url_service = 'https://demo.mifact.net.pe/api/invoiceService.svc/LowInvoice';
          break;
  
          case 'consultar_comprobante':
            $url_service = 'https://demo.mifact.net.pe/api/invoiceService.svc/GetEstatusInvoice';
          break;
        }
      }
      else
      {
        switch ($tipo_operacion) {
          case 'generar_comprobante':
            $url_service = 'https://demo.mifact.net.pe/api/invoiceService.svc/SendInvoice';
          break;
          
          case 'generar_anulacion':
            $url_service = 'https://demo.mifact.net.pe/api/invoiceService.svc/LowInvoice';
          break;
  
          case 'consultar_comprobante':
            $url_service = 'https://demo.mifact.net.pe/api/invoiceService.svc/GetEstatusInvoice';
          break;
        }
      }      
      
      //Invocamos el servicio 
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $url_service);

      curl_setopt(
        $ch, CURLOPT_HTTPHEADER, array(
        'Authorization: Token token="b4938777-800c-1fb1-b127-aefda436e223"',
        'Content-Type: application/json',
        )
      );

      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $data_json);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      $respuesta  = curl_exec($ch);
      curl_close($ch);

      $leer_respuesta = json_decode($respuesta, true);     
      

      if (isset($leer_respuesta["errors"]) && $leer_respuesta["errors"] != '') {

        $response = array(
          'tipo'                => 'danger',
          'mensaje'             => $leer_respuesta["errors"],
          'proveedor_data'      => $leer_respuesta,
          'comprobante_data'    => $data_comprobante,            
        );

        return $response;
      }
      else
      {
        if (isset($leer_respuesta["codigo_hash"])) {

          $numero_comprobante = $comprobante->serie.'-'.$comprobante->numero;
              
          /* ACTUALIZAR ESTADO */
          $data_update = array(
              'codigo_error_sunat'        => $leer_respuesta['sunat_responsecode'],
              'sunat_soap_error'          => $leer_respuesta['sunat_note'],
              'hash'                      => $leer_respuesta['codigo_hash'],
              'qr'                        => $leer_respuesta['cadena_para_codigo_qr'],
              'id'                        => $comprobante->id,                      
          );

          /*** MANIPULACIÓN SEGÚN ESTADO DE RESPUESTA */
          if($leer_respuesta['estado_documento'] == 101)
          {
             $estado_comprobante = 'PENDIENTE';
             $tipo_respuesta = 'warning';
             $mensaje = 'Comprobante '.$numero_comprobante.' en proceso';
          }
          else if($leer_respuesta['estado_documento'] == 102)
          {
             $estado_comprobante = 'ACEPTADO';
             $tipo_respuesta = 'success';
             $mensaje = 'EL comprobante '.$numero_comprobante.' fue aceptado.';
          }
          else if($leer_respuesta['estado_documento'] == 103)
          {
             $estado_comprobante = 'ACEPTADO';
             $tipo_respuesta = 'success';
             $mensaje = $leer_respuesta['sunat_description'];
          }
          else if($leer_respuesta['estado_documento'] == 104)
          {
             $estado_comprobante = 'RECHAZADO';
             $tipo_respuesta = 'danger';
             $mensaje = 'Comprobante '.$numero_comprobante.' Rechazado';
          }
          else if($leer_respuesta['estado_documento'] == 105)
          {
             $estado_comprobante = 'ANULADO';
             $tipo_respuesta = 'warning';
             $mensaje = 'Comprobante '.$numero_comprobante.' Anulado automáticamente, revisar.';
          }
          else if($leer_respuesta['estado_documento'] == 108)
          {
             $estado_comprobante = 'ANULADO';
             $tipo_respuesta = 'warning';
             $mensaje = 'Comprobante '.$numero_comprobante.' Solicitud de Baja emitido, revisar.';
          }

          $data_update["estado"] = $estado_comprobante;

          $Factura_m->save($data_update);
        

          /* RESPUESTA */                  
            $response = array(
              'enlace'                => null,
              'proveedor_data'        => $leer_respuesta,
              'comprobante_data'      => $data_comprobante,
              'tipo'                  => $tipo_respuesta,
              'estado'                => $data_update["estado"],
              'mensaje'               => $mensaje,
              'proveedor_electronico' => true,
              'id_factura'            => $comprobante->id,
              'origen_factura'        => $empresa->origen_factura,
              'formato_factura'       => $empresa->formato_factura
          );

          return $response;
        }
        else
        {
          /** PROVEEDOR NO RESPONDE ERROR CONEXIÓN */
          $response = array(
              'tipo'      => 'danger',
              'mensaje'   => 'El servidor del Proveedor Electrónico no responde, inténtelo nuevamente en un momento',
          );

          return $response;
        }
      }
      
    }
}
