<?php namespace App\Models\Facturacion_electronica;

use CodeIgniter\Model;
use App\Models\Facturacion\Factura_model;
use App\Models\Facturacion\Factura_detalle_model;
use App\Models\Configuracion\Empresa_model;

class Nubefact_model
{
    public function conexion($data)
    {      
      $tipo_operacion = $data["tipo_operacion"];
      $id_factura = $data["id_factura"];

      $Empresa_m = new Empresa_model();
      $Factura_m = new Factura_model();
      $Factura_detalle_m = new Factura_detalle_model();

      $empresa = $Empresa_m->find(ID_EMPRESA);

      $comprobante = $Factura_m->select('factura.*')
      ->select('static_documento.codigo_sunat as cliente_codigo_sunat_documento')
      ->select('static_comprobante.codigo_nubefact as codigo_nubefact_comprobante')
      
      ->join('static_documento', 'static_documento.id = factura.cliente_id_documento')
      ->join('static_comprobante', 'static_comprobante.id = factura.id_comprobante')

      ->where('factura.id', $id_factura)
      ->first();

      /** GET TIPO NOTA DE CREDITO */
      if($comprobante->id_tipo_nota_credito != null)
      {
        $nota_credito = $Factura_m->select('static_tipo_nota.codigo_nubefact')      
        ->join('static_tipo_nota', 'static_tipo_nota.id = factura.id_tipo_nota_credito')
        ->where('factura.id', $id_factura)
        ->first();

        $comprobante->nota_credito_codigo_nubefact = $nota_credito->codigo_nubefact;
      }

      /** GET TIPO NOTA DE DEBITO */
      if($comprobante->id_tipo_nota_debito != null)
      {
        $nota_debito = $Factura_m->select('static_tipo_nota.codigo_nubefact')      
        ->join('static_tipo_nota', 'static_tipo_nota.id = factura.id_tipo_nota_debito')
        ->where('factura.id', $id_factura)
        ->first();

        $comprobante->nota_debito_codigo_nubefact = $nota_debito->codigo_nubefact;
      }     

      
      /** GET COMPROBANTE AFECTADO */
      $comprobante_afectado = $Factura_m->select('static_comprobante.codigo_nubefact as afectado_codigo_nubefact_comprobante')      
      ->join('static_comprobante', 'static_comprobante.id = factura.afectado_id_comprobante')
      ->where('factura.id', $id_factura)
      ->first();
      
      $detalle_comprobante = $Factura_detalle_m->where('id_factura', $id_factura)->findAll();

      $array_detalle_factura = [];
      
      foreach ($detalle_comprobante as $row) {
        $array_detalle_factura[] = [
          "unidad_de_medida"          => $row->codigo_unidad_medida,
          "codigo"                    => $row->codigo_producto,
          "descripcion"               => $row->descripcion,
          "cantidad"                  => $row->cantidad,
          "valor_unitario"            => $row->valor_unitario,
          "precio_unitario"           => $row->precio_unitario,
          "descuento"                 => "",
          "subtotal"                  => $row->subtotal,
          "tipo_de_igv"               => $row->tipo_igv, // 1 GRAVADA
          "igv"                       => $row->igv,
          "total"                     => $row->importe,
          "anticipo_regularizacion"   => "false",
          "anticipo_documento_serie"  => "",
          "anticipo_documento_numero" => ""
        ];
      }

      /** CABECERA FACTURA */
      $data = array(
          "operacion"				                  => $tipo_operacion,
          "tipo_de_comprobante"               => $comprobante->codigo_nubefact_comprobante,
          "serie"                             => $comprobante->serie,
          "numero"				                    => $comprobante->numero,
          "sunat_transaction"			            => "1",
          "cliente_tipo_de_documento"		      => $comprobante->cliente_codigo_sunat_documento,
          "cliente_numero_de_documento"	      => $comprobante->cliente_numero_documento,
          "cliente_denominacion"              => $comprobante->cliente_razon_social,
          "cliente_direccion"                 => $comprobante->cliente_direccion, /** REGISTRADO AL FACTURAR */
          "cliente_email"                     => $comprobante->cliente_email, /** REGISTRADO AL FACTURAR */
          "cliente_email_1"                   => "",
          "cliente_email_2"                   => "",
          "fecha_de_emision"                  => date('d-m-Y'),
          "fecha_de_vencimiento"              => "",
          "moneda"                            => $comprobante->id_moneda,
          "tipo_de_cambio"                    => $comprobante->tipo_cambio,
          "porcentaje_de_igv"                 => "18",
          "descuento_global"                  => "",
          "total_descuento"                   => "",
          "total_anticipo"                    => "",
          "total_gravada"                     => $comprobante->total_gravada,
          "total_inafecta"                    => "",
          "total_exonerada"                   => "",
          "total_igv"                         => $comprobante->total_igv,
          "total_gratuita"                    => "",
          "total_otros_cargos"                => "",
          "total"                             => $comprobante->total_importe,
          "percepcion_tipo"                   => "",
          "percepcion_base_imponible"         => "",
          "total_percepcion"                  => "",
          "total_incluido_percepcion"         => "",
          "detraccion"                        => ($comprobante->fl_detraccion == 1) ? "true" : "false",
          "observaciones"                     => '',
          "documento_que_se_modifica_tipo"    => ($comprobante->afectado_id_comprobante != null) ? $comprobante_afectado->afectado_codigo_nubefact_comprobante : '',
          "documento_que_se_modifica_serie"   => ($comprobante->afectado_serie != null) ? $comprobante->afectado_serie : '',
          "documento_que_se_modifica_numero"  => ($comprobante->afectado_numero != null) ? $comprobante->afectado_numero : '',
          "tipo_de_nota_de_credito"           => ($comprobante->id_tipo_nota_credito != null) ? $comprobante->nota_credito_codigo_nubefact : '',
          "tipo_de_nota_de_debito"            => ($comprobante->id_tipo_nota_debito != null) ? $comprobante->nota_debito_codigo_nubefact : '',
          "enviar_automaticamente_a_la_sunat" => "true",
          "enviar_automaticamente_al_cliente" => ($comprobante->cliente_email != '') ? "true" : "false",
          "codigo_unico"                      => "",
          "condiciones_de_pago"               => $comprobante->condicion_pago,
          "medio_de_pago"                     => "",
          "placa_vehiculo"                    => "",
          "orden_compra_servicio"             => "",
          "tabla_personalizada_codigo"        => "",
          "formato_de_pdf"                    => $empresa->formato_factura,
          "items"                             => $array_detalle_factura,
          "motivo"                            => $comprobante->motivo_anulacion
      );

      $data_comprobante = $data;
      $data_json = json_encode($data);      
      
      //Invocamos el servicio de NUBEFACT
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $empresa->url_proveedor_electronico);
      curl_setopt(
        $ch, CURLOPT_HTTPHEADER, array(
        'Authorization: Token token="'.$empresa->token_proveedor_electronico.'"',
        'Content-Type: application/json',
        )
      );

      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($ch, CURLOPT_POSTFIELDS,$data_json);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      $respuesta  = curl_exec($ch);
      curl_close($ch);
      
      $leer_respuesta = json_decode($respuesta, true);
      
      if (isset($leer_respuesta["errors"])) {

        $response = array(
          'tipo'                => 'danger',
          'mensaje'             => $leer_respuesta["errors"],
          'proveedor_data'      => $leer_respuesta,
          'comprobante_data'    => $data_comprobante,            
        );

        $codigo_error = $leer_respuesta["codigo"];

        if($codigo_error == 23)
        {
          $response['mensaje'] = 'El comprobante '.$comprobante->serie.'-'.$comprobante->numero.' ya existe, solicite al administrador verifique el último correlativo en la cuenta del proveedor electrónico y cambie el inicio del correlativo en este sistema. Le recordamos que no debe usar la serie registrado en este sistema, para usos en otras plataformas.';
        }

        return $response;

      }
      else
      {
          
        if (isset($leer_respuesta["enlace"])) {                        

          /* ACTUALIZAR ESTADO */
          $data_update = array(
              'codigo_error_sunat'        => $leer_respuesta['sunat_responsecode'],
              'sunat_soap_error'          => $leer_respuesta['sunat_soap_error'],
              'enlace'                    => $leer_respuesta['enlace'],
              'id'                        => $comprobante->id,                      
          );         
          
          if(isset($leer_respuesta['codigo_hash']))
          {
            $data_update["hash"] = $leer_respuesta['codigo_hash'];
          }

          if(isset($leer_respuesta['cadena_para_codigo_qr']))
          {
            $data_update["qr"] = $leer_respuesta['cadena_para_codigo_qr'];
          }
          

          /** MENSAJES SEGÚN CONDICIONES */
          if($tipo_operacion == 'generar_anulacion')
          {
            $mensaje = 'Comprobante anulado en Nubefact';
            $data_update["estado"] = 'ANULADO';
            $tipo_respuesta = 'success';
            $data_update["fl_anulado"] = 1;
          }
          else if($tipo_operacion == 'consultar_anulacion')
          {
            

            $mensaje = 'Comprobante electrónico enviado a Nubefact';

            $mensaje = ($leer_respuesta['sunat_description'] != null) ? $leer_respuesta['sunat_description'] : $mensaje;

            $tipo_respuesta = 'success';

            $data_update["estado"] = 'ANULADO';
           
          }
          else if($comprobante->codigo_nubefact_comprobante == 1 or (is_object($comprobante_afectado) && $comprobante_afectado->afectado_codigo_nubefact_comprobante == 1))
          {
            if($leer_respuesta['aceptada_por_sunat'] == true)
            {
              $mensaje = $leer_respuesta['sunat_description'];
              $data_update["estado"] = 'ACEPTADO';     
              $tipo_respuesta = 'success';         
            }
            else
            {
              $codigo_error_sunat = intval($leer_respuesta['sunat_responsecode']);
              $mensaje = $leer_respuesta['sunat_soap_error'];
              
              if(is_numeric($codigo_error_sunat))
              {
                if(intval($codigo_error_sunat) >= 2000 and intval($codigo_error_sunat) <= 3999)
                {
                  $data_update["estado"] = 'ANULADO';
                  $tipo_respuesta = 'warning';
                  $data_update["fl_anulado"] = 1;
                }
                else
                {
                  $data_update["estado"] = 'PENDIENTE';
                  $tipo_respuesta = 'warning';
                } 
              }
              else
              {
                if($leer_respuesta['anulado'] == true)
                {
                  $data_update["estado"] = 'ANULADO';
                  $data_update["fl_anulado"] = 1;
                  $tipo_respuesta = 'warning';
                }
                else
                {
                  $data_update["estado"] = 'PENDIENTE';
                  $tipo_respuesta = 'warning';
                }
              }
            }     
          }
          else
          {
            $mensaje = 'Comprobante electrónico enviado a Nubefact';

            if($tipo_operacion == 'consultar_comprobante')
            {
              $mensaje = 'Comprobante Aceptado por Proveedor Electrónico';
            }

            $mensaje = ($leer_respuesta['sunat_description'] != null) ? $leer_respuesta['sunat_description'] : $mensaje;
              
            $data_update["estado"] = 'ENVIADO_PROVEEDOR';
            $tipo_respuesta = 'success';
          }

          $Factura_m->save($data_update);
          
        
          /* RESPUESTA */                  
            $response = array(
              'enlace'                => $leer_respuesta['enlace'],
              'proveedor_data'        => $leer_respuesta,
              'comprobante_data'      => $data_comprobante,
              'tipo'                  => $tipo_respuesta,
              'estado'                => $data_update["estado"],
              'mensaje'               => $mensaje,
              'proveedor_electronico' => true,
              'id_factura'            => $comprobante->id,
              'origen_factura'        => $empresa->origen_factura,
              'formato_factura'       => $empresa->formato_factura
          );

          return $response;
        }
        else
        {
          /** NUBEFACT NO RESPONDE ERROR CONEXIÓN */
          $response = array(
              'tipo'                => 'danger',
              'mensaje'             => 'El servidor del Proveedor Electrónico no responde, inténtelo nuevamente en un momento',
              'comprobante_data'    => $data_comprobante,
              'proveedor_data'      => $leer_respuesta,
          );

          return $response;
        }
        
      }
      
    }
}
