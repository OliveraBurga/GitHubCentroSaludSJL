<?php namespace App\Models\Documento;

use CodeIgniter\Model;

class Documento_vehiculo_model extends Model
{
  protected $table      = 'documento_vehiculo';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_vehiculo', 
    'id_tipo_documento', 
    'documento', 
    'fecha_emision', 
    'fecha_vencimiento', 
    'archivo', 
    'id_empresa',
    'costo'
  ];
}
