<?php namespace App\Models\Operacion;

use CodeIgniter\Model;

class Proforma_detalle_model extends Model
{
  protected $table      = 'proforma_detalle';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_proforma',
    'codigo_producto',
    'cantidad',
    'descripcion',
    'valor_unitario',
    'precio_unitario',
    'subtotal',
    'tipo_igv',
    'igv',
    'importe',
    'porcentaje_igv',
  ];

}
