<?php namespace App\Models\Operacion;

use CodeIgniter\Model;

class Mantenimiento_vehiculo_model extends Model
{
  protected $table      = 'mantenimiento_vehiculo';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_vehiculo',
    'fecha',
    'fecha_sistema',
    'tipo',
    'numero_documento',
    'id_proveedor',
    'descripcion',
    'kilometraje',
    'costo',
    'mantenimiento',
    'id_empresa',
    'id_moneda',
    'tipo_cambio',
    'tipo_pago',
    'fl_caja',
    'fl_pagado',
    'id_usuario',
    'id_caja',
    'dias_credito'
  ];

}
