<?php namespace App\Models\Operacion;

use CodeIgniter\Model;

class Vale_combustible_model extends Model
{
  protected $table      = 'vale_combustible';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'serie',
    'numero',
    'fecha',
    'id_viaje',
    'id_vehiculo',
    'id_conductor',
    'id_proveedor',
    'estacion',
    'numero_comprobante',
    'numero_ticket',
    'tipo',
    'tipo_pago',
    'kilometraje',
    'peso',
    'galones',
    'costo_galon',
    'observacion',
    'id_empresa',
    'importe',
    'id_moneda',
    'fl_estado',
    'tipo_cambio',
    'fl_caja',
    'id_usuario',
    'fl_pagado',
    'id_caja',
    'dias_credito'
  ];

  public function get_correlativo($serie)
  {
    $Vale_combustible_m = new Vale_combustible_model();

    $response = $Vale_combustible_m->select('COALESCE(MAX(CAST(numero AS UNSIGNED)), 0) as numero')
    ->where('serie', $serie)
    ->where('id_empresa', ID_EMPRESA)
    ->first();

    $response->serie = $serie;
    $response->numero = str_pad(($response->numero + 1),  8, "0", STR_PAD_LEFT);

    return $response;
  }

}
