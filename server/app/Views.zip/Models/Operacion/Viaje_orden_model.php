<?php namespace App\Models\Operacion;

use CodeIgniter\Model;

class Viaje_orden_model extends Model
{
  protected $table      = 'viaje_orden';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_viaje',
    'id_orden' ,
    'id_vehiculo_compartimiento'
  ];

}
