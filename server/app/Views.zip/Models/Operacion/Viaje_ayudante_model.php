<?php namespace App\Models\Operacion;

use CodeIgniter\Model;

class Viaje_ayudante_model extends Model
{
  protected $table      = 'viaje_ayudante';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'nombre',
    'id_viaje',
    'id_orden',
    'tipo'
  ];

}
