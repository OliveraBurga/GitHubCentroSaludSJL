<?php namespace App\Models\Operacion;

use CodeIgniter\Model;

class Viaje_guia_model extends Model
{
  protected $table      = 'viaje_guia';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'tipo',
    'serie',
    'numero',
    'punto_origen',
    'punto_destino',
    'id_viaje',
    'fl_estado',
    'id_orden'
  ];

}
