<?php namespace App\Models\Operacion;

use CodeIgniter\Model;

class Viaje_escolta_model extends Model
{
  protected $table      = 'viaje_escolta';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'vehiculo',
    'descripcion' ,
    'id_viaje'
  ];

}
