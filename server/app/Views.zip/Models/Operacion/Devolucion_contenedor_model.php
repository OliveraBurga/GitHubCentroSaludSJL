<?php namespace App\Models\Operacion;

use CodeIgniter\Model;

class Devolucion_contenedor_model extends Model
{
  protected $table      = 'devolucion_contenedor';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'fecha',
    'numero_contenedor' ,
    'id_viaje',
    'estado',
    'comentario',
    'id_empresa'
  ];

}
