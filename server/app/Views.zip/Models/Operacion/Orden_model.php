<?php namespace App\Models\Operacion;

use CodeIgniter\Model;

class Orden_model extends Model
{
  protected $table      = 'orden';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'fecha',
    'serie',
    'numero',
    'id_moneda',
    'id_cliente',
    'id_subcliente',
    'id_ruta',
    'id_tarifa',
    'orden_servicio',
    'costo_medida',
    'cantidad_medida',
    'total_orden',
    'fl_estado',
    'id_factura',
    'fl_liquidacion',
    'numero_contenedor',
    'id_empresa',
    'fecha_sistema',
    'id_viaje',
    'fl_pagado',
    'direccion_llegada',
    'producto',
    'id_usuario',
    'id_local',
    'referencia_carga_cliente',
    'id_cliente_contacto',
    'tipo_cambio'
  ];

  public function get_correlativo($serie)
  {
    $Orden_m = new Orden_model();

    $response = $Orden_m->select('COALESCE(MAX(CAST(numero AS UNSIGNED)), 0) as numero')
    ->where('serie', $serie)
    ->where('id_empresa', ID_EMPRESA)
    ->first();

    $response->serie = $serie;
    $response->numero = str_pad(($response->numero + 1),  8, "0", STR_PAD_LEFT);

    return $response;
  }
}
