<?php namespace App\Models\Operacion;

use CodeIgniter\Model;

class Viaje_monitoreo_model extends Model
{
  protected $table      = 'viaje_monitoreo';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_viaje',
    'id_estado_monitoreo',
    'fecha',
    'fecha_sistema',
    'id_usuario',
    'comentario',
    'latitud',
    'longitud',
    'foto',
    'fl_mapa',
    'fl_email_enviado'
  ];

}
