<?php namespace App\Models\Operacion;

use CodeIgniter\Model;

class Inventario_entrega_vehiculo_detalle_model extends Model
{
  protected $table      = 'inventario_entrega_vehiculo_detalle';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_inventario_entrega_vehiculo',
    'descripcion',
    'estado',
    'observacion',
    'cantidad',
    'valor'
  ];
}
