<?php namespace App\Models\Operacion;

use CodeIgniter\Model;

class Control_llanta_model extends Model
{
  protected $table      = 'control_llanta';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_vehiculo_llanta',
    'kilometraje',
    'condicion',
    'presion',
    'observacion',
    'fecha',
    'fecha_sistema',
    'id_empresa'
  ];

}
