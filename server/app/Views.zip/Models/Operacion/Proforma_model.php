<?php namespace App\Models\Operacion;

use CodeIgniter\Model;
use App\Models\Configuracion\Serie_model;

class Proforma_model extends Model
{
  protected $table      = 'proforma';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'fecha',
    'id_comprobante',
    'serie',
    'numero',
    'id_usuario',
    'id_empresa',
    'nombre_contacto',
    'direccion',
    'telefono',
    'email',
    'fl_estado',
    'total_gravada',
    'total_igv',
    'total_importe',
    'condicion_pago',
    'id_moneda',
    'fecha_sistema',
    'dias_pagar',
    'fl_detraccion',
    'porcentaje_detraccion',
    'empresa',
    'medida',
    'salida',
    'llegada',
    'dias_oferta',
    'observacion'
  ];

  public function get_correlativo($id_comprobante, $serie)
  {
    $Proforma_m = new Proforma_model();
    $Serie_m = new Serie_model();

    /** GET SERIE DE CONFIGURACION */
    $correlativo = $Serie_m->where('id_comprobante', $id_comprobante)
    ->where('serie', $serie)
    ->where('tipo', 'PROFORMA')
    ->first();

    /** VERIFICAR SI SERIE INICIAL YA FUE CREADA */
    $existe = $Proforma_m->where('serie', $serie)
    ->where('id_comprobante', $id_comprobante)
    ->where('CAST(numero AS UNSIGNED)', $correlativo->numero)
    ->first();

    if(is_object($existe))
    {
      $numero_inicial = $correlativo->numero - 1;

      $response = $Proforma_m->select('COALESCE(MAX(CAST(numero AS UNSIGNED)), '.$numero_inicial.') as numero')
      ->where('serie', $serie)
      ->where('id_empresa', ID_EMPRESA)
      ->first();

      $response->serie = $serie;
      $response->numero = str_pad(($response->numero + 1),  8, "0", STR_PAD_LEFT);
    }
    else
    {
      $response = new \stdClass();
      
      $response->serie = $correlativo->serie;
      $response->numero = str_pad($correlativo->numero,  8, "0", STR_PAD_LEFT);
    }
   
    return $response;
  }

}
