<?php namespace App\Models\Operacion;

use CodeIgniter\Model;

class Vale_pago_model extends Model
{
  protected $table      = 'vale_pago';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'serie',
    'numero',
    'fecha',
    'id_viaje',
    'id_vehiculo',
    'id_proveedor',
    'numero_comprobante',
    'numero_ticket',
    'tipo_pago',
    'observacion',
    'id_empresa',
    'importe',
    'id_moneda',
    'fl_estado',
    'tipo_cambio',
    'fl_caja',
    'motivo',
    'descripcion',
    'id_usuario',
    'fl_pagado',
    'id_caja',
    'dias_credito',
    'porcentaje_detraccion'
  ];

  public function get_correlativo($serie)
  {
    $Vale_pago_m = new Vale_pago_model();

    $response = $Vale_pago_m->select('COALESCE(MAX(CAST(numero AS UNSIGNED)), 0) as numero')
    ->where('serie', $serie)
    ->where('id_empresa', ID_EMPRESA)
    ->first();

    $response->serie = $serie;
    $response->numero = str_pad(($response->numero + 1),  8, "0", STR_PAD_LEFT);

    return $response;
  }

}
