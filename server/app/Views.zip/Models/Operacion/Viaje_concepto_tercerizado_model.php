<?php namespace App\Models\Operacion;

use CodeIgniter\Model;

class Viaje_concepto_tercerizado_model extends Model
{
  protected $table      = 'viaje_concepto_tercerizado';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'concepto',
    'monto',
    'id_viaje'
  ];

}
