<?php namespace App\Models\Operacion;

use CodeIgniter\Model;

class Inventario_entrega_vehiculo_model extends Model
{
  protected $table      = 'inventario_entrega_vehiculo';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'fecha',
    'fecha_sistema',
    'serie' ,
    'numero',
    'id_vehiculo',
    'id_remolque',
    'id_conductor',
    'descripcion',
    'id_empresa',
    'fl_estado'
  ];

  public function get_correlativo($serie)
  {
    $Inventario_entrega_vehiculo_m = new Inventario_entrega_vehiculo_model();

    $response = $Inventario_entrega_vehiculo_m->select('COALESCE(MAX(CAST(numero AS UNSIGNED)), 0) as numero')
    ->where('serie', $serie)
    ->where('id_empresa', ID_EMPRESA)
    ->first();

    $response->serie = $serie;
    $response->numero = str_pad(($response->numero + 1),  8, "0", STR_PAD_LEFT);

    return $response;
  }
}
