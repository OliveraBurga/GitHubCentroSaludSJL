<?php namespace App\Models\Operacion;

use CodeIgniter\Model;

class Gasto_operativo_model extends Model
{
  protected $table      = 'gasto_operativo';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_viaje',
    'fecha' ,
    'id_tipo_gasto_operativo',
    'detalle',
    'importe',
    'id_usuario',
    'archivo',
    'id_empresa',
    'numero_documento',
    'id_moneda',
    'fl_comprobante_fiscal',
    'detalle_comprobante_fiscal',
    'id_proveedor',
    'tipo_pago',
    'dias_pago',
    'tipo_cambio'
  ];

}
