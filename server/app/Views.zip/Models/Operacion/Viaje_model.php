<?php namespace App\Models\Operacion;

use CodeIgniter\Model;

class Viaje_model extends Model
{
  protected $table      = 'viaje';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'fecha',
    'serie' ,
    'numero',
    'id_vehiculo',
    'id_remolque',
    'id_conductor',
    'pago_conductor',
    'distancia',
    'modalidad',
    'cantidad',
    'tipo_carga',
    'numero_contenedor',
    'fl_estado',
    'fecha_sistema',
    'costo_tercerizado',
    'monto_gasto_operativo',
    'descripcion_gasto_operativo',
    'id_empresa',
    'accion_saldo_gasto_operativo',
    'id_ruta',
    'fecha_inicio',
    'km_inicio',
    'fecha_retorno',
    'km_retorno',
    'fecha_fin',
    'km_fin',
    'estado_operacion',
    'comentario',
    'id_liquidacion_gasto_operativo',
    'id_liquidacion_tercero',
    'km_gps',
    'monto_adelanto_tercerizado',
    'id_usuario',
    'fl_requerimiento_adelanto_tercerizado',
    'fl_requerimiento_flete_tercerizado',
    'costo_flete_tercerizado',
    'porc_detraccion_tercerizado',
    'mas_inc_igv_tercerizado',
    'id_moneda_tercerizado',
    'serie_factura_tercero',
    'numero_factura_tercero',
    'tipo_cambio_tercerizado',

    'id_proveedor_escolta',
    'costo_escolta',
    'monto_adelanto_escolta',
    'id_moneda_escolta',
    'tipo_cambio_escolta',
    'fl_requerimiento_escolta',
    'fl_requerimiento_adelanto_escolta',
    'id_liquidacion_escolta',
    'porc_detraccion_escolta',
    'mas_inc_igv_escolta',
    'serie_factura_escolta',
    'numero_factura_escolta'

  ];

  public function get_correlativo($serie)
  {
    $Viaje_m = new Viaje_model();

    $response = $Viaje_m->select('COALESCE(MAX(CAST(numero AS UNSIGNED)), 0) as numero')
    ->where('serie', $serie)
    ->where('id_empresa', ID_EMPRESA)
    ->first();

    $response->serie = $serie;
    $response->numero = str_pad(($response->numero + 1),  8, "0", STR_PAD_LEFT);

    return $response;
  }
}
