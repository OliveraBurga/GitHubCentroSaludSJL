<?php namespace App\Models\Facturacion;

use CodeIgniter\Model;

class Factura_orden_model extends Model
{
  protected $table      = 'factura_orden';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_factura',
    'id_orden',
  ];


}
