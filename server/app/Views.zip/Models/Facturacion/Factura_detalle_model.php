<?php namespace App\Models\Facturacion;

use CodeIgniter\Model;

class Factura_detalle_model extends Model
{
  protected $table      = 'factura_detalle';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_factura',
    'codigo_unidad_medida',
    'codigo_producto',
    'cantidad',
    'descripcion',
    'valor_unitario',
    'precio_unitario',
    'subtotal',
    'tipo_igv',
    'igv',
    'importe',
    'porcentaje_igv',
    'id_orden'
  ];

}
