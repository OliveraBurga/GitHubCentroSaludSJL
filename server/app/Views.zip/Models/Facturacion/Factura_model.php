<?php namespace App\Models\Facturacion;

use CodeIgniter\Model;
use App\Models\Configuracion\Serie_model;

class Factura_model extends Model
{
  protected $table      = 'factura';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'fecha',
    'id_comprobante',
    'serie',
    'numero',
    'id_usuario',
    'id_empresa',
    'id_cliente',
    'estado',
    'total_gravada',
    'total_igv',
    'total_importe',
    'afectado_id_factura',
    'afectado_id_comprobante',
    'afectado_serie',
    'afectado_numero',
    'afectado_fecha',
    'id_tipo_nota_credito',
    'id_tipo_nota_debito',
    'enlace',
    'hash',
    'codigo_unico',
    'qr',
    'descripcion_motivo',
    'comentario',
    'cliente_id_documento',
    'cliente_numero_documento',
    'cliente_razon_social',
    'cliente_direccion',
    'cliente_ubigeo',
    'cliente_email',
    'codigo_error_sunat',
    'sunat_soap_error',
    'condicion_pago',
    'id_moneda',
    'fecha_sistema',
    'motivo_anulacion',
    'fl_anulado',
    'dias_pagar',
    'fl_detraccion',
    'porcentaje_detraccion',
    'id_orden',
    'tipo_cambio',
    'total_detraccion',
    'fl_masivo'
  ];

  public function get_correlativo($id_comprobante, $serie)
  {
    $Factura_m = new Factura_model();
    $Serie_m = new Serie_model();

    /** GET SERIE DE CONFIGURACION */
    $correlativo = $Serie_m->where('id_comprobante', $id_comprobante)
    ->where('serie', $serie)
    ->where('tipo', 'FACTURACION')
    ->first();

    /** VERIFICAR SI SERIE INICIAL YA FUE FACTURADA */
    $existe = $Factura_m->where('serie', $serie)
    ->where('id_comprobante', $id_comprobante)
    ->where('CAST(numero AS UNSIGNED)', $correlativo->numero)
    ->first();

    if(is_object($existe))
    {
      $numero_inicial = $correlativo->numero - 1;

      $response = $Factura_m->select('COALESCE(MAX(CAST(numero AS UNSIGNED)), '.$numero_inicial.') as numero')
      ->where('serie', $serie)
      ->where('id_empresa', ID_EMPRESA)
	  ->where('id_comprobante', $id_comprobante)
      ->first();

      $response->serie = $serie;
      $response->numero = str_pad(($response->numero + 1),  8, "0", STR_PAD_LEFT);
    }
    else
    {
      $response = new \stdClass();
      
      $response->serie = $correlativo->serie;
      $response->numero = str_pad($correlativo->numero,  8, "0", STR_PAD_LEFT);
    }
   
    return $response;
  }

}
