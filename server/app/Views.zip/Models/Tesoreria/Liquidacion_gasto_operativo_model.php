<?php namespace App\Models\Tesoreria;

use CodeIgniter\Model;

class Liquidacion_gasto_operativo_model extends Model
{
  protected $table      = 'liquidacion_gasto_operativo';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'fecha',
    'serie',
    'numero',
    'fecha_sistema',
    'id_viaje',
    'id_conductor',
    'total_desembolso',
    'total_gasto',
    'total_reembolso',
    'total_saldo',
    'fl_estado',
    'id_empresa',
    'tipo_accion',
    'observacion',
    'fl_tipo_accion'
  ];

  public function get_correlativo($serie)
  {
    $Liquidacion_gasto_operativo_m = new Liquidacion_gasto_operativo_model();

    $response = $Liquidacion_gasto_operativo_m->select('COALESCE(MAX(CAST(numero AS UNSIGNED)), 0) as numero')
    ->where('serie', $serie)
    ->where('id_empresa', ID_EMPRESA)
    ->first();

    $response->serie = $serie;
    $response->numero = str_pad(($response->numero + 1),  8, "0", STR_PAD_LEFT);

    return $response;
  }

}
