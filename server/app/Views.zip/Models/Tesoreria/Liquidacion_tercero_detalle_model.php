<?php namespace App\Models\Tesoreria;

use CodeIgniter\Model;

class Liquidacion_tercero_detalle_model extends Model
{
  protected $table      = 'liquidacion_tercero_detalle';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'item',
    'fecha',
    'descripcion',
    'importe',
    'id_liquidacion_tercero'
  ];
  
}
