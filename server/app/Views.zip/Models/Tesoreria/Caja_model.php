<?php namespace App\Models\Tesoreria;

use CodeIgniter\Model;
use App\Models\Configuracion\Ajuste_avanzado_model;

class Caja_model extends Model
{
  protected $table      = 'caja';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'fecha',
    'serie' ,
    'numero',
    'id_empresa',
    'id_viaje',
    'tipo_persona',
    'id_tipo_persona',
    'nombre_persona',
    'motivo',
    'modalidad',
    'importe',
    'observacion',
    'cuenta_bancaria_persona',
    'titular_cuenta',
    'id_cuenta_bancaria_empresa',
    'id_cuenta_bancaria_persona',
    'fl_estado',
    'descripcion',
    'tipo',
    'id_usuario',
    'comentario_autorizacion',
    'id_moneda',
    'fl_no_liquidacion_viaje',
    'tipo_cambio',
	  'id_gasto_recurrente',
    'id_cuenta_bancaria_detraccion_persona',
    'monto_detraccion',
    'porcentaje_detraccion'
  ];

  public function get_correlativo($serie = null)
  {
    $Caja_m = new Caja_model();
    $Ajuste_avanzado_m = new Ajuste_avanzado_model();

    $ajuste = $Ajuste_avanzado_m->where('id_empresa', ID_EMPRESA)->first();

    $serie = ($ajuste->tesoreria_serie_caja != null && $ajuste->tesoreria_serie_caja != '') ? $ajuste->tesoreria_serie_caja : date("Y");

    $response = $Caja_m->select('COALESCE(MAX(CAST(numero AS UNSIGNED)), 0) as numero')
    ->where('serie', $serie)
    ->where('id_empresa', ID_EMPRESA)
    ->first();

    $response->serie = $serie;
    $response->numero = str_pad(($response->numero + 1),  8, "0", STR_PAD_LEFT);

    return $response;
  }

}
