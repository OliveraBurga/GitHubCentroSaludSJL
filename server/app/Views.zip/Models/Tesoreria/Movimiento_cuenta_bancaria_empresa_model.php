<?php namespace App\Models\Tesoreria;

use CodeIgniter\Model;

class Movimiento_cuenta_bancaria_empresa_model extends Model
{
  protected $table      = 'movimiento_cuenta_bancaria_empresa';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'tipo',
    'monto',
    'id_cuenta_bancaria',
    'descripcion',
    'fecha',
    'id_caja',
    'id_cobranza',
  ];

}
