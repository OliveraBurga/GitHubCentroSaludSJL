<?php namespace App\Models\Tesoreria;

use CodeIgniter\Model;

class Caja_pago_compra_model extends Model
{
  protected $table      = 'caja_pago_compra';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_caja',
    'id_compra',
    'monto',
    'id_empresa',
    'id_membresia',
    'id_usuario',
    'fecha',
    'id_moneda'
  ];

}
