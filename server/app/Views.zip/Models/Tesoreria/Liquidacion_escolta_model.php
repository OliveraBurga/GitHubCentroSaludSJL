<?php namespace App\Models\Tesoreria;

use CodeIgniter\Model;

class Liquidacion_escolta_model extends Model
{
  protected $table      = 'liquidacion_escolta';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'fecha',
    'serie',
    'numero',
    'fecha_sistema',
    'id_viaje',
    'total_servicio',
    'total_importe',
    'fl_estado',
    'id_empresa',
    'observacion',
    'modalidad_pago',
    'referencia_pago',
    'numero_factura',
    'serie_factura',
    'porcentaje_detraccion',
    'fecha_detraccion',
    'total_detraccion',
    'total_adelanto',
    'total_igv',
    'banco_detraccion',
    'bien_servicio'
  ];

  public function get_correlativo($serie)
  {
    $Liquidacion_escolta_m = new Liquidacion_escolta_model();

    $response = $Liquidacion_escolta_m->select('COALESCE(MAX(CAST(numero AS UNSIGNED)), 0) as numero')
    ->where('serie', $serie)
    ->where('id_empresa', ID_EMPRESA)
    ->first();

    $response->serie = $serie;
    $response->numero = str_pad(($response->numero + 1),  8, "0", STR_PAD_LEFT);

    return $response;
  }

}
