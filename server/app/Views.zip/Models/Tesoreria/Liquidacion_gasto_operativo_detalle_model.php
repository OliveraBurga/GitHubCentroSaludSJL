<?php namespace App\Models\Tesoreria;

use CodeIgniter\Model;

class Liquidacion_gasto_operativo_detalle_model extends Model
{
  protected $table      = 'liquidacion_gasto_operativo_detalle';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'item',
    'fecha',
    'descripcion',
    'importe',
    'id_liquidacion_gasto_operativo'
  ];
}
