<?php namespace App\Models\Tesoreria;

use CodeIgniter\Model;

class Liquidacion_escolta_detalle_model extends Model
{
  protected $table      = 'liquidacion_escolta_detalle';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'item',
    'fecha',
    'descripcion',
    'importe',
    'id_liquidacion_escolta'
  ];


}
