<?php namespace App\Models\Almacen;

use CodeIgniter\Model;

class Marca_model extends Model
{
  protected $table      = 'alm_marca';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'nombre', 
    'id_empresa', 
    'id_membresia'
  ];

}
