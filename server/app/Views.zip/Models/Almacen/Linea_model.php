<?php namespace App\Models\Almacen;

use CodeIgniter\Model;

class Linea_model extends Model
{
  protected $table      = 'alm_linea';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'codigo', 
    'nombre', 
    'id_empresa', 
    'id_membresia'
  ];

}
