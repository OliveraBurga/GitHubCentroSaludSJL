<?php namespace App\Models\Almacen;

use CodeIgniter\Model;

class Articulo_model extends Model
{
  protected $table      = 'alm_articulo';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'codigo',
    'nombre',
    'id_tipo_articulo',
    'id_linea',
    'id_sublinea',
    'descripcion',
    'id_unidad_medida',
    'id_marca',
    'fl_estado',
    'cantidad',
    'cantidad_minimo',
    'costo',
    'fecha_sistema',
    'id_usuario',
    'id_membresia',
    'observacion',
    'codigo_barra',
    'imagen',
    'id_empresa'
  ];

}
