<?php namespace App\Models\Almacen;

use CodeIgniter\Model;

class Salida_articulo_detalle_model extends Model
{
  protected $table      = 'alm_salida_articulo_detalle';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_salida_articulo',
    'id_articulo',
    'cantidad',
    'costo_unitario',
    'importe',
  ];

}
