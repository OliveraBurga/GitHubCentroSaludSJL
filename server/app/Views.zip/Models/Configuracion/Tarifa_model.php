<?php namespace App\Models\Configuracion;

use CodeIgniter\Model;

class Tarifa_model extends Model
{
  protected $table      = 'tarifa';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_ruta', 
    'tipo_servicio', 
    'tipo_medida', 
    'costo_medida', 
    'id_empresa',
    'id_cliente',
    'id_vehiculo_modelo'
  ];
}
