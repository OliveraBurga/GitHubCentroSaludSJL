<?php namespace App\Models\Configuracion;

use CodeIgniter\Model;

class Vehiculo_model extends Model
{
  protected $table      = 'vehiculo';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'placa',
    'tipo_contratacion',
    'ano_fabricacion',
    'ano_modelo',
    'id_vehiculo_clase',
    'marca',
    'modelo',
    'capacidad_carga',
    'galones',
    'id_remolque',
    'id_conductor',
    'id_proveedor',
    'id_empresa',
    'numero_motor',
    'serie_chasis',
    'color',
    'cantidad_ruedas',
    'cantidad_cilindros',
    'cantidad_asientos', 
    'cantidad_pasajeros', 
    'cantidad_ejes', 
    'mtc', 
    'peso_seco', 
    'peso_bruto', 
    'carga_util', 
    'hp_motor', 
    'longitud', 
    'altura', 
    'ancho', 
    'cantidad_pinas', 
    'combustible', 
    'carroceria',
    'imagen',
    'tipo_carga',

    /*** TPA */
    'region',
    'planta',
    'plan_contingencia',
    'ruta',
    'vencimiento_tarjeta_circu_tracto',
    'vencimiento_tarjeta_circu_cisterna',
    'empresa_cubicacion',
    'numero_tarjeta_cubicacion',
    'vencimiento_cubicacion',
    'tabla_aforo',
    'tapa_manhole',
    'scull_valvula_fondo',
    'vencimiento_soat',
    'vencimiento_inspec_tracto',
    'vencimiento_inspec_cisterna',
    'numero_dgh',
    'vencimiento_matpel',
    'empresa_aseguradora',
    'vencimiento_poliza_millon_anual',
    'vencimiento_poliza_millon_mensual',
    'tipologia_unidad',
    'unidad_dedicada',
    'vencimiento_iqbf',
    'proveedor_gps',
    'plataforma',
    'ultimo_mantenimiento_gps',
    'fecha_fabricacion_gps',
    'modelo_gps',
    'tablet',
    'care_drive',
    'camara',
    'balones',
    'lanzas',
    'parches',
    'pagina_web_gps',
    'pagina_usuario',
    'pagina_clave',

    /*** MALVINAS */
    'tipo_flete',
    'costo_flete'
    
  ];
}
