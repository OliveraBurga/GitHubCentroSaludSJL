<?php namespace App\Models\Configuracion;

use CodeIgniter\Model;

class Vehiculo_llanta_model extends Model
{
  protected $table      = 'vehiculo_llanta';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_vehiculo', 
    'configuracion',
    'kilometraje',
    'posicion',
    'codigo',
    'marca',
    'medida',
    'diseno',
    'condicion',
    'vida',
    'remanente',
    'presion_recomendada',
    'presion_actual',
    'codigo_unico'
  ];
}
