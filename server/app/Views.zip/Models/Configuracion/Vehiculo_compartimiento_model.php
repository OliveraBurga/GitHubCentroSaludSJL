<?php namespace App\Models\Configuracion;

use CodeIgniter\Model;

class Vehiculo_compartimiento_model extends Model
{
  protected $table      = 'vehiculo_compartimiento';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_vehiculo', 
    'nombre',
    'capacidad_carga',
    'id_empresa'
  ];
}
