<?php namespace App\Models\Configuracion;

use CodeIgniter\Model;

class Ajuste_avanzado_model extends Model
{
  protected $table      = 'ajuste_avanzado';
  protected $primaryKey = 'id_empresa';
  protected $returnType = 'object';

  protected $allowedFields = [ 
    'fl_viaje_cantidad_opcional', 
    'id_empresa', 
    'fl_factura_formato_customer', 
    'fl_proforma_formato_customer', 
    'fl_orden_crear_viaje_autoselect',
    'fl_viaje_monitoreo',
    'viaje_inicio_estado',
    'viaje_retornar_estado',
    'viaje_finalizar_estado',
    'fl_tesoreria_bloqueo_caja_orden_facturado',
    'tipo_cambio',
    'porcentaje_detraccion',
    'porcentaje_igv',
    'fl_liquidacion_tercero_print_custom',
    'operacion_viaje_terc_detraccion_opcion',
    'operacion_viaje_terc_igv_opcion',
    'fl_sistema_logo',
    'fl_sistema_change_color',
    'sistema_color_bg',
    'fl_tesoreria_pago_importe_orden',
    'fl_tesoreria_pago_detraccion_no_descuento',
    'fl_rep_ord_serv_custom',


    'operacion_serie_orden',
    'operacion_serie_viaje',
    'operacion_serie_vale_combu',
    'operacion_serie_vale_pago',
    'tesoreria_serie_caja',
    'almacen_serie_orden_comp',
    
    'fl_config_vehiculo_no_duplicidad',
    'fl_tesoreria_liq_tercero_desc_detrac',
    'fl_tesoreria_liq_escolta_desc_detrac'
  ];
}
