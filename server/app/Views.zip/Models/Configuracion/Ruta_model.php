<?php namespace App\Models\Configuracion;

use CodeIgniter\Model;

class Ruta_model extends Model
{
  protected $table      = 'ruta';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'punto_inicio', 
    'punto_final', 
    'distancia_km', 
    'id_empresa', 
    'galones',
    'tipo_vehiculo',
    'capacidad_carga'
  ];
}
