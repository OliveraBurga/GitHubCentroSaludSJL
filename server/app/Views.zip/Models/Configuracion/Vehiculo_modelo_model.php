<?php namespace App\Models\Configuracion;

use CodeIgniter\Model;

class Vehiculo_modelo_model extends Model
{
  protected $table      = 'vehiculo_modelo';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_empresa', 
    'id_vehiculo_marca',
    'nombre'
  ];
}
