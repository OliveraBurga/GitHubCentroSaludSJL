<?php namespace App\Models\Configuracion;

use CodeIgniter\Model;

class Tipo_gasto_operativo_model extends Model
{
  protected $table      = 'tipo_gasto_operativo';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'nombre',
    'id_empresa',
    'fl_no_liquidacion',
    'fl_proveedor',
    'fl_pago_credito'
  ];
}
