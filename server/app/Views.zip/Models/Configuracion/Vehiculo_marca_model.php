<?php namespace App\Models\Configuracion;

use CodeIgniter\Model;

class Vehiculo_marca_model extends Model
{
  protected $table      = 'vehiculo_marca';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_empresa', 
    'nombre'
  ];
}
