<?php namespace App\Models\Configuracion;

use CodeIgniter\Model;

class Gasto_recurrente_model extends Model
{
  protected $table      = 'gasto_recurrente';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'nombre',
    'descripcion',
    'importe',
    'fecha_pago',
    'fecha_sistema',
    'tipo_recurrencia',
    'fl_estado',
    'id_empresa',
	'id_moneda',
	'id_proveedor'
  ];
}
