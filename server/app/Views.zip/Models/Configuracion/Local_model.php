<?php namespace App\Models\Configuracion;

use CodeIgniter\Model;

class Local_model extends Model
{
  protected $table      = 'local';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_empresa', 
    'nombre', 
    'direccion', 
    'codigo_sunat', 
    'tipo',
    'fl_facturacion',
    'token_pse',
    'descripcion'
  ];

}
