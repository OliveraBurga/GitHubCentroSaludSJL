<?php namespace App\Models\Configuracion;

use CodeIgniter\Model;

class Vehiculo_clase_model extends Model
{
  protected $table      = 'vehiculo_clase';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_empresa', 
    'nombre',
    'json_config',
    'fl_remolque',
    'fl_compartimiento',
    'identificador_vehiculo'
  ];
}
