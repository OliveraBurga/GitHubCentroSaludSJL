<?php namespace App\Models\Configuracion;

use CodeIgniter\Model;

class Vehiculo_km_model extends Model
{
  protected $table      = 'vehiculo_km';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_vehiculo',
    'fecha',
    'km'    
  ];
}
