<?php namespace App\Models\Configuracion;

use CodeIgniter\Model;

class Cliente_model extends Model
{
  protected $table      = 'cliente';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_documento', 
    'numero_documento', 
    'razon_social', 
    'id_ubigeo', 
    'direccion', 
    'id_empresa', 
    'telefono', 
    'persona_encargado',
    'imagen',
    'email'
  ];
}
