<?php namespace App\Models\Configuracion;

use CodeIgniter\Model;

class Subcliente_model extends Model
{
  protected $table      = 'subcliente';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_documento', 
    'numero_documento', 
    'razon_social', 
    'direccion', 
    'email',
    'telefono',
    'id_cliente',
    'codigo',
    'distrito',
    'mapa_latitud',
    'mapa_longitud',
    'segmento',
    'vendedor',
    'atencion_tipo',
    'atencion_horario',
    'tienda'
  ];
}
