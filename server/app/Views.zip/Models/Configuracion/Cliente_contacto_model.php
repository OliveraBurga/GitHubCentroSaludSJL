<?php namespace App\Models\Configuracion;

use CodeIgniter\Model;

class Cliente_contacto_model extends Model
{
  protected $table      = 'cliente_contacto';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_cliente',
    'nombre',
    'telefono',
    'email',
    'otros',
  ];
}
