<?php namespace App\Models\Configuracion;

use CodeIgniter\Model;

class Vehiculo_mantenimiento_model extends Model
{
  protected $table      = 'vehiculo_mantenimiento';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_vehiculo', 
    'ciclo_km',
    'alerta_km',
    'mantenimiento',
    'id_empresa'
  ];
}
