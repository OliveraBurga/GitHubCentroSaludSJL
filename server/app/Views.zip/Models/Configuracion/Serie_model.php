<?php namespace App\Models\Configuracion;

use CodeIgniter\Model;

class Serie_model extends Model
{
  protected $table      = 'serie';
  protected $primaryKey = 'id';
  protected $returnType = 'object';

  protected $allowedFields = [
    'id_comprobante', 
    'serie', 
    'numero', 
    'tipo', 
    'id_empresa'
  ];
}
