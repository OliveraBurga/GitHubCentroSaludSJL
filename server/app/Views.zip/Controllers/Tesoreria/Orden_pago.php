<?php namespace App\Controllers\Tesoreria;

use App\Controllers\BaseController;

use App\Models\Operacion\Orden_model;
use App\Models\Tesoreria\Flujo_caja_model;
use App\Models\Tesoreria\Orden_pago_model;
use App\Models\Configuracion\Ajuste_avanzado_model;

class Orden_pago extends BaseController
{
	public function __construct()
	{
		$this->Orden_pago_m = new Orden_pago_model();
		$this->Orden_m = new Orden_model();
		$this->Flujo_caja_m = new Flujo_caja_model();
		$this->Ajuste_avanzado_m = new Ajuste_avanzado_model();
	}

	public function orden_pendiente()
	{		
		$ajuste = $this->Ajuste_avanzado_m->where('id_empresa', ID_EMPRESA)->first();

		$response = $this->Orden_m->select('orden.*, concat(orden.serie,"-",orden.numero) as orden')
		->select('c.razon_social as cliente')
		->select('coalesce(concat(r.punto_inicio," - ",r.punto_final), "") as ruta')
		->select('mo.simbolo as moneda_orden, mo.id as id_moneda_orden')
		->select('mf.simbolo as moneda_factura, mf.id as id_moneda_factura')
		->select('coalesce(concat(f.serie,"-",f.numero), "") as factura, f.total_importe as total_importe_factura, f.porcentaje_detraccion as porcentaje_detraccion_factura, f.total_detraccion, f.fl_masivo as factura_masivo')
		->join('cliente c', 'c.id = orden.id_cliente', 'left')
		->join('ruta r', 'r.id = orden.id_ruta', 'left')
		->join('factura f', 'f.id = orden.id_factura')
		->join('static_moneda mo', 'mo.id = orden.id_moneda', 'left')
		->join('static_moneda mf', 'mf.id = f.id_moneda', 'left')
		->where('orden.fl_estado', 1)
		->where('orden.fl_pagado', null)
		->where('orden.id_empresa', ID_EMPRESA)		
		->findAll();

		foreach ($response as $row) {

			$total_pago = $this->Orden_pago_m->select('coalesce(sum(monto), 0) as monto')->where('id_orden', $row->id)->first();

			// COBRAR SEGÚN FACTURA O SEGÚN IMPORTE DE ORDEN
			if($ajuste->fl_tesoreria_pago_importe_orden == 1)
			{
				$row->moneda_deuda = $row->moneda_orden;
				$row->id_moneda_deuda = $row->id_moneda_orden;
				$total_orden = $row->total_orden;
			}
			else
			{
				if($row->factura_masivo == 1)
				{
					$row->moneda_deuda = $row->moneda_orden;
					$row->id_moneda_deuda = $row->id_moneda_orden;
					$total_orden = $row->total_orden;
				}
				else
				{
					$row->id_moneda_deuda = $row->id_moneda_factura;
					$row->moneda_deuda = $row->moneda_factura;

					$total_orden = $row->total_importe_factura;

					if($ajuste->fl_tesoreria_pago_detraccion_no_descuento != 1)
					{
						/*** DESCUENTO DETRACCIÓN */
						$total_orden = $total_orden - $row->total_detraccion;
					}
					
				}	
			}
					

			$total_deuda = $total_orden - $total_pago->monto;

			$row->total_pago = $total_pago->monto;
			$row->total_deuda = number_format($total_deuda, 2, '.', '');
		}

		return $this->respond(['data' => $response], 200);
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response = $this->Orden_pago_m->select("id, concat(serie, ' - ', numero) as text");

		$response = $response
		->where('id_empresa', ID_EMPRESA)
		->findAll();
		
		return $this->respond($response, 200);
	}

	public function get_correlativo($serie)
	{
		$secuencia = $this->Orden_pago_m->get_correlativo($serie);

		return $this->respond($secuencia, 200);
	}

	public function print($id)
	{
		$response = $this->Orden_pago_m->select('orden_pago.*')
		->select('coalesce(concat(o.serie, "-", o.numero), "") as orden')
		->select('e.nombre_comercial as empresa, e.logo')
		->select('u.usuario')
		->select('coalesce(mp.simbolo, "") as moneda_pago')

		->join('orden o', 'o.id = orden_pago.id_orden', 'left')
		->join('empresa e', 'e.id = orden_pago.id_empresa', 'left')
		->join('usuario u', 'u.id = orden_pago.id_usuario', 'left')
		->join('static_moneda mp', 'mp.id = orden_pago.id_moneda', 'left')

		->where('orden_pago.id_empresa', ID_EMPRESA)	
		->where('orden_pago.id', $id)	
		->first();

		$cantidad_pagos = $this->Orden_pago_m->where('id_orden', $response->id_orden)->countAllResults();

		$response->cantidad_pagos = $cantidad_pagos;

		return $this->respond($response, 200);
	}

	public function index()
	{		
		$data_request = $this->request->getGet();

		$response = $this->Orden_pago_m->select('orden_pago.*')
		->select('concat(o.serie, "-", o.numero) as orden, o.total_orden')
		->select('mo.simbolo as moneda_orden')
		->select('mf.simbolo as moneda_factura')
		->select('coalesce(mp.simbolo, "") as moneda_pago')
		->select('coalesce(concat(f.serie,"-",f.numero), "") as factura, f.total_importe as total_importe_factura')

		->join('orden o', 'o.id = orden_pago.id_orden', 'left')
		->join('static_moneda mo', 'mo.id = o.id_moneda', 'left')
		->join('factura f', 'f.id = o.id_factura', 'left')
		->join('static_moneda mf', 'mf.id = f.id_moneda', 'left')
		->join('static_moneda mp', 'mp.id = orden_pago.id_moneda', 'left')

		->where('DATE_FORMAT(orden_pago.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(orden_pago.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])
		->where('orden_pago.id_empresa', ID_EMPRESA)		
		->findAll();

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('tesoreria-orden_pago', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('tesoreria-orden_pago', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$aporte = $data_request["monto_pago"];

            $efectivo = $aporte;
            $ordenes_pagadas = array();
            $orden_saldo = null;

            /* RECORRIENDO DETALLE */
            foreach (json_decode($data_request["detalle_orden"]) as $item) {
                
				$id_orden = $item->id;

                $orden = $this->Orden_m->select('id as id_orden, total_orden')->find($id_orden);

				$orden->monto_cobrar = $item->total_deuda;

				
                $efectivo = $efectivo - $orden->monto_cobrar;

                if($efectivo > 0)
                {
                    /* PAGANDO COMPROBANTES */
                    $ordenes_pagadas[] = $orden;
                }
                else if($efectivo == 0)
                {
                    /* PAGO EXACTO */
                    $ordenes_pagadas[] = $orden;
                    break;
                }
                else
                {
                    /* COMPROBANTE SALDO */
                    $orden_saldo = $orden;
                    $saldo = abs($efectivo);
                    $efectivo = 0;
                    break;
                }
            }

            foreach ($ordenes_pagadas as $row) {

                /** REGISTRAR PAGO */
                $array_pago = [
                  'id_cuenta_bancaria_empresa'   	=> (isset($data_request["id_cuenta_bancaria_empresa"])) ? $data_request["id_cuenta_bancaria_empresa"] : null,
                  'tipo_canal'        				=> $data_request["tipo_canal"],
                  'medio_pago'         				=> $data_request["medio_pago"],
				  'numero_operacion'         		=> $data_request["numero_operacion"],
                  'observacion'           			=> $data_request["observacion"],
                  'id_empresa'       				=> ID_EMPRESA,
                  'id_usuario'        				=> ID_USUARIO,
                  'monto'             				=> $row->monto_cobrar,
                  'id_orden'          				=> $row->id_orden,
                  'fecha'             				=> $data_request["fecha"],
				  'fecha_sistema'					=> date("Y-m-d H:i:s"),
				  'id_moneda'						=> $data_request["id_moneda"]
                ];

                $this->Orden_pago_m->save($array_pago);

                $id_orden_pago = $db->insertID();

                /** SAVE FLUJO CAJA */
				$data =  [
					'fecha'       					=> $data_request["fecha"],
					'tipo'        					=> 'INGRESO',
					'descripcion' 					=> $data_request["numero_operacion"],
					'id_orden_pago'					=> $id_orden_pago,
					'id_usuario'  					=> ID_USUARIO,
					'id_empresa' 					=> ID_EMPRESA,
					'id_cuenta_bancaria_empresa'   	=> (isset($data_request["id_cuenta_bancaria_empresa"])) ? $data_request["id_cuenta_bancaria_empresa"] : null,
					'monto'       					=>  $row->monto_cobrar
				];

				$this->Flujo_caja_m->save($data);
                               

                /* GUARDAR ESTADO */                
                $array_save = [
                  'id'          		=> $row->id_orden,
                  'fl_pagado'         	=> 1,
                ];
    
                $this->Orden_m->save($array_save);

				/****************** SAVE CENTINELA *****************/
				$orden_pago = $this->Orden_pago_m->select('concat(o.serie,"-",o.numero) as orden')
				->join('orden o', 'o.id = orden_pago.id_orden')
				->select('orden_pago.monto')
				->find($id_orden_pago);

				$data_centinela = [
					'modulo'		=> 'TESORERIA',
					'menu'			=> 'PAGO DE ÓRDENES',
					'accion'		=> 'NUEVO',
					'descripcion'	=> 'Pago Completo: '.$orden_pago->monto.', Orden: '.$orden_pago->orden
				];

				$this->Centinela_m->registrar($data_centinela);
				/*************************************************** */
                
            } 

            if ($orden_saldo != null) {

				/** REGISTRAR PAGO */
                $array_pago = [
					'id_cuenta_bancaria_empresa'   		=> (isset($data_request["id_cuenta_bancaria_empresa"])) ? $data_request["id_cuenta_bancaria_empresa"] : null,
					'tipo_canal'        				=> $data_request["tipo_canal"],
					'medio_pago'         				=> $data_request["medio_pago"],
					'numero_operacion'         			=> $data_request["numero_operacion"],
					'observacion'           			=> $data_request["observacion"],
					'id_empresa'       					=> ID_EMPRESA,
					'id_usuario'        				=> ID_USUARIO,
					'monto'             				=> $orden_saldo->monto_cobrar - $saldo,
					'id_orden'          				=> $orden_saldo->id_orden,
					'fecha'             				=> $data_request["fecha"],
					'fecha_sistema'						=> date("Y-m-d H:i:s"),
					'id_moneda'						=> $data_request["id_moneda"]
				  ];

				$this->Orden_pago_m->save($array_pago);

                $id_orden_pago = $db->insertID();

				/** SAVE FLUJO CAJA */
				$data =  [
					'fecha'       					=> $data_request["fecha"],
					'tipo'        					=> 'INGRESO',
					'descripcion' 					=> $data_request["numero_operacion"],
					'id_orden_pago'					=> $id_orden_pago,
					'id_usuario'  					=> ID_USUARIO,
					'id_empresa' 					=> ID_EMPRESA,
					'id_cuenta_bancaria_empresa'   	=> (isset($data_request["id_cuenta_bancaria_empresa"])) ? $data_request["id_cuenta_bancaria_empresa"] : null,
					'monto'       					=> $orden_saldo->monto_cobrar - $saldo
				];

				$this->Flujo_caja_m->save($data);

				/****************** SAVE CENTINELA *****************/
				$orden_pago = $this->Orden_pago_m->select('concat(o.serie,"-",o.numero) as orden')
				->select('orden_pago.monto')
				->join('orden o', 'o.id = orden_pago.id_orden')
				->find($id_orden_pago);

				$data_centinela = [
					'modulo'		=> 'TESORERIA',
					'menu'			=> 'PAGO DE ÓRDENES',
					'accion'		=> 'NUEVO',
					'descripcion'	=> 'Pago Parcial: '.$orden_pago->monto.', Orden: '.$orden_pago->orden
				];

				$this->Centinela_m->registrar($data_centinela);
				/*************************************************** */
                
				
            }
				

			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function edit()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('tesoreria-orden_pago', 'edit');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$orden_pago = $this->Orden_pago_m->select('f.id as id_flujo_caja, orden_pago.id, orden_pago.id_orden, o.total_orden')
			->join('flujo_caja f', 'f.id_orden_pago = orden_pago.id')
			->join('orden o', 'o.id = orden_pago.id_orden')
			->where('orden_pago.id', $data_request["id"])
			->first();

			if(is_object($orden_pago))
			{
				/** REGISTRAR PAGO */
				$array_pago = [
					'id_cuenta_bancaria_empresa'   	=> (isset($data_request["id_cuenta_bancaria_empresa"])) ? $data_request["id_cuenta_bancaria_empresa"] : null,
					'tipo_canal'        			=> $data_request["tipo_canal"],
					'medio_pago'         			=> $data_request["medio_pago"],
					'numero_operacion'         		=> $data_request["numero_operacion"],
					'observacion'           		=> $data_request["observacion"],
					'id_usuario'        			=> ID_USUARIO,
					'monto'             			=> $data_request["monto_pago"],
					'fecha'             			=> $data_request["fecha"],
					'id'							=> $data_request["id"]
				];

				$this->Orden_pago_m->save($array_pago);

				/** SAVE FLUJO CAJA */
				$data =  [
					'fecha'       					=> $data_request["fecha"],
					'tipo'        					=> 'INGRESO',
					'descripcion' 					=> $data_request["numero_operacion"],
					'id_orden_pago'					=> $data_request["id"],
					'id_usuario'  					=> ID_USUARIO,
					'id_cuenta_bancaria_empresa'   	=> (isset($data_request["id_cuenta_bancaria_empresa"])) ? $data_request["id_cuenta_bancaria_empresa"] : null,
					'monto'       					=> $data_request["monto_pago"],
					'id'							=> $orden_pago->id_flujo_caja
				];

				$this->Flujo_caja_m->save($data);
				

				/*** VERIFICAR PAGO TOTAL */
				$total_pago = $this->Orden_pago_m->select('coalesce(sum(monto), 0) as monto')->where('id_orden', $orden_pago->id_orden)->first();
			
				/* GUARDAR ESTADO */                
				$array_save = [
					'id'          		=> $orden_pago->id_orden,
					'fl_pagado'         => ($total_pago->monto >= $orden_pago->total_orden) ? 1 : null,
				];				
	
				$this->Orden_m->save($array_save);

				/****************** SAVE CENTINELA *****************/
				$orden_pago = $this->Orden_pago_m->select('concat(o.serie,"-",o.numero) as orden')
				->select('orden_pago.monto')
				->join('orden o', 'o.id = orden_pago.id_orden')
				->find($data_request["id"]);

				$data_centinela = [
					'modulo'		=> 'TESORERIA',
					'menu'			=> 'PAGO DE ÓRDENES',
					'accion'		=> 'EDITAR',
					'descripcion'	=> 'Monto: '.$orden_pago->monto.', Orden: '.$orden_pago->orden
				];

				$this->Centinela_m->registrar($data_centinela);
				/*************************************************** */

				$db->transComplete();

				return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);
			}
			else
			{
				return $this->respond(['tipo' => 'warning', 'mensaje' => 'No hubo cambios'], 200);
			}
			

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('tesoreria-orden_pago', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$orden_pago = $this->Orden_pago_m->select('concat(o.serie,"-",o.numero) as orden, orden_pago.id as id_orden')
			->select('orden_pago.monto')
			->join('orden o', 'o.id = orden_pago.id_orden')
			->find($data_request["id"]);

			$data = [
				'id'		=> $orden_pago->id_orden,
				'fl_pagado'	=> null
			];

			$this->Orden_m->save($data);

			$this->Orden_pago_m->where('id', $data_request["id"])->delete();
			$this->Flujo_caja_m->where('id_orden_pago', $data_request["id"])->delete();

			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'TESORERIA',
				'menu'			=> 'PAGO DE ÓRDENES',
				'accion'		=> 'ELIMINAR',
				'descripcion'	=> 'Monto: '.$orden_pago->monto.', Orden: '.$orden_pago->orden
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
