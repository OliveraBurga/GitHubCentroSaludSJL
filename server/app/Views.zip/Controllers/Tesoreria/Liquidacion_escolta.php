<?php namespace App\Controllers\Tesoreria;

use App\Controllers\BaseController;
use App\Models\Tesoreria\Liquidacion_escolta_model;
use App\Models\Operacion\Viaje_model;
use App\Models\Tesoreria\Caja_model;
use App\Models\Operacion\Viaje_guia_model;
use App\Models\Operacion\Viaje_escolta_model;
use App\Models\Configuracion\Empresa_model;
use App\Models\Configuracion\Cuenta_bancaria_persona_model;
use App\Models\Configuracion\Ajuste_avanzado_model;

class Liquidacion_escolta extends BaseController
{
	public function __construct()
	{
		$this->Liquidacion_escolta_m = new Liquidacion_escolta_model();
		$this->Viaje_m = new Viaje_model();
		$this->Caja_m = new Caja_model();
		$this->Empresa_m = new Empresa_model();
		$this->Viaje_guia_m = new Viaje_guia_model();
		$this->Cuenta_bancaria_persona_m = new Cuenta_bancaria_persona_model();
		$this->Ajuste_avanzado_m = new Ajuste_avanzado_model();
		$this->Viaje_escolta_m = new Viaje_escolta_model();
	}

	public function print($id_liquidacion_escolta)
	{
		$response = $this->Liquidacion_escolta_m->select('liquidacion_escolta.*')
		->select('concat(v.serie, "-", v.numero) as viaje, v.id as id_viaje')
		->select('vh.placa as vehiculo')
		->select('coalesce(vs.placa, "") as remolque')
		->select('p.razon_social as proveedor, p.numero_documento as numero_documento_proveedor')
		->select('dp.nombre as documento_proveedor')
		->select('m.nombre as moneda, m.simbolo as simbolo_moneda')
		->join('viaje v', 'v.id = liquidacion_escolta.id_viaje', 'left')
		->join('vehiculo vh', 'vh.id = v.id_vehiculo', 'left')
		->join('vehiculo vs', 'vs.id = v.id_remolque', 'left')
		->join('proveedor p', 'p.id = v.id_proveedor_escolta', 'left')
		->join('static_documento dp', 'dp.id = p.id_documento', 'left')
		->join('static_moneda m', 'm.id = v.id_moneda_escolta', 'left')
		->where('liquidacion_escolta.id', $id_liquidacion_escolta)
		->first();

		$vehiculos_escolta = $this->Viaje_escolta_m->where('id_viaje', $response->id_viaje)->findAll();

		$array_vehiculos = [];
		foreach ($vehiculos_escolta as $row) {
			$array_vehiculos[] = $row->vehiculo;
		}

		$response->vehiculos_escolta = implode(', ', $array_vehiculos);

		$response->empresa = $this->Empresa_m->find(ID_EMPRESA);

		return $this->respond($response, 200);
	}

	public function get_liquidar($id_viaje)
	{		
		$data_request = $this->request->getGet();		
		
		if(isset($data_request["porcentaje_detraccion"]) && !is_numeric($data_request["porcentaje_detraccion"]))
		{
			$data_request["porcentaje_detraccion"] = 0;
		}

		$response = $this->Viaje_m->select('lg.*,')
		->select('concat(viaje.serie, "-", viaje.numero) as viaje, viaje.id as id_viaje, viaje.costo_escolta, viaje.mas_inc_igv_escolta, viaje.porc_detraccion_escolta, viaje.numero_factura_escolta, viaje.serie_factura_escolta, viaje.id_moneda_escolta')
		->select('p.nombre_completo as conductor, p.id as id_conductor')
		->select('lg.id as id_liquidacion_escolta')
		->select('v.placa as vehiculo, v.id_proveedor')
		->select('coalesce(vs.placa, "") as remolque')
		->select('pr.razon_social as razon_social_proveedor, pr.numero_documento as numero_documento_proveedor')
		->select('m.simbolo as simbolo_moneda')
		->join('liquidacion_escolta lg', 'lg.id = viaje.id_liquidacion_escolta', 'left')
		->join('personal p', 'p.id = viaje.id_conductor', 'left')
		->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
		->join('vehiculo vs', 'vs.id = viaje.id_remolque', 'left')
		->join('proveedor pr', 'pr.id = viaje.id_proveedor_escolta', 'left')
		->join('static_moneda m', 'm.id = viaje.id_moneda_escolta')
		->where('viaje.id', $id_viaje)
		->where("viaje.id_proveedor_escolta !=", null)
		->where('viaje.fl_estado', 1)
		->first();		


		$porcentaje_detraccion = (isset($data_request["porcentaje_detraccion"])) ? $data_request["porcentaje_detraccion"] : $response->porc_detraccion_escolta;

		/** AJUSTE AVANZADO */
		$ajuste = $this->Ajuste_avanzado_m->where('id_empresa', ID_EMPRESA)->first();

		$response->ajuste = $ajuste;

		/*** VEHICULOS ESCOLTA */
		$response->vehiculos_escolta = $this->Viaje_escolta_m->where('id_viaje', $id_viaje)->findAll();

		/*** ADELANTOS */		
		$detalle_adelanto = $this->Caja_m->select('caja.*,')
		->select('m.simbolo as simbolo_moneda')
		->select('coalesce(caja.tipo_cambio, "") as tipo_cambio')
		->join('static_moneda m', 'm.id = caja.id_moneda')
		->where('id_viaje', $id_viaje)
		->where('fl_estado', 3)
		->where('motivo', 'ADELANTO SERVICIO ESCOLTA')
		->findAll();

		$response->detalle_adelanto = $detalle_adelanto;

		$total_adelanto = 0;
		
		foreach ($detalle_adelanto as $deta) {
			$total_adelanto = $total_adelanto + $deta->importe;
		}		

		$response->total_adelanto = number_format($total_adelanto, 2, '.', '');

		/** PAGO SERVICIO TERCERIZADO */
		$response->pago_flete = $this->Caja_m->where('id_viaje', $id_viaje)
		->where('fl_estado', 3)
		->where('motivo', 'SERVICIO ESCOLTA')
		->orderBy('id', 'desc')
		->first();

		$response->guia_transportista = $this->Viaje_guia_m->where('id_viaje', $id_viaje)
		->where('tipo', 'TRANSPORTISTA')
		->findAll();

		$response->bancos_proveedor = $this->Cuenta_bancaria_persona_m->where('id_proveedor', $response->id_proveedor)
		->where('fl_detraccion', 1)
		->findAll();		
		
	

		/** CALCULO IMPORTE */
		$response->total_igv = 0;

		if($response->mas_inc_igv_escolta == 'MAS_IGV')
		{						
			$response->total_servicio = $response->costo_escolta;
			$monto_base = $response->costo_escolta;

			$total_igv =  $response->costo_escolta * (($ajuste->porcentaje_igv / 100));
			$importe = $monto_base + $total_igv;
		}		
		else
		{
			
			$monto_base = $response->costo_escolta / (($ajuste->porcentaje_igv / 100) + 1);
			$response->total_servicio = $monto_base;

			$total_igv =  $response->costo_escolta - $monto_base;

			$importe = $response->costo_escolta;
			
		}	
		
		$response->total_servicio = number_format($response->total_servicio, 2, '.', '');
		
		$response->total_igv = $importe - $monto_base;		
		$response->total_igv = number_format($response->total_igv, 2, '.', '');

		$response->total_detraccion = $importe * ($porcentaje_detraccion / 100);		
		$response->total_detraccion = number_format($response->total_detraccion, 2, '.', '');
		$response->porcentaje_detraccion = $porcentaje_detraccion;
		
		if($ajuste->fl_tesoreria_liq_escolta_desc_detrac == 1)
		{
			$importe = $importe - $response->total_detraccion;
		}
		

		$total_importe =  $importe - $total_adelanto;
		
		$response->total_importe = number_format($total_importe, 2, '.', '');

		return $this->respond($response, 200);
	}

	public function index()
	{		
		$data_request = $this->request->getGet();		

		if($data_request["tipo"] == 'SIN_LIQUIDAR')
		{ 
			$response = $this->Viaje_m->select('lg.*,')
			->select('concat(viaje.serie, "-", viaje.numero) as viaje, viaje.id as id_viaje, viaje.serie_factura_escolta, viaje.numero_factura_escolta')
			->select('lg.id as id_liquidacion_escolta')
			->select('pr.razon_social as razon_social_proveedor, pr.numero_documento as numero_documento_proveedor')
			->select('m.nombre as moneda, m.simbolo as simbolo_moneda')
			->join('liquidacion_escolta lg', 'lg.id = viaje.id_liquidacion_escolta', 'left')
			->join('proveedor pr', 'pr.id = viaje.id_proveedor_escolta', 'left')
			->join('static_moneda m', 'm.id = viaje.id_moneda_escolta', 'left')
			->where("lg.fl_estado", null)
			->where("viaje.costo_escolta >", 0)
			->where('viaje.fl_estado', 1);
		}
		else
		{
			$response = $this->Liquidacion_escolta_m->select('liquidacion_escolta.*,')
			->select('concat(viaje.serie, "-", viaje.numero) as viaje, viaje.id as id_viaje, viaje.serie_factura_escolta')
			->select('liquidacion_escolta.id as id_liquidacion_escolta')			
			->select('pr.razon_social as razon_social_proveedor, pr.numero_documento as numero_documento_proveedor')
			->select('m.nombre as moneda, m.simbolo as simbolo_moneda')
			->join('viaje', 'viaje.id = liquidacion_escolta.id_viaje', 'left')
			->join('proveedor pr', 'pr.id = viaje.id_proveedor_escolta', 'left')
			->join('static_moneda m', 'm.id = viaje.id_moneda_escolta', 'left')
			->where('DATE_FORMAT(liquidacion_escolta.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
			->where('DATE_FORMAT(liquidacion_escolta.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"]);
		}

		$response = $response->where('viaje.id_empresa', ID_EMPRESA)		
		->findAll();

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('tesoreria-liquidacion_escolta', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('tesoreria-liquidacion_escolta', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			/** GUARDAR */
			$data = [
				'fecha' 					=> trim($data_request["fecha"]),
				'id_viaje'					=> trim($data_request["id_viaje"]),
				'id_conductor'				=> trim($data_request["id_conductor"]),
				'modalidad_pago'			=> trim($data_request["modalidad_pago"]),
				'referencia_pago'			=> trim($data_request["referencia_pago"]),
				'numero_factura'			=> trim($data_request["numero_factura"]),
				'serie_factura'				=> trim($data_request["serie_factura"]),
				'total_servicio'			=> trim($data_request["total_servicio"]),
				'total_importe'				=> trim($data_request["total_importe"]),
				'total_detraccion'			=> trim($data_request["total_detraccion"]),
				'total_igv'					=> trim($data_request["total_igv"]),
				'total_adelanto'			=> trim($data_request["total_adelanto"]),
				'observacion'				=> trim($data_request["observacion"]),

				'porcentaje_detraccion'		=> ($data_request["porcentaje_detraccion"] == '') ? 0 : trim($data_request["porcentaje_detraccion"]),
				'fecha_detraccion'			=> (isset($data_request["fecha_detraccion"])) ? trim($data_request["fecha_detraccion"]) : '',
				'banco_detraccion'			=> (isset($data_request["banco_detraccion"])) ? trim($data_request["banco_detraccion"]) : '',

				'bien_servicio'				=> trim($data_request["bien_servicio"]),
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$correlativo = $this->Liquidacion_escolta_m->get_correlativo(date("Y"));
				$data["numero"] = $correlativo->numero;
				$data["serie"] = $correlativo->serie;

				$data["id_usuario"] = ID_USUARIO;
				$data["id_empresa"] = ID_EMPRESA;
				$data["fecha_sistema"] = date("Y-m-d H:i:s");
				$data["fl_estado"] = 1;
			}

			$this->Liquidacion_escolta_m->save($data);

			$id_liquidacion_escolta = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			
			/*** VINCULAR A VIAJE */

			$data_viaje = [
				'id'								=> $data_request["id_viaje"],
				'id_liquidacion_escolta'			=> $id_liquidacion_escolta
			];

			$this->Viaje_m->save($data_viaje);
			

			/****************** SAVE CENTINELA *****************/
			$liquidacion = $this->Liquidacion_escolta_m->select('concat(v.serie,"-",v.numero) as viaje')
			->join('viaje v', 'v.id = liquidacion_escolta.id_viaje')
			->find($id_liquidacion_escolta);

			$data_centinela = [
				'modulo'		=> 'TESORERIA',
				'menu'			=> 'LIQUIDACIÓN SERVICIO DE ESCOLTA',
				'accion'		=> 'NUEVO',
				'descripcion'	=> 'Total Importe: '.trim($data_request["total_importe"]).', Viaje: '.$liquidacion->viaje
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */

			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente', 'id_liquidacion_escolta' => $id_liquidacion_escolta], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('tesoreria-liquidacion_escolta', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$liquidacion = $this->Liquidacion_escolta_m->find($data_request["id"]);

			/** DESVINCULAR DE VIAJE */
			$data_viaje = [
				'id'						=> $liquidacion->id_viaje,
				'id_liquidacion_escolta'	=> null
			];

			$this->Viaje_m->save($data_viaje);

			/** SAVE */
			$data_liquidacion  = [
				'id'		=> $data_request["id"],
				'fl_estado'	=> 0
			];

			$this->Liquidacion_escolta_m->save($data_liquidacion);     

			/****************** SAVE CENTINELA *****************/
			$liquidacion = $this->Liquidacion_escolta_m->select('concat(v.serie,"-",v.numero) as viaje, liquidacion_escolta.total_importe')
			->join('viaje v', 'v.id = liquidacion_escolta.id_viaje')
			->find($data_request["id"]);

			$data_centinela = [
				'modulo'		=> 'TESORERIA',
				'menu'			=> 'LIQUIDACIÓN SERVICIO DE ESCOLTA',
				'accion'		=> 'ANULAR',
				'descripcion'	=> 'Total Importe: '.$liquidacion->total_importe.', Viaje: '.$liquidacion->viaje
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function save_factura_viaje()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('tesoreria-liquidacion_escolta', 'new');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			/** DESVINCULAR DE VIAJE */
			$data_viaje = [
				'id'						=> $data_request["id_viaje"],
				'serie_factura_escolta'		=> $data_request["serie_factura"],
				'numero_factura_escolta'	=> $data_request["numero_factura"],
			];

			$this->Viaje_m->save($data_viaje);
			
			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'TESORERIA',
				'menu'			=> 'LIQUIDACIÓN SERVICIO DE ESCOLTA',
				'accion'		=> 'INSERTAR FACTURA ESCOLTA',
				'descripcion'	=> $data_request["serie_factura"].'-'.$data_request["numero_factura"]
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
