<?php namespace App\Controllers\Tesoreria;

use App\Controllers\BaseController;

use App\Models\Tesoreria\Caja_model;
use App\Models\Tesoreria\Flujo_caja_model;
use App\Models\Tesoreria\Liquidacion_gasto_operativo_model;
use App\Models\Operacion\Viaje_orden_model;
use App\Models\Operacion\Viaje_model;
use App\Models\Configuracion\Empresa_model;

class Caja extends BaseController
{
	public function __construct()
	{
		$this->Caja_m = new Caja_model();
		$this->Flujo_caja_m = new Flujo_caja_model();
		$this->Liquidacion_gasto_operativo_m = new Liquidacion_gasto_operativo_model();
		$this->Empresa_m = new Empresa_model();
		$this->Viaje_m = new Viaje_model();
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response = $this->Caja_m->select("id, concat(serie, ' - ', numero) as text");

		$response = $response
		->where('id_empresa', ID_EMPRESA)
		->findAll();
		
		return $this->respond($response, 200);
	}

	public function get_correlativo()
	{
		$secuencia = $this->Caja_m->get_correlativo();

		return $this->respond($secuencia, 200);
	}

	public function print($id)
	{
		$response = $this->Caja_m->select('caja.*, concat(caja.serie, "-", caja.numero) as caja, coalesce(caja.cuenta_bancaria_persona, "") as cuenta_bancaria_persona, coalesce(caja.observacion, "") as observacion')
		->select('coalesce(concat(v.serie, "-", v.numero), "") as viaje')
		->select('e.nombre_comercial as empresa, e.logo')
		->select('coalesce(m.simbolo, "") as simbolo_moneda, coalesce(m.nombre, "SOLES") as moneda')
		->join('viaje v', 'v.id = caja.id_viaje', 'left')
		->join('empresa e', 'e.id = caja.id_empresa', 'left')
		->join('static_moneda m', 'm.id = caja.id_moneda', 'left')

		->where('caja.id_empresa', ID_EMPRESA)	
		->where('caja.id', $id)	
		->first();

		$response->empresa = $this->Empresa_m->find(ID_EMPRESA);

		return $this->respond($response, 200);
	}

	public function index()
	{		
		$data_request = $this->request->getGet();

		$response = $this->Caja_m->select('caja.*, concat(caja.serie, "-", caja.numero) as caja')
		->select('concat(v.serie, "-", v.numero) as viaje')
		->select('coalesce(m.simbolo, "") as simbolo_moneda')
		->join('viaje v', 'v.id = caja.id_viaje', 'left')
		->join('static_moneda m', 'm.id = caja.id_moneda', 'left')

		->where('DATE_FORMAT(caja.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(caja.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])
		->where('caja.tipo', $data_request["tipo"])		
		->where('caja.id_empresa', ID_EMPRESA)		
		->findAll();

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('tesoreria-caja', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('tesoreria-caja', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->query('SET AUTOCOMMIT = 0');
			$db->transStart();
			$db->query('LOCK TABLES caja write,  flujo_caja write, centinela write, liquidacion_gasto_operativo read, ajuste_avanzado read, viaje_orden read, orden read, viaje write');

			/*** AJUSTE GENERAL */

			$ajuste = $this->Ajuste_avanzado_m->find(ID_EMPRESA);

			if($ajuste->fl_tesoreria_bloqueo_caja_orden_facturado == 1 && isset($data_request["id_viaje"]))
			{
				$Viaje_orden_m = new Viaje_orden_model();

				$ordenes = $Viaje_orden_m->select('orden.id_factura')
				->join('orden', 'orden.id = viaje_orden.id_orden')
				->where('id_viaje', $data_request["id_viaje"])->findAll();

				/*** VALIDAR SI VIAJE CONTIENE ORDENES DE TRABAJO FACTURADOS */

				$facturado = false;

				foreach ($ordenes as $row) {
					if($row->id_factura != null)
					{
						$facturado = true;
					}
				}

				if($facturado == true)
				{
					return $this->respond(['tipo' => 'warning', 'mensaje' => 'No se puede destinar más gastos al viaje seleccionado porque contiene ordenes ya facturadas'], 400);
				}
			}

			/** VALIDAR SI VIAJE ESTÁ LIQUIDADO */
			if(isset($data_request["id_viaje"]) && $data_request["motivo"] == 'GASTOS OPERATIVOS')
			{
				$liquidacion = $this->Liquidacion_gasto_operativo_m->where('id_viaje', $data_request["id_viaje"])
				->where('fl_estado', 1)
				->first();

				if(is_object($liquidacion))
				{
					return $this->respond(['tipo' => 'warning', 'mensaje' => 'No se puede desembolsar por motivo de GASTOS OPERATIVOS, porque el viaje ya cuenta con una liquidación de ello, debería anular la liquidación'], 400);
				}
			}

			/** GUARDAR */
			$data = [
				'fecha'							=> trim($data_request["fecha"]),
				'id_viaje'						=> (isset($data_request["id_viaje"])) ? trim($data_request["id_viaje"]) : null,
				'tipo_persona'					=> trim($data_request["tipo_persona"]),
				'id_tipo_persona'				=> (isset($data_request["id_tipo_persona"])) ? trim($data_request["id_tipo_persona"]) : null,
				'nombre_persona'				=> trim($data_request["nombre_persona"]),
				'motivo'						=> trim($data_request["motivo"]),
				'modalidad'						=> trim($data_request["modalidad"]),
				'id_moneda'						=> trim($data_request["id_moneda"]),
				'importe'						=> trim($data_request["importe"]),
				'observacion'					=> trim($data_request["observacion"]),
				'descripcion'					=> trim($data_request["descripcion"]),
				'cuenta_bancaria_persona'		=> (isset($data_request["cuenta_bancaria_persona"])) ? trim($data_request["cuenta_bancaria_persona"]) : null,
				'titular_cuenta'				=> (isset($data_request["titular_cuenta"])) ? trim($data_request["titular_cuenta"]) : null,
				'id_cuenta_bancaria_empresa'	=> ($data_request["id_cuenta_bancaria_empresa"] != '') ? trim($data_request["id_cuenta_bancaria_empresa"]) : null,
				'id_cuenta_bancaria_persona'	=> (isset($data_request["id_cuenta_bancaria_persona"])) ? trim($data_request["id_cuenta_bancaria_persona"]): null,
				'fl_no_liquidacion_viaje'		=> (isset($data_request["fl_no_liquidacion_viaje"])) ? 1 : null,
				'tipo_cambio'					=> (isset($data_request["tipo_cambio"])) ? $data_request["tipo_cambio"] : null,
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$correlativo = $this->Caja_m->get_correlativo();

				$data["serie"] = $correlativo->serie;
				$data["numero"] = $correlativo->numero;
				$data["tipo"] = trim($data_request["tipo"]);
				$data["fl_estado"] = ($data_request["tipo"] == 'CAJA_RAPIDA') ? 3 : 1;
				$data["id_empresa"] = ID_EMPRESA;
				$data["id_usuario"] = ID_USUARIO;
			}

			$this->Caja_m->save($data);

			$id_caja = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();


			/** SAVE FLUJO CAJA */
			if($data_request["tipo"] == 'CAJA_RAPIDA')
			{
				$this->Flujo_caja_m->where('id_caja', $id_caja)->delete();

				$data =  [
					'fecha'       					=> $data_request["fecha"],
					'tipo'        					=> 'EGRESO',
					'descripcion' 					=> $data_request["descripcion"],
					'id_caja'						=> $id_caja,
					'id_usuario'  					=> ID_USUARIO,
					'id_empresa' 					=> ID_EMPRESA,
					'id_cuenta_bancaria_empresa'   	=> (isset($data_request["id_cuenta_bancaria_empresa"])) ? $data_request["id_cuenta_bancaria_empresa"] : null,
					'monto'       					=> $data_request["importe"]
				];

				$this->Flujo_caja_m->save($data);
			}
			


			/*** OPERACIONES SOLO AL CREAR NUEVA CAJA RÁPIDA */
			if(!isset($data_request["id"]) && $data_request["tipo"] == 'CAJA_RAPIDA' && isset($data_request["id_viaje"]) && $data_request["motivo"] == 'ADELANTO VIAJE TERCERIZADO')
			{
				/*** CANCELAR ADELANTO DE VIAJE TERCERIZADO */
				$viaje = $this->Viaje_m->select('fl_requerimiento_adelanto_tercerizado, monto_adelanto_tercerizado')->find($data_request["id_viaje"]);

				if($viaje->fl_requerimiento_adelanto_tercerizado != 1 && $viaje->monto_adelanto_tercerizado <= $data_request["importe"])
				{
					$data_viaje = [
						'fl_requerimiento_adelanto_tercerizado' => 1,
						'id'									=> $data_request["id_viaje"]
					];

					$this->Viaje_m->save($data_viaje);
				}
				
			}
			


			/****************** SAVE CENTINELA *****************/
			$caja = $this->Caja_m->find($id_caja);

			$data_centinela = [
				'modulo'		=> 'TESORERIA',
				'menu'			=> 'CAJA',
				'accion'		=> (isset($data_request["id"])) ? 'EDITAR' : 'NUEVO',
				'descripcion'	=> $caja->serie.'-'.$caja->numero
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */

			$db->query('UNLOCK TABLES');
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente', 'id_caja' => $id_caja], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('tesoreria-caja', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$data = [
				'id'		=> $data_request["id"],
				'fl_estado'	=> 0
			];

			$this->Caja_m->save($data);

			$caja = $this->Caja_m->find($data_request["id"]);

			$this->Flujo_caja_m->where('id_caja', $data_request["id"])->delete();

			// DESVINCULAR CAJA DE OTROS PAGOS
			$data_null = [
				'id_caja' => null
			];

			$db->table('vale_pago')
			->update($data_null, ['id_caja' => $data_request["id"]]);

			$db->table('vale_combustible')
			->update($data_null, ['id_caja' => $data_request["id"]]);

			$db->table('mantenimiento_vehiculo')
			->update($data_null, ['id_caja' => $data_request["id"]]);

			/******** OTRAS VERIFICACIONES VINCULADAS DE CAJA */

			/****
			 * SI LA CAJA PERTENECE A UN PAGO DE REQUERIMIENTO DEBERÁ MOSTRARSE NUEVAMENTE EN PAGO DE REQUERIMIENTOS
			 */

			if($caja->motivo == 'ADELANTO VIAJE TERCERIZADO')
			{
				$data_viaje = [
					'id'									=> $caja->id_viaje,
					'fl_requerimiento_adelanto_tercerizado'	=> null
				];

				$this->Viaje_m->save($data_viaje);
			}
			else if($caja->motivo == 'FLETE VIAJE TERCERIZADO')
			{
				$data_viaje = [
					'id'									=> $caja->id_viaje,
					'fl_requerimiento_flete_tercerizado'	=> null
				];

				$this->Viaje_m->save($data_viaje);
			}
			else if($caja->motivo == 'ADELANTO SERVICIO ESCOLTA')
			{
				$data_viaje = [
					'id'									=> $caja->id_viaje,
					'fl_requerimiento_adelanto_escolta'		=> null
				];

				$this->Viaje_m->save($data_viaje);
			}

			else if($caja->motivo == 'SERVICIO ESCOLTA')
			{
				$data_viaje = [
					'id'									=> $caja->id_viaje,
					'fl_requerimiento_escolta'				=> null
				];

				$this->Viaje_m->save($data_viaje);
			}


			/****************** SAVE CENTINELA *****************/
			$caja = $this->Caja_m->find($data_request["id"]);

			$data_centinela = [
				'modulo'		=> 'TESORERIA',
				'menu'			=> 'CAJA',
				'accion'		=> 'ANULAR',
				'descripcion'	=> $caja->serie.'-'.$caja->numero
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
