<?php namespace App\Controllers\Tesoreria;

use App\Controllers\BaseController;

use App\Models\Operacion\Viaje_model;
use App\Models\Operacion\Vale_combustible_model;
use App\Models\Operacion\Mantenimiento_vehiculo_model;
use App\Models\Operacion\Vale_pago_model;
use App\Models\Tesoreria\Caja_model;
use App\Models\Configuracion\Proveedor_model;
use App\Models\Configuracion\Ajuste_avanzado_model;
use App\Models\Tesoreria\Flujo_caja_model;
use App\Models\Configuracion\Gasto_recurrente_model;

class Pago_requerimiento extends BaseController
{
	public function __construct()
	{
		$this->Ajuste_avanzado_m = new Ajuste_avanzado_model();
		$this->Viaje_m = new Viaje_model();
		$this->Caja_m = new Caja_model();
		$this->Flujo_caja_m = new Flujo_caja_model();
		$this->Vale_combustible_m = new Vale_combustible_model();
		$this->Mantenimiento_vehiculo_m = new Mantenimiento_vehiculo_model();
		$this->Vale_pago_m = new Vale_pago_model();
		$this->Gasto_recurrente_m = new Gasto_recurrente_model();
	}

	public function index()
	{		
		$data_request = $this->request->getGet();

		$ajuste = $this->Ajuste_avanzado_m->where('id_empresa', ID_EMPRESA)->first();

		$array_response = [];

		if($data_request["tipo_mostrar"] == '' or $data_request["tipo_mostrar"] == 'ADELANTO VIAJE TERCERIZADO')
		{
			/*** ADELANTO DE VIAJES */
			$adelanto = $this->Viaje_m->select('viaje.*, viaje.id as id_viaje')
			->select('p.razon_social as proveedor, p.id as id_proveedor')		
			->select('u.usuario')
			->select('m.simbolo as simbolo_moneda')
			->join('vehiculo v', 'v.id = viaje.id_vehiculo')
			->join('proveedor p', 'p.id = v.id_proveedor', 'left')
			->join('usuario u', 'u.id = viaje.id_usuario', 'left')
			->join('static_moneda m', 'm.id = viaje.id_moneda_tercerizado', 'left')
			->where('viaje.fl_requerimiento_adelanto_tercerizado', null)
			->where('viaje.monto_adelanto_tercerizado >', 0)		
			->where('viaje.fl_estado', 1)		
			->where('viaje.id_empresa', ID_EMPRESA)		
			->findAll();

			foreach ($adelanto as $row) {

				$adelantos_caja = $this->Caja_m->where('motivo', 'ADELANTO VIAJE TERCERIZADO')
				->where('fl_estado', 3)
				->where('id_viaje', $row->id_viaje)
				->findAll();

				$total_adelanto = 0;

				foreach ($adelantos_caja as $caja) {
					$total_adelanto = $total_adelanto + $caja->importe;
				}

				$importe = $row->monto_adelanto_tercerizado - $total_adelanto;

				if($importe > 0)
				{
					$array_response[] = [
						'tipo'							=> 'ADELANTO VIAJE TERCERIZADO',
						'fecha'							=> date("d/m/Y", strtotime($row->fecha)),
						'viaje'							=> $row->serie.'-'.$row->numero,
						'proveedor'						=> $row->proveedor,
						'id_proveedor'					=> $row->id_proveedor,
						'monto_adelanto_tercerizado'	=> $row->monto_adelanto_tercerizado,
						'costo_tercerizado'				=> $row->costo_tercerizado,
						'importe'						=> number_format($importe, 2, '.', ''),
						'id_viaje'						=> $row->id,
						'usuario'						=> $row->usuario,
						'id_caja'						=> '',
						'caja'							=> '',
						'simbolo_moneda'				=> $row->simbolo_moneda,
						'id_moneda'						=> $row->id_moneda_tercerizado,
						'descripcion'					=> 'VIAJE: '.$row->serie.'-'.$row->numero,
						'tipo_cambio'					=> $row->tipo_cambio_tercerizado,
						'dias_restantes'                => null,
					];
				}
				
			}
		}
		

		if($data_request["tipo_mostrar"] == '' or $data_request["tipo_mostrar"] == 'FLETE VIAJE TERCERIZADO')
		{
			/*** VIAJES TERCERIZADOS INICIADOS */
			$viajes = $this->Viaje_m->select('viaje.*')
			->select('p.razon_social as proveedor, p.id as id_proveedor')		
			->select('u.usuario')
			->select('m.simbolo as simbolo_moneda')
			->join('vehiculo v', 'v.id = viaje.id_vehiculo')
			->join('proveedor p', 'p.id = v.id_proveedor', 'left')
			->join('usuario u', 'u.id = viaje.id_usuario', 'left')
			->join('static_moneda m', 'm.id = viaje.id_moneda_tercerizado', 'left')
			->where('v.tipo_contratacion', 'TERCERO')
			->where('viaje.id_liquidacion_tercero', null)
			->where('viaje.fl_requerimiento_flete_tercerizado', null)
			->where('viaje.costo_tercerizado >', 0)		
			->where('viaje.fl_estado', 1)		
			->where('viaje.id_empresa', ID_EMPRESA)		
			->findAll();

			foreach ($viajes as $row) {

				$importe = $row->costo_tercerizado;
	

				if($ajuste->fl_tesoreria_pago_detraccion_no_descuento != 1)
				{
					/*** DESCUENTO DETRACCIÓN */
					$importe = $importe - ($importe * ($row->porc_detraccion_tercerizado / 100));
				}
				
				$importe = $importe - $row->monto_adelanto_tercerizado;

				$array_response[] = [
					'tipo'							=> 'FLETE VIAJE TERCERIZADO',
					'fecha'							=> date("d/m/Y", strtotime($row->fecha)),
					'viaje'							=> $row->serie.'-'.$row->numero,
					'id_viaje'						=> $row->id,
					'id_proveedor'					=> $row->id_proveedor,
					'proveedor'						=> $row->proveedor,				
					'monto_adelanto_tercerizado'	=> $row->monto_adelanto_tercerizado,
					'costo_tercerizado'				=> $row->costo_tercerizado,
					'importe'						=> number_format($importe, 2, '.', ''),				
					'id_orden'						=> $row->id,
					'usuario'						=> $row->usuario,
					'id_caja'						=> '',
					'caja'							=> '',
					'simbolo_moneda'				=> $row->simbolo_moneda,
					'id_moneda'						=> $row->id_moneda_tercerizado,
					'descripcion'					=> 'VIAJE: '.$row->serie.'-'.$row->numero,
					'tipo_cambio'					=> $row->tipo_cambio_tercerizado,
					'dias_restantes'                => null
				];
			}
		}
		

		if($data_request["tipo_mostrar"] == '' or $data_request["tipo_mostrar"] == 'CAJA')
		{
			/*** CAJAS APROBADAS */
			$caja = $this->Caja_m->select('caja.*, concat(caja.serie, "-", caja.numero) as caja')
			->select('coalesce(concat(v.serie, "-", v.numero), "") as viaje, v.id as id_viaje')
			->select('u.usuario')
			->select('p.razon_social as proveedor')	
			->select('m.simbolo as simbolo_moneda')
			->join('viaje v', 'v.id = caja.id_viaje', 'left')
			->join('vehiculo vh', 'vh.id = v.id_vehiculo', 'left')
			->join('proveedor p', 'p.id = vh.id_proveedor', 'left') 
			->join('usuario u', 'u.id = caja.id_usuario', 'left')
			->join('static_moneda m', 'm.id = caja.id_moneda', 'left')
			->where('caja.fl_estado', 2)		
			->where('caja.id_empresa', ID_EMPRESA)		
			->findAll();

			foreach ($caja as $row) {
				$array_response[] = [
					'tipo'							=> 'CAJA',
					'fecha'							=> date("d/m/Y", strtotime($row->fecha)),
					'caja'							=> $row->serie.'-'.$row->numero,
					'motivo_caja'					=> $row->motivo,
					'id_caja'						=> $row->id,
					'viaje'							=> $row->viaje,
					'proveedor'						=> $row->proveedor,
					'importe'						=> $row->importe,
					'monto_adelanto_tercerizado'	=> '',
					'costo_tercerizado'				=> '',
					'id_orden'						=> $row->id,
					'usuario'						=> $row->usuario,
					'id_viaje'						=> $row->id_viaje,
					'simbolo_moneda'				=> $row->simbolo_moneda,
					'id_moneda'						=> $row->id_moneda,
					'descripcion'					=> $row->motivo,
					'tipo_cambio'					=> $row->tipo_cambio,
					'dias_restantes'                => null
				];
			}
		}
		

		if($data_request["tipo_mostrar"] == '' or $data_request["tipo_mostrar"] == 'COMBUSTIBLE')
		{
			/**** VALES DE COMBUSTIBLE CRÉDITO */
			$vale_combustible = $this->Vale_combustible_m->select('vale_combustible.*')
			->select('p.razon_social as proveedor, p.id as id_proveedor')		
			->select('u.usuario')
			->select('m.simbolo as simbolo_moneda')
			->select('concat(vi.serie,"-",vi.numero) as viaje')
			->join('viaje vi', 'vi.id = vale_combustible.id_viaje', 'left')
			->join('vehiculo v', 'v.id = vale_combustible.id_vehiculo')
			->join('proveedor p', 'p.id = vale_combustible.id_proveedor', 'left')
			->join('usuario u', 'u.id = vale_combustible.id_usuario', 'left')
			->join('static_moneda m', 'm.id = vale_combustible.id_moneda', 'left')
			->where('vale_combustible.tipo_pago', 'CREDITO')
			->where('vale_combustible.fl_estado', 1)		
			->where('vale_combustible.id_caja', null)		
			->where('vale_combustible.id_empresa', ID_EMPRESA)		
			->findAll();

			foreach ($vale_combustible as $row) {
				$array_response[] = [
					'tipo'							=> 'COMBUSTIBLE',
					'fecha'							=> date("d/m/Y", strtotime($row->fecha)),
					'viaje'							=> $row->viaje,
					'proveedor'						=> $row->proveedor,
					'id_proveedor'					=> $row->id_proveedor,
					'monto_adelanto_tercerizado'	=> '',
					'costo_tercerizado'				=> '',
					'importe'						=> number_format($row->importe, 2, '.', ''),
					'id_viaje'						=> '',
					'usuario'						=> $row->usuario,
					'id_caja'						=> '',
					'caja'							=> '',
					'motivo_caja'					=> '',
					'simbolo_moneda'				=> $row->simbolo_moneda,
					'id_moneda'						=> $row->id_moneda,
					'id_vale_combustible'			=> $row->id,
					'descripcion'					=> 'VALDE DE COMBUSTIBLE: '.$row->serie.'-'.$row->numero,
					'tipo_cambio'					=> $row->tipo_cambio,
					'dias_restantes'                => $this->Helper->dias_restantes($row->fecha, $row->dias_credito)
				];
			}
		}
		

		if($data_request["tipo_mostrar"] == '' or $data_request["tipo_mostrar"] == 'VALE PAGO')
		{
			/**** VALES DE PAGO CRÉDITO */
			$vale_pago = $this->Vale_pago_m->select('vale_pago.*')
			->select('p.razon_social as proveedor, p.id as id_proveedor')		
			->select('u.usuario')
			->select('m.simbolo as simbolo_moneda')
			->select('concat(vi.serie,"-",vi.numero) as viaje')
			->join('viaje vi', 'vi.id = vale_pago.id_viaje', 'left')
			->join('vehiculo v', 'v.id = vale_pago.id_vehiculo')
			->join('proveedor p', 'p.id = vale_pago.id_proveedor', 'left')
			->join('usuario u', 'u.id = vale_pago.id_usuario', 'left')
			->join('static_moneda m', 'm.id = vale_pago.id_moneda', 'left')
			->where('vale_pago.tipo_pago', 'CREDITO')
			->where('vale_pago.fl_estado', 1)		
			->where('vale_pago.id_caja', null)		
			->where('vale_pago.id_empresa', ID_EMPRESA)		
			->findAll();

			foreach ($vale_pago as $row) {
				$array_response[] = [
					'tipo'							=> 'VALE PAGO',
					'fecha'							=> date("d/m/Y", strtotime($row->fecha)),
					'viaje'							=> $row->viaje,
					'proveedor'						=> $row->proveedor,
					'id_proveedor'					=> $row->id_proveedor,
					'monto_adelanto_tercerizado'	=> '',
					'costo_tercerizado'				=> '',
					'importe'						=> number_format($row->importe, 2, '.', ''),
					'id_viaje'						=> '',
					'usuario'						=> $row->usuario,
					'id_caja'						=> '',
					'caja'							=> '',
					'motivo_caja'					=> '',
					'simbolo_moneda'				=> $row->simbolo_moneda,
					'id_moneda'						=> $row->id_moneda,
					'id_vale_pago'					=> $row->id,
					'descripcion'					=> 'VALE DE PAGO: '.$row->serie.'-'.$row->numero,
					'tipo_cambio'					=> $row->tipo_cambio,
					'dias_restantes'                => $this->Helper->dias_restantes($row->fecha, $row->dias_credito),
					'porcentaje_detraccion'			=> $row->porcentaje_detraccion
				];
			}
		}
		

		if($data_request["tipo_mostrar"] == '' or $data_request["tipo_mostrar"] == 'MANTENIMIENTO VEHICULO')
		{
			/**** MANTENIMIENTO VEHICULO CRÉDITO */
			$mantenimiento_vehiculo = $this->Mantenimiento_vehiculo_m->select('mantenimiento_vehiculo.*')
			->select('p.razon_social as proveedor, p.id as id_proveedor')		
			->select('u.usuario')
			->select('m.simbolo as simbolo_moneda')
			->join('vehiculo v', 'v.id = mantenimiento_vehiculo.id_vehiculo')
			->join('proveedor p', 'p.id = mantenimiento_vehiculo.id_proveedor', 'left')
			->join('usuario u', 'u.id = mantenimiento_vehiculo.id_usuario', 'left')
			->join('static_moneda m', 'm.id = mantenimiento_vehiculo.id_moneda', 'left')
			->where('mantenimiento_vehiculo.tipo_pago', 'CREDITO')
			->where('mantenimiento_vehiculo.id_caja', null)		
			->where('mantenimiento_vehiculo.id_empresa', ID_EMPRESA)		
			->findAll();

			foreach ($mantenimiento_vehiculo as $row) {

				$array_response[] = [
					'tipo'							=> 'MANTENIMIENTO VEHICULO',
					'fecha'							=> date("d/m/Y", strtotime($row->fecha)),
					'viaje'							=> '-',
					'proveedor'						=> $row->proveedor,
					'id_proveedor'					=> $row->id_proveedor,
					'monto_adelanto_tercerizado'	=> '',
					'costo_tercerizado'				=> '',
					'importe'						=> number_format($row->costo, 2, '.', ''),
					'id_viaje'						=> '',
					'usuario'						=> $row->usuario,
					'id_caja'						=> '',
					'caja'							=> '',
					'motivo_caja'					=> '',
					'simbolo_moneda'				=> $row->simbolo_moneda,
					'id_moneda'						=> $row->id_moneda,
					'id_mantenimiento_vehiculo'		=> $row->id,
					'descripcion'					=> $row->tipo.' '.$row->mantenimiento,
					'tipo_cambio'					=> $row->tipo_cambio,
					'dias_restantes'                => $this->Helper->dias_restantes($row->fecha, $row->dias_credito)
				];

			}
		}


		if($data_request["tipo_mostrar"] == '' or $data_request["tipo_mostrar"] == 'GASTO RECURRENTE')
		{
			/**** GASTOS RECURRENTES */
			$gastos_recurrentes = $this->Gasto_recurrente_m->select('gasto_recurrente.*')
			->select('coalesce(p.razon_social, "") as proveedor')
			->select('coalesce(u.usuario, "") as usuario')
			->select('m.simbolo as simbolo_moneda, m.tipo_cambio')
			->join('proveedor p', 'p.id = gasto_recurrente.id_proveedor', 'left')
			->join('usuario u', 'u.id = gasto_recurrente.id_usuario', 'left')
			->join('static_moneda m', 'm.id = gasto_recurrente.id_moneda', 'left')
			->where('gasto_recurrente.fl_estado', 1)
			->where('gasto_recurrente.id_empresa', ID_EMPRESA)
			->findAll();

			foreach ($gastos_recurrentes as $row) {

				$mostrar_pago = false;

				$ultimo_pago = $this->Caja_m->select('fecha')
				->where('fl_estado', 3)
				->where('id_gasto_recurrente', $row->id)
				->orderBy('fecha', 'desc')
				->first();

				switch ($row->tipo_recurrencia) {
					case 'SOLO UNA VEZ':

						$fecha_pagar = $row->fecha_pago;									

					break;
					
					case 'MENSUAL':						

						if(is_object($ultimo_pago))
						{
							$fecha_exp = explode('-', $ultimo_pago->fecha);
							$fecha_pago = explode('-', $row->fecha_pago);

							$fecha_ultimo_pago = $fecha_pago[0].'-'.$fecha_exp[1].'-'.$fecha_exp[2];

							$fecha_pagar = date("d-m-Y",strtotime($fecha_ultimo_pago."+ 1 month")); 
						}
						else
						{
							$fecha_pagar = $row->fecha_pago;
						}
						
					break;

					case 'ANUAL':
						
						if(is_object($ultimo_pago))
						{
							$fecha_exp = explode('-', $ultimo_pago->fecha);
							$fecha_pago = explode('-', $row->fecha_pago);

							$fecha_ultimo_pago = $fecha_pago[0].'-'.$fecha_exp[1].'-'.$fecha_exp[2];

							$fecha_pagar = date("d-m-Y",strtotime($fecha_ultimo_pago."+ 1 year")); 
						}
						else
						{
							$fecha_pagar = $row->fecha_pago;
						}

					break;
				}

				$dias_restantes = $this->Helper->dias_restantes($fecha_pagar, 0);			

				$array_response[] = [
					'tipo'							=> 'GASTO RECURRENTE',
					'fecha'							=> date("d/m/Y", strtotime($row->fecha_pago)),
					'viaje'							=> '-',
					'proveedor'						=> $row->proveedor,
					'id_proveedor'					=> $row->id_proveedor,
					'monto_adelanto_tercerizado'	=> '',
					'costo_tercerizado'				=> '',
					'importe'						=> number_format($row->importe, 2, '.', ''),
					'id_viaje'						=> '',
					'usuario'						=> $row->usuario,
					'id_caja'						=> '',
					'caja'							=> '',
					'motivo_caja'					=> '',
					'simbolo_moneda'				=> $row->simbolo_moneda,
					'id_moneda'						=> $row->id_moneda,
					'id_mantenimiento_vehiculo'		=> $row->id,
					'descripcion'					=> $row->nombre,
					'tipo_cambio'					=> $row->tipo_cambio,
					'dias_restantes'                => $dias_restantes,
					'id_gasto_recurrente'			=> $row->id,
					'tipo_recurrencia'				=> $row->tipo_recurrencia
				];
			}
		}

		if($data_request["tipo_mostrar"] == '' or $data_request["tipo_mostrar"] == 'ADELANTO SERVICIO ESCOLTA')
		{
			/*** ADELANTO DE VIAJES */
			$adelanto = $this->Viaje_m->select('viaje.*, viaje.id as id_viaje')
			->select('p.razon_social as proveedor, p.id as id_proveedor')		
			->select('u.usuario')
			->select('m.simbolo as simbolo_moneda')
			->join('proveedor p', 'p.id = viaje.id_proveedor_escolta', 'left')
			->join('usuario u', 'u.id = viaje.id_usuario', 'left')
			->join('static_moneda m', 'm.id = viaje.id_moneda_escolta', 'left')
			->where('viaje.fl_requerimiento_adelanto_escolta', null)
			->where('viaje.monto_adelanto_escolta >', 0)		
			->where('viaje.fl_estado', 1)		
			->where('viaje.id_empresa', ID_EMPRESA)		
			->findAll();

			foreach ($adelanto as $row) {

				$adelantos_caja = $this->Caja_m->where('motivo', 'ADELANTO SERVICIO ESCOLTA')
				->where('fl_estado', 3)
				->where('id_viaje', $row->id_viaje)
				->findAll();

				$total_adelanto = 0;

				foreach ($adelantos_caja as $caja) {
					$total_adelanto = $total_adelanto + $caja->importe;
				}

				$importe = $row->monto_adelanto_escolta - $total_adelanto;

				if($importe > 0)
				{
					$array_response[] = [
						'tipo'							=> 'ADELANTO SERVICIO ESCOLTA',
						'fecha'							=> date("d/m/Y", strtotime($row->fecha)),
						'viaje'							=> $row->serie.'-'.$row->numero,
						'proveedor'						=> $row->proveedor,
						'id_proveedor'					=> $row->id_proveedor,
						'monto_adelanto_tercerizado'	=> $row->monto_adelanto_escolta,
						'costo_tercerizado'				=> $row->costo_escolta,
						'importe'						=> number_format($importe, 2, '.', ''),
						'id_viaje'						=> $row->id,
						'usuario'						=> $row->usuario,
						'id_caja'						=> '',
						'caja'							=> '',
						'simbolo_moneda'				=> $row->simbolo_moneda,
						'id_moneda'						=> $row->id_moneda_escolta,
						'descripcion'					=> 'VIAJE: '.$row->serie.'-'.$row->numero,
						'tipo_cambio'					=> $row->tipo_cambio_escolta,
						'dias_restantes'                => null,
					];
				}
				
			}
		}
		

		if($data_request["tipo_mostrar"] == '' or $data_request["tipo_mostrar"] == 'SERVICIO ESCOLTA')
		{
			/*** VIAJES TERCERIZADOS INICIADOS */
			$viajes = $this->Viaje_m->select('viaje.*')
			->select('p.razon_social as proveedor, p.id as id_proveedor')		
			->select('u.usuario')
			->select('m.simbolo as simbolo_moneda')
			->join('proveedor p', 'p.id = viaje.id_proveedor_escolta', 'left')
			->join('usuario u', 'u.id = viaje.id_usuario', 'left')
			->join('static_moneda m', 'm.id = viaje.id_moneda_escolta', 'left')
			->where('viaje.id_liquidacion_escolta', null)
			->where('viaje.fl_requerimiento_escolta', null)
			->where('viaje.costo_escolta >', 0)		
			->where('viaje.fl_estado', 1)		
			->where('viaje.id_empresa', ID_EMPRESA)		
			->findAll();

			foreach ($viajes as $row) {

				$importe = $row->costo_escolta;

				if($row->mas_inc_igv_escolta == 'MAS_IGV')
				{						
					$total_igv =  $row->costo_escolta * (($ajuste->porcentaje_igv / 100));
					$importe = $row->costo_escolta + $total_igv;
				}		
				
				$importe_real = $importe;

				if($ajuste->fl_tesoreria_pago_detraccion_no_descuento != 1)
				{
					/*** DESCUENTO DETRACCIÓN */
					$importe = $importe - ($importe * ($row->porc_detraccion_tercerizado / 100));
				}
				
				$importe = $importe - $row->monto_adelanto_escolta;

				$array_response[] = [
					'tipo'							=> 'SERVICIO ESCOLTA',
					'fecha'							=> date("d/m/Y", strtotime($row->fecha)),
					'viaje'							=> $row->serie.'-'.$row->numero,
					'id_viaje'						=> $row->id,
					'id_proveedor'					=> $row->id_proveedor,
					'proveedor'						=> $row->proveedor,				
					'monto_adelanto_tercerizado'	=> $row->monto_adelanto_escolta,
					'costo_tercerizado'				=> $row->costo_escolta,
					'importe'						=> number_format($importe, 2, '.', ''),				
					'id_orden'						=> $row->id,
					'usuario'						=> $row->usuario,
					'id_caja'						=> '',
					'caja'							=> '',
					'simbolo_moneda'				=> $row->simbolo_moneda,
					'id_moneda'						=> $row->id_moneda_escolta,
					'descripcion'					=> 'VIAJE: '.$row->serie.'-'.$row->numero,
					'tipo_cambio'					=> $row->tipo_cambio_escolta,
					'dias_restantes'                => null,
					'porcentaje_detraccion'			=> $row->porc_detraccion_escolta,
					'importe_real'					=> $importe_real
				];
			}
		}
		

		return $this->respond(['data' => $array_response], 200);
	}

	public function proceder()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('tesoreria-pago_requerimiento', 'edit');

		try {

			$db = \Config\Database::connect();
			$db->query('SET AUTOCOMMIT = 0');
			$db->transStart();
			$db->query('LOCK TABLES caja write, centinela write, flujo_caja write');

			/** GUARDAR */
			$data = [
				'id'			=> $data_request["id_caja"],
				'fl_estado'		=> 3,
			];


			$this->Caja_m->save($data);

			$id_caja = $data_request["id_caja"];

			$caja = $this->Caja_m->find($data_request["id_caja"]);

			/** SAVE FLUJO CAJA */
			$this->Flujo_caja_m->where('id_caja', $id_caja)->delete();

			$data =  [
				'fecha'       					=> $caja->fecha,
				'tipo'        					=> 'EGRESO',
				'descripcion' 					=> $caja->descripcion,
				'id_caja'						=> $id_caja,
				'id_usuario'  					=> $caja->id_usuario,
				'id_empresa' 					=> $caja->id_empresa,
				'id_cuenta_bancaria_empresa'   	=> $caja->id_cuenta_bancaria_empresa,
				'monto'       					=> $caja->importe
			];

			$this->Flujo_caja_m->save($data);


			/****************** SAVE CENTINELA *****************/		

			$data_centinela = [
				'modulo'		=> 'TESORERIA',
				'menu'			=> 'PAGO DE REQUERIMIENTOS',
				'accion'		=> 'PROCEDER',
				'descripcion'	=> $data_request["descripcion"]
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */

			$db->query('UNLOCK TABLES');
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente', 'id_caja' => $id_caja], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function save_caja()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('tesoreria-pago_requerimiento', 'edit');

		try {

			$db = \Config\Database::connect();
			$db->query('SET AUTOCOMMIT = 0');
			$db->transStart();
			$db->query('LOCK TABLES caja write,  flujo_caja write, centinela write, liquidacion_gasto_operativo read, proveedor read, viaje write, vale_combustible write, vale_pago write, mantenimiento_vehiculo write, ajuste_avanzado read, gasto_recurrente write');

			$Proveedor_m = new Proveedor_model();
			$proveedor = $Proveedor_m->find($data_request["id_proveedor"]);

			$data_request_json = json_decode($data_request["data_json"]);

			/*** VERIFICAR TIPO DE CAMBIO DE MONEDA */
			$tipo_cambio = (isset($data_request_json->tipo_cambio) && is_numeric($data_request_json->tipo_cambio)) ? $data_request_json->tipo_cambio : null;

			/** GUARDAR */
			$data = [
				'fecha'							=> $data_request["fecha"],
				'id_viaje'						=> ($data_request["id_viaje"] != '') ? $data_request["id_viaje"] : null,
				'tipo_persona'					=> 'PROVEEDOR',
				'id_tipo_persona'				=> $data_request["id_proveedor"],
				'nombre_persona'				=> $proveedor->razon_social,
				'motivo'						=> $data_request["motivo"],
				'id_moneda'						=> $data_request["id_moneda"],
				'tipo_cambio'					=> $tipo_cambio,
				'descripcion'					=> $data_request["descripcion"],
				'modalidad'						=> $data_request["modalidad"],
				'importe'						=> $data_request["importe"],
				'cuenta_bancaria_persona'		=> (isset($data_request["cuenta_bancaria_persona"])) ? trim($data_request["cuenta_bancaria_persona"]) : null,
				'titular_cuenta'				=> (isset($data_request["titular_cuenta"])) ? trim($data_request["titular_cuenta"]) : null,
				'id_cuenta_bancaria_empresa'	=> ($data_request["id_cuenta_bancaria_empresa"] != '') ? trim($data_request["id_cuenta_bancaria_empresa"]) : null,
				'id_cuenta_bancaria_persona'	=> (isset($data_request["id_cuenta_bancaria_persona"])) ? trim($data_request["id_cuenta_bancaria_persona"]): null,
				'id_gasto_recurrente'			=> (isset($data_request_json->id_gasto_recurrente)) ? $data_request_json->id_gasto_recurrente : null,

				'id_cuenta_bancaria_detraccion_persona'	=> (isset($data_request["id_cuenta_bancaria_detraccion_persona"])) ? trim($data_request["id_cuenta_bancaria_detraccion_persona"]): null,
				'monto_detraccion'						=> (isset($data_request["id_cuenta_bancaria_detraccion_persona"])) ?  $data_request["monto_detraccion"] : null,
				'porcentaje_detraccion'					=> (isset($data_request["id_cuenta_bancaria_detraccion_persona"])) ?  $data_request["porcentaje_detraccion"] : null,
			];

			$correlativo = $this->Caja_m->get_correlativo();

			$data["serie"] = $correlativo->serie;
			$data["numero"] = $correlativo->numero;
			$data["tipo"] = 'CAJA';
			$data["fl_estado"] = 3;
			$data["id_empresa"] = ID_EMPRESA;
			$data["id_usuario"] = ID_USUARIO;

			$this->Caja_m->save($data);

			$id_caja = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			/** SAVE FLUJO CAJA */
			$this->Flujo_caja_m->where('id_caja', $id_caja)->delete();

			$data =  [
				'fecha'       					=> $data_request["fecha"],
				'tipo'        					=> 'EGRESO',
				'descripcion' 					=> $data_request["descripcion"],
				'id_caja'						=> $id_caja,
				'id_usuario'  					=> ID_USUARIO,
				'id_empresa' 					=> ID_EMPRESA,
				'id_cuenta_bancaria_empresa'   	=> ($data_request["id_cuenta_bancaria_empresa"] != '') ? $data_request["id_cuenta_bancaria_empresa"] : null,
				'monto'       					=> $data_request["importe"],
				'id_moneda'						=> $data_request["id_moneda"],
				'tipo_cambio'					=> $tipo_cambio
			];

			$this->Flujo_caja_m->save($data);

			/********** CONDICIONALES SEGÚN TIPO DE REQUERIMIENTO */

			if($data_request["id_viaje"] != '')
			{
				if($data_request["tipo"] == 'ADELANTO VIAJE TERCERIZADO')
				{
					/**** ACTUALIZAR VIAJE REQUERIMIENTO SI */			
					$data_viaje = [
						'id'      								=> $data_request["id_viaje"],
						'fl_requerimiento_adelanto_tercerizado'	=> 1,
					];

					$this->Viaje_m->save($data_viaje);
				}	
				else if($data_request["tipo"] == 'FLETE VIAJE TERCERIZADO')
				{
					/**** ACTUALIZAR VIAJE REQUERIMIENTO SI */			
					$data_viaje = [
						'id'      								=> $data_request["id_viaje"],
						'fl_requerimiento_flete_tercerizado'	=> 1,
					];

					$this->Viaje_m->save($data_viaje);
				}
				else if($data_request["tipo"] == 'ADELANTO SERVICIO ESCOLTA')
				{
					/**** ACTUALIZAR VIAJE REQUERIMIENTO SI */			
					$data_viaje = [
						'id'      								=> $data_request["id_viaje"],
						'fl_requerimiento_adelanto_escolta'		=> 1,
					];

					$this->Viaje_m->save($data_viaje);
				}	
				else if($data_request["tipo"] == 'SERVICIO ESCOLTA')
				{
					/**** ACTUALIZAR VIAJE REQUERIMIENTO SI */			
					$data_viaje = [
						'id'      								=> $data_request["id_viaje"],
						'fl_requerimiento_escolta'	=> 1,
					];

					$this->Viaje_m->save($data_viaje);
				}	
			}
			else
			{
				/*** VINCULACIÓN DE CAJA */

				if($data_request["tipo"] == 'COMBUSTIBLE')
				{		
					$data_viaje = [
						'id'      	=> $data_request_json->id_vale_combustible,
						'id_caja'	=> $id_caja,
					];

					$this->Vale_combustible_m->save($data_viaje);
				}
				else if($data_request["tipo"] == 'VALE PAGO')
				{	
					$data_viaje = [
						'id'      	=> $data_request_json->id_vale_pago,
						'id_caja'	=> $id_caja,
					];

					$this->Vale_pago_m->save($data_viaje);
				}
				else if($data_request["tipo"] == 'MANTENIMIENTO VEHICULO')
				{		
					$data_viaje = [
						'id'      	=> $data_request_json->id_mantenimiento_vehiculo,
						'id_caja'	=> $id_caja,
					];

					$this->Mantenimiento_vehiculo_m->save($data_viaje);
				}
				else if($data_request["tipo"] == 'GASTO RECURRENTE')
				{		
					if($data_request_json->tipo_recurrencia == 'SOLO UNA VEZ')
					{
						$data_update = [
							'id'      	=> $data_request_json->id_gasto_recurrente,
							'fl_estado'	=> 0,
						];
	
						$this->Gasto_recurrente_m->save($data_update);
					}
					
				}
				
			}

			/****************** SAVE CENTINELA *****************/
			$caja = $this->Caja_m->find($id_caja);

			$data_centinela = [
				'modulo'		=> 'TESORERIA',
				'menu'			=> 'PAGO DE REQUERIMIENTOS',
				'accion'		=> 'PROCEDER',
				'descripcion'	=> $data_request["descripcion"]
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */

			$db->query('UNLOCK TABLES');
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente', 'id_caja' => $id_caja], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

		
}
