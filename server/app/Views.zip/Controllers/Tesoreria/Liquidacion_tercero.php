<?php namespace App\Controllers\Tesoreria;

use App\Controllers\BaseController;
use App\Models\Tesoreria\Liquidacion_tercero_model;
use App\Models\Tesoreria\Liquidacion_tercero_detalle_model;
use App\Models\Operacion\Viaje_model;
use App\Models\Tesoreria\Caja_model;
use App\Models\Operacion\Gasto_operativo_model;
use App\Models\Operacion\Orden_model;
use App\Models\Operacion\Viaje_guia_model;
use App\Models\Operacion\Viaje_orden_model;
use App\Models\Configuracion\Empresa_model;
use App\Models\Configuracion\Cuenta_bancaria_persona_model;
use App\Models\Configuracion\Ajuste_avanzado_model;

class Liquidacion_tercero extends BaseController
{
	public function __construct()
	{
		$this->Liquidacion_tercero_m = new Liquidacion_tercero_model();
		$this->Liquidacion_tercero_detalle_m = new Liquidacion_tercero_detalle_model();
		$this->Viaje_m = new Viaje_model();
		$this->Viaje_orden_m = new Viaje_orden_model();
		$this->Caja_m = new Caja_model();
		$this->Gasto_operativo_m = new Gasto_operativo_model();
		$this->Empresa_m = new Empresa_model();
		$this->Orden_m = new Orden_model();
		$this->Viaje_guia_m = new Viaje_guia_model();
		$this->Cuenta_bancaria_persona_m = new Cuenta_bancaria_persona_model();
		$this->Ajuste_avanzado_m = new Ajuste_avanzado_model();
	}

	public function print($id_liquidacion_tercero)
	{
		$response = $this->Liquidacion_tercero_m->select('liquidacion_tercero.*')
		->select('concat(v.serie, "-", v.numero) as viaje')
		->select('vh.placa as vehiculo')
		->select('coalesce(vs.placa, "") as remolque')
		->select('p.razon_social as proveedor, p.numero_documento as numero_documento_proveedor')
		->select('dp.nombre as documento_proveedor')
		->select('m.nombre as moneda, m.simbolo as simbolo_moneda')
		->join('viaje v', 'v.id = liquidacion_tercero.id_viaje', 'left')
		->join('vehiculo vh', 'vh.id = v.id_vehiculo', 'left')
		->join('vehiculo vs', 'vs.id = v.id_remolque', 'left')
		->join('proveedor p', 'p.id = vh.id_proveedor', 'left')
		->join('static_documento dp', 'dp.id = p.id_documento', 'left')
		->join('static_moneda m', 'm.id = v.id_moneda_tercerizado', 'left')
		->where('liquidacion_tercero.id', $id_liquidacion_tercero)
		->first();

		$response->detalle = $this->Liquidacion_tercero_detalle_m->where('id_liquidacion_tercero', $response->id)->findAll();
		$response->empresa = $this->Empresa_m->find(ID_EMPRESA);

		return $this->respond($response, 200);
	}

	public function get_liquidar($id_viaje)
	{		
		$data_request = $this->request->getGet();	
		
		if(isset($data_request["porcentaje_detraccion"]) && !is_numeric($data_request["porcentaje_detraccion"]))
		{
			$data_request["porcentaje_detraccion"] = 0;
		}
		
		$response = $this->Viaje_m->select('lg.*,')
		->select('concat(viaje.serie, "-", viaje.numero) as viaje, viaje.id as id_viaje, viaje.costo_tercerizado, viaje.mas_inc_igv_tercerizado, viaje.porc_detraccion_tercerizado, viaje.numero_factura_tercero, viaje.serie_factura_tercero, viaje.id_moneda_tercerizado')
		->select('p.nombre_completo as conductor, p.id as id_conductor')
		->select('lg.id as id_liquidacion_tercero')
		->select('v.placa as vehiculo, v.id_proveedor')
		->select('coalesce(vs.placa, "") as remolque')
		->select('pr.razon_social as razon_social_proveedor, pr.numero_documento as numero_documento_proveedor')
		->select('m.simbolo as simbolo_moneda')
		->join('liquidacion_tercero lg', 'lg.id = viaje.id_liquidacion_tercero', 'left')
		->join('personal p', 'p.id = viaje.id_conductor', 'left')
		->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
		->join('vehiculo vs', 'vs.id = viaje.id_remolque', 'left')
		->join('proveedor pr', 'pr.id = v.id_proveedor', 'left')
		->join('static_moneda m', 'm.id = viaje.id_moneda_tercerizado')
		->where('viaje.id', $id_viaje)
		->where("v.tipo_contratacion", 'TERCERO')
		->where('viaje.fl_estado', 1)
		->first();		


		$porcentaje_detraccion = (isset($data_request["porcentaje_detraccion"])) ? $data_request["porcentaje_detraccion"] : $response->porc_detraccion_tercerizado;
		
		/** AJUSTE AVANZADO */
		$ajuste = $this->Ajuste_avanzado_m->where('id_empresa', ID_EMPRESA)->first();

		$response->ajuste = $ajuste;

		/*** GASTOS OPERATIVOS */		
		$detalle_gasto_operativo = $this->Caja_m->select('caja.*,')
		->select('m.simbolo as simbolo_moneda')
		->select('coalesce(caja.tipo_cambio, "") as tipo_cambio')
		->join('static_moneda m', 'm.id = caja.id_moneda')
		->where('id_viaje', $id_viaje)		
		->where('fl_estado', 3)
		->where('fl_no_liquidacion_viaje', null)
		->where('motivo', 'GASTOS OPERATIVOS')
		->findAll();

		$response->detalle_gasto_operativo = $detalle_gasto_operativo;

		$total_gasto_operativo = 0;
		
		foreach ($detalle_gasto_operativo as $deta) {

			$total_gasto_operativo = $total_gasto_operativo + $deta->importe;
			
		}		

		$response->total_gasto_operativo = number_format($total_gasto_operativo, 2, '.', '');

		/*** ADELANTOS */		
		$detalle_adelanto = $this->Caja_m->select('caja.*,')
		->select('m.simbolo as simbolo_moneda')
		->select('coalesce(caja.tipo_cambio, "") as tipo_cambio')
		->join('static_moneda m', 'm.id = caja.id_moneda')
		->where('id_viaje', $id_viaje)
		->where('fl_estado', 3)
		->where('motivo', 'ADELANTO VIAJE TERCERIZADO')
		->findAll();

		$response->detalle_adelanto = $detalle_adelanto;

		$total_adelanto = 0;
		
		foreach ($detalle_adelanto as $deta) {
			$total_adelanto = $total_adelanto + $deta->importe;
		}		

		$response->total_adelanto = number_format($total_adelanto, 2, '.', '');

		/** PAGO SERVICIO TERCERIZADO */
		$response->pago_flete = $this->Caja_m->where('id_viaje', $id_viaje)
		->where('fl_estado', 3)
		->where('motivo', 'FLETE VIAJE TERCERIZADO')
		->orderBy('id', 'desc')
		->first();

		$response->ordenes = $this->Viaje_orden_m->select('concat(orden.serie,"-",orden.numero) as numero, orden.fecha, orden.tipo_carga')
		->select('coalesce(c.razon_social, "") as cliente')
		->select('concat(r.punto_inicio," - ",r.punto_final) as ruta')
		->select('coalesce(concat(f.serie,"-",f.numero), "") as factura')
		->join('orden', 'orden.id = viaje_orden.id_orden', 'left')
		->join('cliente c', 'c.id = orden.id_cliente', 'left')
		->join('ruta r', 'r.id = orden.id_ruta', 'left')
		->join('factura f', 'f.id = orden.id_factura', 'left')
		->where('id_viaje', $id_viaje)
		->where('orden.fl_estado', 1)
		->findAll();

		$response->guia_transportista = $this->Viaje_guia_m->where('id_viaje', $id_viaje)
		->where('tipo', 'TRANSPORTISTA')
		->findAll();

		$response->bancos_proveedor = $this->Cuenta_bancaria_persona_m->where('id_proveedor', $response->id_proveedor)
		->where('fl_detraccion', 1)
		->findAll();		
		
	

		/** CALCULO IMPORTE */
		$response->total_igv = 0;

		if($response->mas_inc_igv_tercerizado == 'MAS_IGV')
		{						
			$response->total_servicio = $response->costo_tercerizado;
			$monto_base = $response->costo_tercerizado;

			$total_igv =  $response->costo_tercerizado * (($ajuste->porcentaje_igv / 100));
			$importe = $monto_base + $total_igv;
		}		
		else
		{
			
			$monto_base = $response->costo_tercerizado / (($ajuste->porcentaje_igv / 100) + 1);
			$response->total_servicio = $monto_base;

			$total_igv =  $response->costo_tercerizado - $monto_base;

			$importe = $response->costo_tercerizado;
			
		}	
		
		$response->total_servicio = number_format($response->total_servicio, 2, '.', '');
		
		$response->total_igv = $importe - $monto_base;		
		$response->total_igv = number_format($response->total_igv, 2, '.', '');

		$response->total_detraccion = $importe * ($porcentaje_detraccion / 100);		
		$response->total_detraccion = number_format($response->total_detraccion, 2, '.', '');

		$response->porcentaje_detraccion = $porcentaje_detraccion;
		
		if($ajuste->fl_tesoreria_liq_tercero_desc_detrac == 1)
		{
			$importe = $importe - $response->total_detraccion;
		}		

		$total_importe =  ($importe - $total_adelanto) + $total_gasto_operativo;
		
		$response->total_importe = number_format($total_importe, 2, '.', '');

		return $this->respond($response, 200);
	}

	public function index()
	{		
		$data_request = $this->request->getGet();		

		if($data_request["tipo"] == 'SIN_LIQUIDAR')
		{
			$response = $this->Viaje_m->select('lg.*,')
			->select('concat(viaje.serie, "-", viaje.numero) as viaje, viaje.id as id_viaje, viaje.costo_tercerizado, viaje.serie_factura_tercero, viaje.numero_factura_tercero')
			->select('p.nombre_completo as conductor, p.id as id_conductor')
			->select('lg.id as id_liquidacion_tercero')
			->select('v.placa as vehiculo')
			->select('coalesce(vs.placa, "") as remolque')
			->select('pr.razon_social as razon_social_proveedor, pr.numero_documento as numero_documento_proveedor')
			->join('liquidacion_tercero lg', 'lg.id = viaje.id_liquidacion_tercero', 'left')
			->join('personal p', 'p.id = viaje.id_conductor', 'left')
			->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
			->join('vehiculo vs', 'vs.id = viaje.id_remolque', 'left')
			->join('proveedor pr', 'pr.id = v.id_proveedor', 'left');

			
			$response->where("lg.fl_estado", null)
			->where("v.tipo_contratacion", 'TERCERO')
			->where('viaje.fl_estado', 1);
		}
		else
		{
			$response = $this->Liquidacion_tercero_m->select('liquidacion_tercero.*,')
			->select('concat(viaje.serie, "-", viaje.numero) as viaje, viaje.id as id_viaje, viaje.serie_factura_tercero')
			->select('p.nombre_completo as conductor, p.id as id_conductor')
			->select('liquidacion_tercero.id as id_liquidacion_tercero')
			->select('v.placa as vehiculo')
			->select('coalesce(vs.placa, "") as remolque')
			->select('pr.razon_social as razon_social_proveedor, pr.numero_documento as numero_documento_proveedor')
			->join('viaje', 'viaje.id = liquidacion_tercero.id_viaje', 'left')
			->join('personal p', 'p.id = viaje.id_conductor', 'left')
			->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
			->join('vehiculo vs', 'vs.id = viaje.id_remolque', 'left')
			->join('proveedor pr', 'pr.id = v.id_proveedor', 'left');

			$response->where('DATE_FORMAT(liquidacion_tercero.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
			->where('DATE_FORMAT(liquidacion_tercero.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"]);
		}

		$response = $response->where('viaje.id_empresa', ID_EMPRESA)		
		->findAll();

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('tesoreria-liquidacion_tercero', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('tesoreria-liquidacion_tercero', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			/** GUARDAR */
			$data = [
				'fecha' 					=> trim($data_request["fecha"]),
				'id_viaje'					=> trim($data_request["id_viaje"]),
				'id_conductor'				=> trim($data_request["id_conductor"]),
				'modalidad_pago'			=> trim($data_request["modalidad_pago"]),
				'referencia_pago'			=> trim($data_request["referencia_pago"]),
				'numero_factura'			=> trim($data_request["numero_factura"]),
				'serie_factura'				=> trim($data_request["serie_factura"]),
				'total_servicio'			=> trim($data_request["total_servicio"]),
				'total_gasto_operativo'		=> trim($data_request["total_gasto_operativo"]),
				'total_importe'				=> trim($data_request["total_importe"]),
				'total_detraccion'			=> trim($data_request["total_detraccion"]),
				'total_igv'					=> trim($data_request["total_igv"]),
				'total_adelanto'			=> trim($data_request["total_adelanto"]),
				'observacion'				=> trim($data_request["observacion"]),

				'porcentaje_detraccion'		=> ($data_request["porcentaje_detraccion"] == '') ? 0 : trim($data_request["porcentaje_detraccion"]),
				'fecha_detraccion'			=> (isset($data_request["fecha_detraccion"])) ? trim($data_request["fecha_detraccion"]) : '',
				'banco_detraccion'			=> (isset($data_request["banco_detraccion"])) ? trim($data_request["banco_detraccion"]) : '',

				'bien_servicio'				=> trim($data_request["bien_servicio"]),
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$correlativo = $this->Liquidacion_tercero_m->get_correlativo(date("Y"));
				$data["numero"] = $correlativo->numero;
				$data["serie"] = $correlativo->serie;

				$data["id_usuario"] = ID_USUARIO;
				$data["id_empresa"] = ID_EMPRESA;
				$data["fecha_sistema"] = date("Y-m-d H:i:s");
				$data["fl_estado"] = 1;
			}

			$this->Liquidacion_tercero_m->save($data);

			$id_liquidacion_tercero = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			/*** SAVE DETALLE */

			$data_detalle = [];
			$item = 0;

			foreach (json_decode($data_request["detalle_descuento"]) as $row) {

				$item++;

				$data_detalle[] = [
					'id_liquidacion_tercero'			=> $id_liquidacion_tercero,
					'item'								=> $item,
					'fecha'								=> $row->fecha,
					'descripcion'						=> $row->motivo.', '.$row->descripcion,
					'importe'							=> $row->importe
				];
			}

			$this->Liquidacion_tercero_detalle_m->insertbatch($data_detalle);
			
			/*** VINCULAR A VIAJE */

			$data_viaje = [
				'id'								=> $data_request["id_viaje"],
				'id_liquidacion_tercero'			=> $id_liquidacion_tercero
			];

			$this->Viaje_m->save($data_viaje);
			

			/****************** SAVE CENTINELA *****************/
			$liquidacion = $this->Liquidacion_tercero_m->select('concat(v.serie,"-",v.numero) as viaje')
			->join('viaje v', 'v.id = liquidacion_tercero.id_viaje')
			->find($id_liquidacion_tercero);

			$data_centinela = [
				'modulo'		=> 'TESORERIA',
				'menu'			=> 'LIQUIDACIÓN DE TERCEROS',
				'accion'		=> 'NUEVO',
				'descripcion'	=> 'Total Importe: '.trim($data_request["total_importe"]).', Viaje: '.$liquidacion->viaje
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */

			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente', 'id_liquidacion_tercero' => $id_liquidacion_tercero], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('tesoreria-liquidacion_tercero', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$liquidacion = $this->Liquidacion_tercero_m->find($data_request["id"]);

			/** DESVINCULAR DE VIAJE */
			$data_viaje = [
				'id'						=> $liquidacion->id_viaje,
				'id_liquidacion_tercero'	=> null
			];

			$this->Viaje_m->save($data_viaje);

			/** SAVE */
			$data_liquidacion  = [
				'id'		=> $data_request["id"],
				'fl_estado'	=> 0
			];

			$this->Liquidacion_tercero_m->save($data_liquidacion);     

			/****************** SAVE CENTINELA *****************/
			$liquidacion = $this->Liquidacion_tercero_m->select('concat(v.serie,"-",v.numero) as viaje, liquidacion_tercero.total_importe')
			->join('viaje v', 'v.id = liquidacion_tercero.id_viaje')
			->find($data_request["id"]);

			$data_centinela = [
				'modulo'		=> 'TESORERIA',
				'menu'			=> 'LIQUIDACIÓN DE TERCEROS',
				'accion'		=> 'ANULAR',
				'descripcion'	=> 'Total Importe: '.$liquidacion->total_importe.', Viaje: '.$liquidacion->viaje
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function save_factura_viaje()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('tesoreria-liquidacion_tercero', 'new');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			/** DESVINCULAR DE VIAJE */
			$data_viaje = [
				'id'						=> $data_request["id_viaje"],
				'serie_factura_tercero'		=> $data_request["serie_factura"],
				'numero_factura_tercero'	=> $data_request["numero_factura"],
			];

			$this->Viaje_m->save($data_viaje);
			
			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'TESORERIA',
				'menu'			=> 'LIQUIDACIÓN DE TERCEROS',
				'accion'		=> 'INSERTAR FACTURA',
				'descripcion'	=> $data_request["serie_factura"].'-'.$data_request["numero_factura"]
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
