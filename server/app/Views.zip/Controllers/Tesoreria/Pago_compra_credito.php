<?php namespace App\Controllers\Tesoreria;

use App\Controllers\BaseController;

use App\Models\Almacen\Compra_model;
use App\Models\Tesoreria\Caja_model;
use App\Models\Tesoreria\Flujo_caja_model;
use App\Models\Tesoreria\Caja_pago_compra_model;

class Pago_compra_credito extends BaseController
{
	public function __construct()
	{
		$this->Caja_pago_compra_m = new Caja_pago_compra_model();
		$this->Compra_m = new Compra_model();
		$this->Flujo_caja_m = new Flujo_caja_model();
		$this->Caja_m = new Caja_model();
	}

	public function compra_pendiente()
	{		
		$response = $this->Compra_m->select('alm_compra.*, concat(alm_compra.serie,"-",alm_compra.numero) as factura')
		->select('pr.razon_social as proveedor')
		->select('m.simbolo as moneda, m.id as id_moneda_deuda')
		->select('c.nombre as comprobante')
		->join('proveedor pr', 'pr.id = alm_compra.id_proveedor', 'left')
		->join('static_comprobante c', 'c.id = alm_compra.id_comprobante')
		->join('static_moneda m', 'm.id = alm_compra.id_moneda', 'left')
		->where('alm_compra.condicion_pago', 'CREDITO')
		->where('alm_compra.fl_estado', 1)
		->where('alm_compra.fl_pagado', null)
		->where('alm_compra.id_empresa', ID_EMPRESA)		
		->findAll();

		foreach ($response as $row) {

			$total_pago = $this->Caja_pago_compra_m->select('coalesce(sum(monto), 0) as monto')->where('id_compra', $row->id)->first();
			

			$total_deuda = $row->total_importe - $total_pago->monto;

			$row->total_pago = $total_pago->monto;
			$row->total_deuda = number_format($total_deuda, 2, '.', '');

			/** CALCULAR DIAS RESNTANTE DE PAGO */

			$fecha_a_pagar = date("d-m-Y",strtotime($row->fecha."+ ".($row->dias_pagar + 1)." days")); 

			$now = time(); // or your date as well
			$your_date = strtotime($fecha_a_pagar);
			$datediff =  $your_date - $now;
	
			$row->dias_restantes = round($datediff / (60 * 60 * 24));
		}

		return $this->respond(['data' => $response], 200);
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response = $this->Pago_compra_credito_m->select("id, concat(serie, ' - ', numero) as text");

		$response = $response
		->where('id_empresa', ID_EMPRESA)
		->findAll();
		
		return $this->respond($response, 200);
	}

	public function get_correlativo($serie)
	{
		$secuencia = $this->Pago_compra_credito_m->get_correlativo($serie);

		return $this->respond($secuencia, 200);
	}

	public function print($id)
	{
		$response = $this->Pago_compra_credito_m->select('pago_compra_credito.*')
		->select('coalesce(concat(o.serie, "-", o.numero), "") as compra')
		->select('e.nombre_comercial as empresa, e.logo')
		->select('u.usuario')
		->select('coalesce(mp.simbolo, "") as moneda_pago')

		->join('compra o', 'o.id = pago_compra_credito.id_compra', 'left')
		->join('empresa e', 'e.id = pago_compra_credito.id_empresa', 'left')
		->join('usuario u', 'u.id = pago_compra_credito.id_usuario', 'left')
		->join('static_moneda mp', 'mp.id = pago_compra_credito.id_moneda', 'left')

		->where('pago_compra_credito.id_empresa', ID_EMPRESA)	
		->where('pago_compra_credito.id', $id)	
		->first();

		$cantidad_pagos = $this->Pago_compra_credito_m->where('id_compra', $response->id_compra)->countAllResults();

		$response->cantidad_pagos = $cantidad_pagos;

		return $this->respond($response, 200);
	}

	public function index()
	{		
		$data_request = $this->request->getGet();

		$response = $this->Caja_pago_compra_m->select('caja_pago_compra.*')
		->select('concat(c.serie, "-", c.numero) as caja, c.modalidad, c.observacion, c.id as id_caja')
		->select('coalesce(m.simbolo, "") as simbolo_moneda')
		->select('pr.razon_social as proveedor')
		->select('concat(ac.serie,"-",ac.numero) as factura, ac.total_importe as total_importe_compra')
		->select('u.usuario')
		->join('static_moneda m', 'm.id = caja_pago_compra.id_moneda', 'left')
		->join('caja c', 'c.id = caja_pago_compra.id_caja')
		->join('alm_compra ac', 'ac.id = caja_pago_compra.id_compra', 'left')
		->join('proveedor pr', 'pr.id = ac.id_proveedor', 'left')
		->join('usuario u', 'u.id = caja_pago_compra.id_usuario', 'left')

		->where('DATE_FORMAT(caja_pago_compra.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(caja_pago_compra.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])
		->where('caja_pago_compra.id_empresa', ID_EMPRESA)		
		->findAll();

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('tesoreria-pago_compra_credito', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('tesoreria-pago_compra_credito', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->query('SET AUTOCOMMIT = 0');
			$db->transStart();
			$db->query('LOCK TABLES caja write, caja_pago_compra write,  movimiento_cuenta_bancaria_empresa write, centinela write, flujo_caja write, alm_compra write');

			// SAVE CAJA


			/** GUARDAR */
			$data = [
				'fecha'							=> trim($data_request["fecha"]),
				'tipo_persona'					=> trim($data_request["tipo_persona"]),
				'id_tipo_persona'				=> (isset($data_request["id_tipo_persona"])) ? trim($data_request["id_tipo_persona"]) : null,
				'nombre_persona'				=> trim($data_request["nombre_persona"]),
				'motivo'						=> 'PAGO DE COMPRAS AL CRÉDITO',
				'modalidad'						=> trim($data_request["modalidad"]),
				'id_moneda'						=> trim($data_request["id_moneda"]),
				'importe'						=> $data_request["monto_pago"],
				'observacion'					=> trim($data_request["observacion"]),
				'descripcion'					=> '',
				'cuenta_bancaria_persona'		=> (isset($data_request["cuenta_bancaria_persona"])) ? trim($data_request["cuenta_bancaria_persona"]) : null,
				'id_cuenta_bancaria_empresa'	=> ($data_request["id_cuenta_bancaria_empresa"] != '') ? trim($data_request["id_cuenta_bancaria_empresa"]) : null,
				'id_cuenta_bancaria_persona'	=> (isset($data_request["id_cuenta_bancaria_persona"])) ? trim($data_request["id_cuenta_bancaria_persona"]): null,
			];

			$correlativo = $this->Caja_m->get_correlativo(date("Y"));
			$data["serie"] = $correlativo->serie;
			$data["numero"] = $correlativo->numero;
			$data["tipo"] = 'CAJA_RAPIDA';
			$data["fl_estado"] = ($data["tipo"] == 'CAJA_RAPIDA') ? 3 : 1;
			$data["id_empresa"] = ID_EMPRESA;
			$data["id_membresia"] = ID_MEMBRESIA;
			$data["id_usuario"] = ID_USUARIO;

			$this->Caja_m->save($data);

			$id_caja = $db->insertID();

			$caja = $this->Caja_m->find($id_caja);

			/** SAVE FLUJO CAJA */
			$data =  [
				'fecha'       					=> $data_request["fecha"],
				'tipo'        					=> 'EGRESO',
				'descripcion' 					=> 'PAGO MASIVO DE COMPRAS - CAJA #'.$caja->serie.'-'.$caja->numero,
				'id_caja'						=> $id_caja,
				'id_usuario'  					=> ID_USUARIO,
				'id_empresa' 					=> ID_EMPRESA,
				'id_membresia' 					=> ID_MEMBRESIA,
				'id_cuenta_bancaria_empresa'   	=> (isset($data_request["id_cuenta_bancaria_empresa"])) ? $data_request["id_cuenta_bancaria_empresa"] : null,
				'monto'       					=> $data_request["monto_pago"]
			];

			$this->Flujo_caja_m->save($data);


			/////

			$aporte = $data_request["monto_pago"];

            $efectivo = $aporte;
            $compras_pagadas = array();
            $compra_saldo = null;

            /* RECORRIENDO DETALLE */
            foreach (json_decode($data_request["detalle_compra"]) as $item) {
                
				$id_compra = $item->id;

                $compra = $this->Compra_m->select('id as id_compra, total_importe')->find($id_compra);

				$compra->monto_cobrar = $item->total_deuda;

				
                $efectivo = $efectivo - $compra->monto_cobrar;

                if($efectivo > 0)
                {
                    /* PAGANDO COMPROBANTES */
                    $compras_pagadas[] = $compra;
                }
                else if($efectivo == 0)
                {
                    /* PAGO EXACTO */
                    $compras_pagadas[] = $compra;
                    break;
                }
                else
                {
                    /* COMPROBANTE SALDO */
                    $compra_saldo = $compra;
                    $saldo = abs($efectivo);
                    $efectivo = 0;
                    break;
                }
            }

            foreach ($compras_pagadas as $row) {

                /** REGISTRAR PAGO */
                $array_pago = [
                  'id_compra'           			=> $row->id_compra,
				  'id_caja'           				=> $id_caja,
                  'id_empresa'       				=> ID_EMPRESA,
				  'id_membresia' 					=> ID_MEMBRESIA,
                  'id_usuario'        				=> ID_USUARIO,
                  'monto'             				=> $row->monto_cobrar,
                  'id_compra'          				=> $row->id_compra,
                  'fecha'             				=> $data_request["fecha"],
				  'id_moneda'						=> $data_request["id_moneda"]
                ];

                $this->Caja_pago_compra_m->save($array_pago);
				
                /* GUARDAR ESTADO */                
                $array_save = [
                  'id'          		=> $row->id_compra,
                  'fl_pagado'         	=> 1,
				  'fecha_pago'			=> $data_request["fecha"]
                ];
    
                $this->Compra_m->save($array_save);			
                
            } 

            if ($compra_saldo != null) {

				  $array_pago = [
					'id_compra'           				=> $compra_saldo->id_compra,
					'id_caja'           				=> $id_caja,
					'id_empresa'       					=> ID_EMPRESA,
					'id_usuario'        				=> ID_USUARIO,
					'monto'             				=> $compra_saldo->monto_cobrar - $saldo,
					'fecha'             				=> $data_request["fecha"],
					'id_moneda'							=> $data_request["id_moneda"]
				  ];
  

				$this->Caja_pago_compra_m->save($array_pago);
				
            }
						
			
			/****************** SAVE CENTINELA *****************/
		
			$data_centinela = [
				'modulo'		=> 'TESORERIA',
				'menu'			=> 'PAGO DE COMPRAS',
				'accion'		=> 'NUEVO',
				'descripcion'	=> 'PAGO MASIVO DE COMPRAS - CAJA #'.$caja->serie.'-'.$caja->numero
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente', 'id_caja' => $id_caja], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function edit()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('tesoreria-pago_compra_credito', 'edit');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$pago_compra_credito = $this->Pago_compra_credito_m->select('f.id as id_flujo_caja, pago_compra_credito.id, pago_compra_credito.id_compra, o.total_compra')
			->join('flujo_caja f', 'f.id_pago_compra_credito = pago_compra_credito.id')
			->join('compra o', 'o.id = pago_compra_credito.id_compra')
			->where('pago_compra_credito.id', $data_request["id"])
			->first();

			if(is_object($pago_compra_credito))
			{
				/** REGISTRAR PAGO */
				$array_pago = [
					'id_cuenta_bancaria_empresa'   	=> (isset($data_request["id_cuenta_bancaria_empresa"])) ? $data_request["id_cuenta_bancaria_empresa"] : null,
					'tipo_canal'        			=> $data_request["tipo_canal"],
					'medio_pago'         			=> $data_request["medio_pago"],
					'numero_operacion'         		=> $data_request["numero_operacion"],
					'observacion'           		=> $data_request["observacion"],
					'id_usuario'        			=> ID_USUARIO,
					'monto'             			=> $data_request["monto_pago"],
					'fecha'             			=> $data_request["fecha"],
					'id'							=> $data_request["id"]
				];

				$this->Pago_compra_credito_m->save($array_pago);

				/** SAVE FLUJO CAJA */
				$data =  [
					'fecha'       					=> $data_request["fecha"],
					'tipo'        					=> 'INGRESO',
					'descripcion' 					=> $data_request["numero_operacion"],
					'id_pago_compra_credito'					=> $data_request["id"],
					'id_usuario'  					=> ID_USUARIO,
					'id_cuenta_bancaria_empresa'   	=> (isset($data_request["id_cuenta_bancaria_empresa"])) ? $data_request["id_cuenta_bancaria_empresa"] : null,
					'monto'       					=> $data_request["monto_pago"],
					'id'							=> $pago_compra_credito->id_flujo_caja
				];

				$this->Flujo_caja_m->save($data);
				

				/*** VERIFICAR PAGO TOTAL */
				$total_pago = $this->Pago_compra_credito_m->select('coalesce(sum(monto), 0) as monto')->where('id_compra', $pago_compra_credito->id_compra)->first();
			
				/* GUARDAR ESTADO */                
				$array_save = [
					'id'          		=> $pago_compra_credito->id_compra,
					'fl_pagado'         => ($total_pago->monto >= $pago_compra_credito->total_compra) ? 1 : null,
				];				
	
				$this->Compra_m->save($array_save);

				/****************** SAVE CENTINELA *****************/
				$pago_compra_credito = $this->Pago_compra_credito_m->select('concat(o.serie,"-",o.numero) as compra')
				->select('pago_compra_credito.monto')
				->join('compra o', 'o.id = pago_compra_credito.id_compra')
				->find($data_request["id"]);

				$data_centinela = [
					'modulo'		=> 'TESORERIA',
					'menu'			=> 'PAGO DE ÓRDENES',
					'accion'		=> 'EDITAR',
					'descripcion'	=> 'Monto: '.$pago_compra_credito->monto.', Compra: '.$pago_compra_credito->compra
				];

				$this->Centinela_m->registrar($data_centinela);
				/*************************************************** */

				$db->transComplete();

				return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);
			}
			else
			{
				return $this->respond(['tipo' => 'warning', 'mensaje' => 'No hubo cambios'], 200);
			}
			

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('tesoreria-pago_compra_credito', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$pago_compra_credito = $this->Pago_compra_credito_m->select('concat(o.serie,"-",o.numero) as compra, pago_compra_credito.id as id_compra')
			->select('pago_compra_credito.monto')
			->join('compra o', 'o.id = pago_compra_credito.id_compra')
			->find($data_request["id"]);

			$data = [
				'id'		=> $pago_compra_credito->id_compra,
				'fl_pagado'	=> null
			];

			$this->Compra_m->save($data);

			$this->Pago_compra_credito_m->where('id', $data_request["id"])->delete();
			$this->Flujo_caja_m->where('id_pago_compra_credito', $data_request["id"])->delete();

			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'TESORERIA',
				'menu'			=> 'PAGO DE ÓRDENES',
				'accion'		=> 'ELIMINAR',
				'descripcion'	=> 'Monto: '.$pago_compra_credito->monto.', Compra: '.$pago_compra_credito->compra
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
