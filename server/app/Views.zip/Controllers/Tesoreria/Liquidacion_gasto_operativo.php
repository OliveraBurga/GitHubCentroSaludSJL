<?php namespace App\Controllers\Tesoreria;

use App\Controllers\BaseController;
use App\Models\Tesoreria\Liquidacion_gasto_operativo_model;
use App\Models\Tesoreria\Liquidacion_gasto_operativo_detalle_model;
use App\Models\Operacion\Viaje_model;
use App\Models\Tesoreria\Caja_model;
use App\Models\Tesoreria\Flujo_caja_model;
use App\Models\Operacion\Gasto_operativo_model;
use App\Models\Operacion\Mantenimiento_vehiculo_model;
use App\Models\Configuracion\Empresa_model;
use App\Models\Configuracion\Personal_model;

class Liquidacion_gasto_operativo extends BaseController
{
	public function __construct()
	{
		$this->Liquidacion_gasto_operativo_m = new Liquidacion_gasto_operativo_model();
		$this->Liquidacion_gasto_operativo_detalle_m = new Liquidacion_gasto_operativo_detalle_model();
		$this->Viaje_m = new Viaje_model();
		$this->Caja_m = new Caja_model();
		$this->Gasto_operativo_m = new Gasto_operativo_model();
		$this->Empresa_m = new Empresa_model();
		$this->Flujo_caja_m = new Flujo_caja_model();
	}

	public function print($id_liquidacion_gasto_operativo)
	{
		$response = $this->Liquidacion_gasto_operativo_m->select('liquidacion_gasto_operativo.*')
		->select('concat(v.serie, "-", v.numero) as viaje')
		->select('p.nombre_completo as conductor')
		->select('vh.placa as vehiculo')
		->select('coalesce(vs.placa, "") as remolque')
		->join('personal p', 'p.id = liquidacion_gasto_operativo.id_conductor', 'left')
		->join('viaje v', 'v.id = liquidacion_gasto_operativo.id_viaje', 'left')
		->join('vehiculo vh', 'vh.id = v.id_vehiculo', 'left')
		->join('vehiculo vs', 'vs.id = v.id_remolque', 'left')
		->where('liquidacion_gasto_operativo.id', $id_liquidacion_gasto_operativo)
		->first();

		$response->detalle = $this->Liquidacion_gasto_operativo_detalle_m->where('id_liquidacion_gasto_operativo', $response->id)->findAll();
		$response->empresa = $this->Empresa_m->find(ID_EMPRESA);

		return $this->respond($response, 200);
	}

	public function get_viaje($id_viaje)
	{
		$response = $this->Viaje_m->select('lg.*,')
		->select('concat(viaje.serie, "-", viaje.numero) as viaje, viaje.id as id_viaje')
		->select('p.nombre_completo as conductor, p.id as id_conductor')
		->select('lg.id as id_liquidacion_gasto_operativo')
		->select('v.placa as vehiculo') 
		->select('coalesce(vs.placa, "") as remolque')

		->join('liquidacion_gasto_operativo lg', 'lg.id = viaje.id_liquidacion_gasto_operativo', 'left')
		->join('personal p', 'p.id = viaje.id_conductor', 'left')
		->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
		->join('vehiculo vs', 'vs.id = viaje.id_remolque', 'left')
		->where('viaje.id', $id_viaje)
		->first();

		$response->detalle = $this->Gasto_operativo_m->select('gasto_operativo.*')
		->select('coalesce(tg.nombre, "") as tipo_gasto_operativo')
		->select('coalesce(m.simbolo, "") as simbolo_moneda')
		->join('tipo_gasto_operativo tg', 'tg.id = gasto_operativo.id_tipo_gasto_operativo', 'left')
		->join('static_moneda m', 'm.id = gasto_operativo.id_moneda', 'left')
		->where('id_viaje', $response->id_viaje)
		->where('tg.fl_no_liquidacion', null)
		->findAll();

		$total_gasto_operativo = 0;

		foreach ($response->detalle as $row) {

			// CONVERSIÓN DE MONEDA A NATAL
			if($row->id_moneda != 1)
			{
				$total_gasto_operativo = $total_gasto_operativo + ($row->importe * $row->tipo_cambio);
			}
			else
			{
				$total_gasto_operativo = $total_gasto_operativo + $row->importe;
			}
			
		}

		$cajas = $this->Caja_m->select('importe, id_moneda, tipo_cambio')
		->where('id_viaje', $response->id_viaje)
		->where('motivo', 'GASTOS OPERATIVOS')				
		->where('fl_estado', 3)
		->where('fl_no_liquidacion_viaje', null)
		->findAll();

		$total_caja = 0;

		foreach ($cajas as $caja) {
			
			if($caja->id_moneda > 1)
			{
				$total_caja = $total_caja + ($caja->importe * $caja->tipo_cambio);
			}
			else
			{
				$total_caja = $total_caja + $caja->importe;
			}
		}
		
		$response->total_desembolso = number_format($total_caja, 2, '.', '');

		$response->total_gasto = number_format($total_gasto_operativo, 2, '.', '');

		$response->total_reembolso = '0.00';
		$response->total_saldo = $response->total_desembolso - $response->total_gasto;

		$response->total_saldo = number_format($response->total_saldo, 2, '.', '');

		return $this->respond($response, 200);
	}

	public function index()
	{		
		$data_request = $this->request->getGet();		

		if($data_request["tipo"] == 'SIN_LIQUIDAR')
		{
			$response = $this->Viaje_m->select('lg.*,')
			->select('concat(viaje.serie, "-", viaje.numero) as viaje, viaje.id as id_viaje')
			->select('p.nombre_completo as conductor, p.id as id_conductor')
			->select('lg.id as id_liquidacion_gasto_operativo')
			->select('v.placa as vehiculo')
			->select('coalesce(vs.placa, "") as remolque')
			->join('liquidacion_gasto_operativo lg', 'lg.id = viaje.id_liquidacion_gasto_operativo', 'left')
			->join('personal p', 'p.id = viaje.id_conductor', 'left')
			->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
			->join('vehiculo vs', 'vs.id = viaje.id_remolque', 'left');

			
			$response->where("viaje.id in (select id_viaje from caja where motivo = 'GASTOS OPERATIVOS' and fl_estado = 3)")
			->where("lg.fl_estado", null)
			->where('viaje.fl_estado', 1)	
		;
		}
		else
		{
			$response = $this->Liquidacion_gasto_operativo_m->select('liquidacion_gasto_operativo.*,')
			->select('concat(viaje.serie, "-", viaje.numero) as viaje, viaje.id as id_viaje')
			->select('p.nombre_completo as conductor, p.id as id_conductor')
			->select('liquidacion_gasto_operativo.id as id_liquidacion_gasto_operativo')
			->select('v.placa as vehiculo')
			->select('coalesce(vs.placa, "") as remolque')
			->join('viaje', 'viaje.id = liquidacion_gasto_operativo.id_viaje', 'left')
			->join('personal p', 'p.id = viaje.id_conductor', 'left')
			->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
			->join('vehiculo vs', 'vs.id = viaje.id_remolque', 'left');

			$response->where('DATE_FORMAT(liquidacion_gasto_operativo.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
			->where('DATE_FORMAT(liquidacion_gasto_operativo.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"]);
		}

		$response = $response->where('viaje.id_empresa', ID_EMPRESA)	
		->findAll();

		foreach ($response as $row) {

			if($row->fl_estado == null)
			{
				$row->detalle = $this->Gasto_operativo_m->select('gasto_operativo.*')
				->select('coalesce(tg.nombre, "") as tipo_gasto_operativo')
				->join('tipo_gasto_operativo tg', 'tg.id = gasto_operativo.id_tipo_gasto_operativo', 'left')
				->where('id_viaje', $row->id_viaje)->findAll();

				$cajas = $this->Caja_m->select('importe, tipo_cambio')
				->where('id_viaje', $row->id_viaje)
				->where('fl_estado', 3)
				->where('motivo', 'GASTOS OPERATIVOS')				
				->where('fl_no_liquidacion_viaje', null)
				->findAll();

				$total_caja = 0;
				foreach ($cajas as $caja) {

					if(is_numeric($caja->tipo_cambio))
					{
						$caja->importe = $caja->importe * $caja->tipo_cambio;
					}
					
					$total_caja = $total_caja + $caja->importe;
				}
				
				$row->total_desembolso = number_format($total_caja, 2, '.', '');

				$gastos_operativos = $this->Gasto_operativo_m->select('importe, tipo_cambio')
				->where('id_viaje', $row->id_viaje)
				->findAll();
				
				$total_gasto_operativo = 0;
				foreach ($gastos_operativos as $gasto) {

					if(is_numeric($gasto->tipo_cambio))
					{
						$gasto->importe = $gasto->importe * $gasto->tipo_cambio;
					}

					$total_gasto_operativo = $total_gasto_operativo + $gasto->importe;
				}
				
				$row->total_gasto = number_format($total_gasto_operativo, 2, '.', '');

				$row->total_reembolso = '0.00';
				$row->total_saldo = $row->total_desembolso - $row->total_gasto;

				$row->total_saldo = number_format($row->total_saldo, 2, '.', '');
			}
		}

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('tesoreria-liquidacion_gasto_operativo', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('tesoreria-liquidacion_gasto_operativo', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->query('SET AUTOCOMMIT = 0');
			$db->transStart();
			$db->query('LOCK TABLES liquidacion_gasto_operativo write,  liquidacion_gasto_operativo_detalle write, centinela write, viaje write, personal read, caja write, flujo_caja write, ajuste_avanzado read');


			/** GUARDAR */
			$data = [
				'fecha' 					=> trim($data_request["fecha"]),
				'id_viaje'					=> trim($data_request["id_viaje"]),
				'id_conductor'				=> trim($data_request["id_conductor"]),
				'total_desembolso'			=> trim($data_request["total_desembolso"]),
				'total_gasto'				=> trim($data_request["total_gasto"]),
				'total_reembolso'			=> trim($data_request["total_reembolso"]),
				'total_saldo'				=> trim($data_request["total_saldo"]),
				'tipo_accion'				=> trim($data_request["tipo_accion"]),
				'observacion'				=> trim($data_request["observacion"]),
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$correlativo = $this->Liquidacion_gasto_operativo_m->get_correlativo(date("Y"));
				$data["numero"] = $correlativo->numero;
				$data["serie"] = $correlativo->serie;

				$data["id_usuario"] = ID_USUARIO;
				$data["id_empresa"] = ID_EMPRESA;
				$data["fecha_sistema"] = date("Y-m-d H:i:s");
				$data["fl_estado"] = 1;
				$data["fl_tipo_accion"] = 0;
			}

			$this->Liquidacion_gasto_operativo_m->save($data);

			$id_liquidacion_gasto_operativo = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			/*** SAVE DETALLE */

			$data_detalle = [];
			$item = 0;

			foreach (json_decode($data_request["detalle_gasto"]) as $row) {

				$item++;

				$data_detalle[] = [
					'id_liquidacion_gasto_operativo'	=> $id_liquidacion_gasto_operativo,
					'item'								=> $item,
					'fecha'								=> $row->fecha,
					'descripcion'						=> $row->tipo_gasto_operativo.', '.$row->detalle,
					'importe'							=> $row->importe
				];
			}

			$this->Liquidacion_gasto_operativo_detalle_m->insertbatch($data_detalle);
			
			/*** VINCULAR A VIAJE */
			$data_viaje = [
				'id'								=> $data_request["id_viaje"],
				'id_liquidacion_gasto_operativo'	=> $id_liquidacion_gasto_operativo
			];

			$this->Viaje_m->save($data_viaje);

			$id_caja = null;

			// CREAR CAJA RÁPIDA
			if($data_request["tipo_accion"] == 'SALIDA CAJA')
			{
				$Personal_m = new Personal_model();
				$conductor = $Personal_m->select('nombre_completo')->find($data_request["id_conductor"]);

				$viaje = $this->Viaje_m->select('serie, numero')->find($data_request["id_viaje"]);

				/** GUARDAR */
				$data = [
					'fecha'							=> $data_request["fecha"],
					'id_viaje'						=> $data_request["id_viaje"],
					'tipo_persona'					=> 'CONDUCTOR',
					'id_tipo_persona'				=> $data_request["id_conductor"],
					'nombre_persona'				=> $conductor->nombre_completo,
					'motivo'						=> 'GASTOS OPERATIVOS',
					'id_moneda'						=> 1, // MONEDA SISTEMA
					'descripcion'					=> 'SALDO NEGATIVO EN LIQUIDACIÓN DE GASTOS OPERATIVOS DE VIAJE:'.$viaje->serie.'-'.$viaje->numero,
					'modalidad'						=> $data_request["modalidad"],
					'importe'						=> abs($data_request["total_saldo"]),
					'cuenta_bancaria_persona'		=> (isset($data_request["cuenta_bancaria_persona"])) ? trim($data_request["cuenta_bancaria_persona"]) : null,
					'titular_cuenta'				=> (isset($data_request["titular_cuenta"])) ? trim($data_request["titular_cuenta"]) : null,
					'id_cuenta_bancaria_empresa'	=> ($data_request["id_cuenta_bancaria_empresa"] != '') ? trim($data_request["id_cuenta_bancaria_empresa"]) : null,
					'id_cuenta_bancaria_persona'	=> (isset($data_request["id_cuenta_bancaria_persona"])) ? trim($data_request["id_cuenta_bancaria_persona"]): null,
				];

				$correlativo = $this->Caja_m->get_correlativo(date("Y"));
				$data["serie"] = $correlativo->serie;
				$data["numero"] = $correlativo->numero;
				$data["tipo"] = 'CAJA_RAPIDA';
				$data["fl_estado"] = 3;
				$data["id_empresa"] = ID_EMPRESA;
				$data["id_usuario"] = ID_USUARIO;

				$this->Caja_m->save($data);

				$id_caja = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

				/** SAVE FLUJO CAJA */
				$this->Flujo_caja_m->where('id_caja', $id_caja)->delete();

				$data =  [
					'fecha'       					=> $data_request["fecha"],
					'tipo'        					=> 'EGRESO',
					'descripcion' 					=> 'SALDO NEGATIVO EN LIQUIDACIÓN DE GASTOS OPERATIVOS',
					'id_caja'						=> $id_caja,
					'id_usuario'  					=> ID_USUARIO,
					'id_empresa' 					=> ID_EMPRESA,
					'id_cuenta_bancaria_empresa'   	=> ($data_request["id_cuenta_bancaria_empresa"] != '') ? $data_request["id_cuenta_bancaria_empresa"] : null,
					'monto'       					=> abs($data_request["total_saldo"])
				];

				$this->Flujo_caja_m->save($data);
			}			

			/****************** SAVE CENTINELA *****************/
			$liquidacion = $this->Liquidacion_gasto_operativo_m->select('concat(viaje.serie,"-",viaje.numero) as viaje')
			->join('viaje', 'viaje.id = liquidacion_gasto_operativo.id_viaje')
			->find($id_liquidacion_gasto_operativo);

			$data_centinela = [
				'modulo'		=> 'TESORERIA',
				'menu'			=> 'LIQUIDACIÓN GASTOS OPERATIVOS',
				'accion'		=> 'NUEVO',
				'descripcion'	=> 'Saldo: '.trim($data_request["total_saldo"]).', Viaje: '.$liquidacion->viaje
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */

			$db->query('UNLOCK TABLES');
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente', 'id_caja' => $id_caja], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('tesoreria-liquidacion_gasto_operativo', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$liquidacion = $this->Liquidacion_gasto_operativo_m->select('concat(v.serie,"-",v.numero) as viaje, liquidacion_gasto_operativo.id_viaje')
			->join('viaje v', 'v.id = liquidacion_gasto_operativo.id_viaje')
			->find($data_request["id"]);

			/** DESVINCULAR DE VIAJE */
			$data_viaje = [
				'id'								=> $liquidacion->id_viaje,
				'id_liquidacion_gasto_operativo'	=> null
			];

			$this->Viaje_m->save($data_viaje);

			/** SAVE */
			$data_liquidacion  = [
				'id'		=> $data_request["id"],
				'fl_estado'	=> 0
			];

			$this->Liquidacion_gasto_operativo_m->save($data_liquidacion);     

			/****************** SAVE CENTINELA *****************/

			$data_centinela = [
				'modulo'		=> 'TESORERIA',
				'menu'			=> 'LIQUIDACIÓN GASTOS OPERATIVOS',
				'accion'		=> 'ANULAR',
				'descripcion'	=> 'Viaje: '.$liquidacion->viaje
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function save_mantenimiento()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('operacion-mantenimiento_vehiculo', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('operacion-mantenimiento_vehiculo', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$Mantenimiento_vehiculo_m = new Mantenimiento_vehiculo_model();

			$viaje = $this->Viaje_m->find($data_request["id_viaje"]);
			$gasto = json_decode($data_request["data_json"]);

			/** GUARDAR */
			$data = [
				'id_vehiculo'         	=> $viaje->id_vehiculo,
				'fecha'               	=> $gasto->fecha,
				'tipo'  			  	=> 'CORRECTIVO',
				'numero_documento'    	=> $gasto->numero_documento,
				'id_moneda'    			=> $gasto->id_moneda,
				'id_proveedor'        	=> null,
				'mantenimiento'     	=> $gasto->detalle,
				'descripcion'         	=> 'TRASPASO DE GASTOS OPERATIVOS DE VIAJE: '.$viaje->serie.'-'.$viaje->numero.', FECHA:'.date("d/m/Y", strtotime($viaje->fecha)),
				'costo'               	=> $gasto->importe,
				'fecha_sistema'			=> date("Y-m-d H:i:s"),
				'id_empresa'			=> ID_EMPRESA
			];

			$Mantenimiento_vehiculo_m->save($data);

			/*** ELIMINAR GASTO OPERATIVO */
			$this->Gasto_operativo_m->where('id', $gasto->id)->delete();
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function delete_gasto()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('operacion-gasto_operativo', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();
			
			$gasto = json_decode($data_request["data_json"]);

			/*** ELIMINAR GASTO OPERATIVO */
			$this->Gasto_operativo_m->where('id', $gasto->id)->delete();

			/****************** SAVE CENTINELA *****************/

			$data_centinela = [
				'modulo'		=> 'TESORERIA',
				'menu'			=> 'LIQUIDACIÓN GASTOS OPERATIVOS',
				'accion'		=> 'ELIMINAR',
				'descripcion'	=> 'ELIMINAR GASTO OPERATIVO, '.$gasto->detalle
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
