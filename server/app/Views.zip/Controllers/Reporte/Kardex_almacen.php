<?php namespace App\Controllers\Reporte;

use App\Controllers\BaseController;

use App\Models\Almacen\Kardex_model;

class Kardex_almacen extends BaseController
{
	public function __construct()
	{
		$this->Kardex_m = new Kardex_model();
	}

	public function index($retorno = false)
	{
		$data_request = $this->request->getGet();

		$response = $this->Kardex_m->select('alm_kardex.*')
		->select('coalesce(ingreso_cantidad, "") as ingreso_cantidad')
		->select('coalesce(ingreso_costo, "") as ingreso_costo')
		->select('coalesce(ingreso_monto, "") as ingreso_monto')
		->select('coalesce(salida_cantidad, "") as salida_cantidad')
		->select('coalesce(salida_costo, "") as salida_costo')
		->select('coalesce(salida_monto, "") as salida_monto')
		->where('DATE_FORMAT(fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])
		->where('id_empresa', ID_EMPRESA)
		->findAll();

		return $this->respond(['data' => $response], 200);
	}
	
}
