<?php namespace App\Controllers\Reporte;

use App\Controllers\BaseController;

use App\Models\Operacion\Viaje_orden_model;
use App\Models\Operacion\Viaje_guia_model;
use App\Models\Operacion\Gasto_operativo_model;
use App\Models\Operacion\Vale_combustible_model;
use App\Models\Operacion\Vale_pago_model;
use App\Models\Tesoreria\Caja_model;
use App\Models\Configuracion\Config_modulo_model;

class Orden extends BaseController
{
	public function __construct()
	{
		$this->Viaje_orden_m = new Viaje_orden_model();
		$this->Viaje_guia_m = new Viaje_guia_model();
		$this->Gasto_operativo_m = new Gasto_operativo_model();
		$this->Vale_combustible_m = new Vale_combustible_model();
		$this->Vale_pago_m = new Vale_pago_model();
		$this->Caja_m = new Caja_model();
		$this->Config_modulo_m = new Config_modulo_model();
	}

	public function index()
	{
		$data_request = $this->request->getGet();

		$response = $this->Viaje_orden_m->select('orden.*, orden.id as id_orden, concat(orden.serie,"-",orden.numero) as orden')
		->select('viaje.*, viaje.id as id_viaje, coalesce(date_format(viaje.fecha_inicio, "%d/%m/%Y"), "") as fecha_inicio, coalesce(date_format(viaje.fecha_fin, "%d/%m/%Y"), "") as fecha_fin, viaje.costo_tercerizado')
		->select('concat(ruta.punto_inicio, " - ", ruta.punto_final) as ruta')
		->select('cond.nombre_completo as conductor')
		->select('cliente.razon_social as cliente')
		->select('v.placa as vehiculo, v.serie_chasis')
		->select('vr.placa as remolque')
		->select('coalesce(concat(f.serie,"-",f.numero), "") as factura')
		->select('lt.numero_factura as factura_tercero')
		->select('m.nombre as moneda, m.simbolo as moneda_simbolo')
		->select('coalesce(l.descripcion, "") as local')

		->join('orden', 'orden.id = viaje_orden.id_orden')
		->join('static_moneda m', 'm.id = orden.id_moneda')
		->join('viaje', 'viaje.id = viaje_orden.id_viaje', 'left')
		->join('ruta', 'ruta.id = orden.id_ruta', 'left')
		->join('personal cond', 'cond.id = viaje.id_conductor', 'left')
		->join('cliente', 'cliente.id = orden.id_cliente', 'left')
		->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
		->join('vehiculo vr', 'vr.id = viaje.id_remolque', 'left')
		->join('factura f', 'f.id = orden.id_factura', 'left')
		->join('liquidacion_tercero lt', 'lt.id = viaje.id_liquidacion_tercero', 'left')
		->join('local l', 'l.id = orden.id_local', 'left')
		->where('DATE_FORMAT(orden.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(orden.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"]);

		if($data_request["id_cliente"] != '')
		{
			$response->where('orden.id_cliente', $data_request["id_cliente"]);
		}

		if($data_request["id_proveedor"] != '')
		{
			$response->where('v.id_proveedor', $data_request["id_proveedor"]);
		}

		if($data_request["id_ruta"] != '')
		{
			$response->where('orden.id_ruta', $data_request["id_ruta"]);
		}

		if($data_request["estado_operacion"] != '')
		{
			$response->where('viaje.estado_operacion', $data_request["estado_operacion"]);
		}

		if($data_request["id_local"] != '')
		{
			$response->where('orden.id_local', $data_request["id_local"]);
		}

		$response = $response->where('orden.id_empresa', ID_EMPRESA)		
		->findAll();	

		foreach ($response as $row) {

			if($row->id_viaje != null)
			{
				$guias = $this->Viaje_guia_m->where('(id_orden = '.$row->id_orden.' or id_viaje = '.$row->id_viaje.')')->where('fl_estado', 1)->findAll();
			}
			else
			{
				$guias = $this->Viaje_guia_m->where('id_orden', $row->id_viaje)->where('fl_estado', 1)->findAll();
			}
			

			$guia_remitente = [];
			$guia_transportista = [];
			$guia_tercero = [];
			$origen_destino_guia_transportista = [];

			foreach ($guias as $guia) {
				
				switch ($guia->tipo) {
					case 'REMITENTE':
						$guia_remitente[] = $guia->serie.'-'.$guia->numero;
					break;
					
					case 'TRANSPORTISTA':
						$guia_transportista[] = $guia->serie.'-'.$guia->numero;
						$origen_destino_guia_transportista[] = $guia->punto_origen.' / '.$guia->punto_destino;
					break;

					case 'TERCERO':
						$guia_tercero[] = $guia->serie.'-'.$guia->numero;
					break;
				}
			}

			$row->guia_remitente = implode(', ', $guia_remitente);
			$row->guia_transportista = implode(', ', $guia_transportista);
			$row->guia_tercero = implode(', ', $guia_tercero);
			$row->origen_destino_guia_transportista = implode(' <br>', $origen_destino_guia_transportista);


			/** GASTOS OPERATIVOS */
			$total_declaracion_gasto_operativo = 0;
			$row->gasto_operativo = $this->Gasto_operativo_m->select('gasto_operativo.*')
			->select('coalesce(tg.nombre, "") as tipo_gasto_operativo')
			->select('coalesce(m.simbolo, "") as simbolo_moneda')
			->join('tipo_gasto_operativo tg', 'tg.id = gasto_operativo.id_tipo_gasto_operativo', 'left')
			->join('static_moneda m', 'm.id = gasto_operativo.id_moneda', 'left')
			->where('tg.fl_no_liquidacion', null)
			->where('id_viaje', $row->id)->findAll();

			foreach ($row->gasto_operativo as $gasto) {

				if(is_numeric($gasto->tipo_cambio))
				{
					$gasto->importe = $gasto->importe * $gasto->tipo_cambio;
					$gasto->importe = number_format($gasto->importe, 2, '.', '');
				}

				$total_declaracion_gasto_operativo = $total_declaracion_gasto_operativo + $gasto->importe;
			}

			/** VALE DE COMBUSTIBLE */
			$total_declaracion_vale_combustible = 0;

			$row->vale_combustible = $this->Vale_combustible_m->select('vale_combustible.*')
			->select('p.razon_social as proveedor')
			->select('coalesce(m.simbolo, "") as simbolo_moneda')
			->join('proveedor p', 'p.id = vale_combustible.id_proveedor', 'left')
			->join('static_moneda m', 'm.id = vale_combustible.id_moneda', 'left')
			->where('fl_estado', 1)
			->where('id_viaje', $row->id)
			->findAll();

			foreach ($row->vale_combustible as $vale) {

				if(is_numeric($vale->tipo_cambio))
				{
					$vale->importe = $vale->importe * $vale->tipo_cambio;
					$vale->importe = number_format($vale->importe , 2, '.', '');
				}

				$total_declaracion_vale_combustible = $total_declaracion_vale_combustible + $vale->importe;
			}


			/** VALES DE PAGO */
			$total_declaracion_vale_pago = 0;

			$row->vale_pago = $this->Vale_pago_m->select('vale_pago.*')
			->select('p.razon_social as proveedor')
			->select('coalesce(m.simbolo, "") as simbolo_moneda')
			->join('proveedor p', 'p.id = vale_pago.id_proveedor', 'left')
			->join('static_moneda m', 'm.id = vale_pago.id_moneda', 'left')
			->where('fl_estado', 1)
			->where('id_viaje', $row->id)
			->findAll();

			foreach ($row->vale_pago as $vale) {

				if(is_numeric($vale->tipo_cambio))
				{
					$vale->importe = $vale->importe * $vale->tipo_cambio;
					$vale->importe = number_format($vale->importe , 2, '.', '');
				}

				$total_declaracion_vale_pago = $total_declaracion_vale_pago + $vale->importe;
			}

			$total_gasto_operativo = $total_declaracion_gasto_operativo;
			$total_combustible = $total_declaracion_vale_combustible; 
			$total_otros = $total_declaracion_vale_pago;
			
			$row->total_gasto_operativo = number_format($total_gasto_operativo, 2, '.', '');
			$row->total_combustible = number_format($total_combustible, 2, '.', '');
			$row->total_otros = number_format($total_otros, 2, '.', '');

		}

		return $this->respond(['data' => $response], 200);
	}

	function get_configuracion()
	{
		$config_modulo = $this->Config_modulo_m->where('id_empresa', ID_EMPRESA)
		->first();

		$response = [
			'view_datatable'	=> $config_modulo->dt_report_orden_trabajo
		];

		return $this->respond($response, 200);
	}

	public function save_configuracion()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('configuracion-ajuste_avanzado', 'edit');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			/** GUARDAR */
			$data = [
				'dt_report_orden_trabajo'     => trim($data_request["view_datatable"]),
				'id_empresa'				=> ID_EMPRESA
			];

			$this->Config_modulo_m->save($data);

			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'REPORTES',
				'menu'			=> 'ORDEN TRABAJO',
				'accion'		=> 'CONFIGURAR',
				'descripcion'	=> 'Configuración'
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	
		
}
