<?php namespace App\Controllers\Reporte;

use App\Controllers\BaseController;

use App\Models\Operacion\Viaje_model;
use App\Models\Operacion\Orden_model;
use App\Models\Operacion\Viaje_guia_model;
use App\Models\Operacion\Viaje_orden_model;
use App\Models\Operacion\Gasto_operativo_model;
use App\Models\Operacion\Vale_combustible_model;
use App\Models\Operacion\Vale_pago_model;
use App\Models\Tesoreria\Orden_pago_model;
use App\Models\Tesoreria\Caja_model;
use App\Models\Configuracion\Ajuste_avanzado_model;

class Utilidad extends BaseController
{
	public function __construct()
	{
		$this->Viaje_m = new Viaje_model();
		$this->Viaje_guia_m = new Viaje_guia_model();
		$this->Orden_m = new Orden_model();
		$this->Viaje_orden_m = new Viaje_orden_model();
		$this->Orden_pago_m = new Orden_pago_model();
		$this->Gasto_operativo_m = new Gasto_operativo_model();
		$this->Vale_combustible_m = new Vale_combustible_model();
		$this->Vale_pago_m = new Vale_pago_model();
		$this->Caja_m = new Caja_model();
		$this->Ajuste_avanzado_m = new Ajuste_avanzado_model();
	}

	public function index()
	{
		$data_request = $this->request->getGet();

		$ajuste = $this->Ajuste_avanzado_m->where('id_empresa', ID_EMPRESA)->first();

		$response = $this->Viaje_m->select('viaje.*, concat(serie,"-",numero) as viaje')
		->select('cond.nombre_completo as conductor')
		->select('r.punto_inicio, r.punto_final')
		->select('v.placa as vehiculo, v.serie_chasis as serie_chasis')
		->select('vr.placa as remolque')
		->join('personal cond', 'cond.id = viaje.id_conductor', 'left')
		->join('ruta r', 'r.id = viaje.id_ruta', 'left')
		->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
		->join('vehiculo vr', 'vr.id = viaje.id_remolque', 'left')

		->where('DATE_FORMAT(viaje.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(viaje.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])
		->where('viaje.id_empresa', ID_EMPRESA)		
		->where('viaje.fl_estado', 1)
		->findAll();

		foreach ($response as $row) {

			$ordenes = $this->Viaje_orden_m->select('orden.*, concat(orden.serie,"-",orden.numero) as orden')
			->select('coalesce(c.razon_social, "") as cliente')
			->select('sc.razon_social as subcliente')
			->select('concat(r.punto_inicio," - ",r.punto_final) as ruta')
			->select('mo.nombre as moneda, mo.simbolo as moneda_simbolo')
			->select('coalesce(concat(v.serie,"-",v.numero), "") as viaje, v.estado_operacion')
			->select('mf.nombre as moneda_factura, mf.simbolo as moneda_simbolo_factura')
			->select('coalesce(concat(f.serie,"-",f.numero), "") as factura, f.fecha as fecha_factura, f.total_importe as total_factura, f.tipo_cambio as tipo_cambio_factura')
			->join('orden', 'orden.id = viaje_orden.id_orden', 'left')
			->join('cliente c', 'c.id = orden.id_cliente', 'left')
			->join('subcliente sc', 'sc.id = orden.id_subcliente', 'left')
			->join('ruta r', 'r.id = orden.id_ruta', 'left')
			->join('static_moneda mo', 'mo.id = orden.id_moneda')			
			->join('viaje v', 'v.id = viaje_orden.id_viaje', 'left')
			->join('factura f', 'f.id = orden.id_factura', 'left')
			->join('static_moneda mf', 'mf.id = f.id_moneda', 'left')
			->where('viaje_orden.id_viaje', $row->id)
			->findAll();

			$total_importe_ordenes = 0;

			foreach ($ordenes as $orden) {

				$orden->fecha_factura = ($orden->fecha_factura != null) ? date("d/m/Y", strtotime($orden->fecha_factura)) : '';

				if($ajuste->fl_tesoreria_pago_importe_orden == 1)
				{
					/*** SEGÚN ORDENES */

					if(is_numeric($orden->tipo_cambio))
					{
						$orden->total_orden = $orden->total_orden * $orden->tipo_cambio;
					}

					$total_importe_ordenes = $total_importe_ordenes + $orden->total_orden;
				}
				else
				{
					if(is_numeric($orden->tipo_cambio_factura))
					{
						$orden->total_factura = $orden->total_factura * $orden->tipo_cambio_factura;
					}

					/*** SEGÚN FACTURAS */
					$total_importe_ordenes = $total_importe_ordenes + $orden->total_factura;
					$orden->total_orden = ($orden->total_factura != null) ? $orden->total_factura : 0;
					$orden->moneda = ($orden->moneda_factura != null) ? $orden->moneda_factura : '';
					$orden->moneda_simbolo = ($orden->moneda_simbolo_factura != null) ? $orden->moneda_simbolo_factura : '';
					$orden->tipo_cambio = ($orden->tipo_cambio_factura != null) ? $orden->tipo_cambio_factura : '';
				}		
				
				$orden->total_orden = number_format($orden->total_orden, 2, '.', '');
				

				/** GUIAS DE REMITENTE */
				$guias = $this->Viaje_guia_m->where('id_orden', $orden->id)
				->where('fl_estado', 1)
				->findAll();

				$array_guia = [];

				foreach ($guias as $guia) {
					$array_guia[] = $guia->serie.'-'.$guia->numero;
				}

				$orden->guia_remitente = implode(', ', $array_guia);

				/** PAGOS */
				$orden->fecha_pago = '';

				$pago = $this->Orden_pago_m->where('id_orden', $orden->id)
				->orderBy('fecha', 'desc')
				->first();

				if(is_object($pago))
				{
					$orden->fecha_pago = date("d/m/Y", strtotime($pago->fecha));
				}				
			}

			$row->ordenes = $ordenes;
			$row->cantidad_ordenes = count($ordenes);
			$row->total_importe_ordenes = number_format($total_importe_ordenes, 2, '.', '');

			/** GUIAS DE TRANSPORTISTA */
			$row->guia_transportista = $this->Viaje_guia_m->where('tipo', 'TRANSPORTISTA')
			->where('fl_estado', 1)
			->where('id_viaje', $row->id)->findAll();

			/** GUIAS DE TERCERO */
			$row->guia_tercero = $this->Viaje_guia_m->where('tipo', 'TERCERO')
			->where('fl_estado', 1)
			->where('id_viaje', $row->id)->findAll();

			/** GASTOS OPERATIVOS */
			$total_declaracion_gasto_operativo = 0;
			$row->gasto_operativo = $this->Gasto_operativo_m->select('gasto_operativo.*')
			->select('coalesce(tg.nombre, "") as tipo_gasto_operativo')
			->select('coalesce(m.simbolo, "") as simbolo_moneda')
			->join('tipo_gasto_operativo tg', 'tg.id = gasto_operativo.id_tipo_gasto_operativo', 'left')
			->join('static_moneda m', 'm.id = gasto_operativo.id_moneda', 'left')
			->where('tg.fl_no_liquidacion', null)
			->where('id_viaje', $row->id)->findAll();

			foreach ($row->gasto_operativo as $gasto) {

				if(is_numeric($gasto->tipo_cambio))
				{
					$gasto->importe = $gasto->importe * $gasto->tipo_cambio;
					$gasto->importe = number_format($gasto->importe, 2, '.', '');
				}

				$total_declaracion_gasto_operativo = $total_declaracion_gasto_operativo + $gasto->importe;
			}

			/** VALE DE COMBUSTIBLE */
			$total_declaracion_vale_combustible = 0;

			$row->vale_combustible = $this->Vale_combustible_m->select('vale_combustible.*')
			->select('p.razon_social as proveedor')
			->select('coalesce(m.simbolo, "") as simbolo_moneda')
			->join('proveedor p', 'p.id = vale_combustible.id_proveedor', 'left')
			->join('static_moneda m', 'm.id = vale_combustible.id_moneda', 'left')
			->where('fl_estado', 1)
			->where('id_viaje', $row->id)
			->findAll();

			foreach ($row->vale_combustible as $vale) {

				if(is_numeric($vale->tipo_cambio))
				{
					$vale->importe = $vale->importe * $vale->tipo_cambio;
					$vale->importe = number_format($vale->importe , 2, '.', '');
				}

				$total_declaracion_vale_combustible = $total_declaracion_vale_combustible + $vale->importe;
			}


			/** VALES DE PAGO */
			$total_declaracion_vale_pago = 0;

			$row->vale_pago = $this->Vale_pago_m->select('vale_pago.*')
			->select('p.razon_social as proveedor')
			->select('coalesce(m.simbolo, "") as simbolo_moneda')
			->join('proveedor p', 'p.id = vale_pago.id_proveedor', 'left')
			->join('static_moneda m', 'm.id = vale_pago.id_moneda', 'left')
			->where('fl_estado', 1)
			->where('id_viaje', $row->id)
			->findAll();

			foreach ($row->vale_pago as $vale) {

				if(is_numeric($vale->tipo_cambio))
				{
					$vale->importe = $vale->importe * $vale->tipo_cambio;
					$vale->importe = number_format($vale->importe , 2, '.', '');
				}

				$total_declaracion_vale_pago = $total_declaracion_vale_pago + $vale->importe;
			}
			
			/********************** */


			$total_gasto_operativo = 0;
			$total_combustible = 0; 
			$total_otros = 0;

			$total_gasto_operativo = $total_declaracion_gasto_operativo;
			$total_combustible = $total_declaracion_vale_combustible; 
			$total_otros = $total_declaracion_vale_pago;

			/* CAJA
			$row->salida_caja = $this->Caja_m->where('fl_estado', 3)
			->where('fl_no_liquidacion_viaje', null)
			->where('id_viaje', $row->id)->findAll();
			
			foreach ($row->salida_caja as $caja) {

				if(is_numeric($caja->tipo_cambio))
				{
					$caja->importe = $caja->importe * $caja->tipo_cambio;
				}

				if($caja->motivo == 'GASTOS OPERATIVOS' or $caja->motivo == 'SALDO DE LIQUIDACIÓN DE GASTOS OPERATIVOS')
				{
					$total_gasto_operativo = $total_gasto_operativo + $caja->importe;
				}
				else if($caja->motivo == 'COMBUSTIBLE')
				{
					$total_combustible = $total_combustible + $caja->importe;
				}	
				else if($caja->motivo == 'OTROS')
				{
					$total_otros = $total_otros + $caja->importe;
				}				
			}
				*/		
			
			$row->total_gasto_operativo = number_format($total_gasto_operativo, 2, '.', '');
			$row->total_combustible = number_format($total_combustible, 2, '.', '');
			$row->total_otros = number_format($total_otros, 2, '.', '');

			$total_gastos = $total_gasto_operativo + $total_combustible + $row->costo_tercerizado +$row->total_otros;

			$row->total_utilidad = number_format(($row->total_importe_ordenes - $total_gastos), 2, '.', '');

			$row->porc_utilidad = ($row->total_importe_ordenes > 0) ? ($row->total_utilidad * 100) / $row->total_importe_ordenes : ' - ';

			if(is_numeric($row->porc_utilidad))
			{
				$row->porc_utilidad = number_format($row->porc_utilidad, 2, '.', '');
			}
			
		}
		
		return $this->respond(['data' => $response], 200);
	}
		
}
