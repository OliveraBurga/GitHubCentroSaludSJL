<?php namespace App\Controllers\Reporte;

use App\Controllers\BaseController;

use App\Models\Operacion\Viaje_model;
use App\Models\Operacion\Orden_model;
use App\Models\Operacion\Viaje_guia_model;
use App\Models\Operacion\Viaje_orden_model;
use App\Models\Operacion\Gasto_operativo_model;
use App\Models\Operacion\Vale_combustible_model;
use App\Models\Tesoreria\Orden_pago_model;
use App\Models\Tesoreria\Caja_model;

class Utilidad extends BaseController
{
	public function __construct()
	{
		$this->Viaje_m = new Viaje_model();
		$this->Viaje_guia_m = new Viaje_guia_model();
		$this->Orden_m = new Orden_model();
		$this->Viaje_orden_m = new Viaje_orden_model();
		$this->Orden_pago_m = new Orden_pago_model();
		$this->Gasto_operativo_m = new Gasto_operativo_model();
		$this->Vale_combustible_m = new Vale_combustible_model();
		$this->Caja_m = new Caja_model();
	}

	public function index()
	{
		$data_request = $this->request->getGet();

		$response = $this->Viaje_m->select('viaje.*, concat(serie,"-",numero) as viaje')
		->select('cond.nombre_completo as conductor')
		->select('r.punto_inicio, r.punto_final')
		->select('v.placa as vehiculo')
		->select('vr.placa as remolque')
		->join('personal cond', 'cond.id = viaje.id_conductor', 'left')
		->join('ruta r', 'r.id = viaje.id_ruta', 'left')
		->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
		->join('vehiculo vr', 'v.id = viaje.id_remolque', 'left')

		->where('DATE_FORMAT(viaje.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(viaje.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])
		->where('viaje.id_empresa', ID_EMPRESA)		
		->where('viaje.fl_estado', 1)
		->where('viaje.estado_operacion', 'FINALIZADO')
		->findAll();

		foreach ($response as $row) {

			$ordenes = $this->Viaje_orden_m->select('orden.*, concat(orden.serie,"-",orden.numero) as orden')
			->select('coalesce(c.razon_social, "") as cliente')
			->select('sc.razon_social as subcliente')
			->select('concat(r.punto_inicio," - ",r.punto_final) as ruta')
			->select('m.nombre as moneda')
			->select('coalesce(concat(v.serie,"-",v.numero), "") as viaje, v.estado_operacion')
			->select('coalesce(concat(f.serie,"-",f.numero), "") as factura, f.fecha as fecha_factura')
			->join('orden', 'orden.id = viaje_orden.id_orden', 'left')
			->join('cliente c', 'c.id = orden.id_cliente', 'left')
			->join('subcliente sc', 'sc.id = orden.id_subcliente', 'left')
			->join('ruta r', 'r.id = orden.id_ruta', 'left')
			->join('static_moneda m', 'm.id = orden.id_moneda')
			->join('viaje v', 'v.id = viaje_orden.id_viaje', 'left')
			->join('factura f', 'f.id = orden.id_factura', 'left')
			->where('viaje_orden.id_viaje', $row->id)
			->findAll();

			$total_importe_ordenes = 0;

			foreach ($ordenes as $orden) {

				$orden->fecha_factura = ($orden->fecha_factura != null) ? date("d/m/Y", strtotime($orden->fecha_factura)) : '';

				$total_importe_ordenes = $total_importe_ordenes + $orden->total_orden;

				/** GUIAS DE REMITENTE */
				$guias = $this->Viaje_guia_m->where('id_orden', $orden->id)
				->where('fl_estado', 1)
				->findAll();

				$array_guia = [];

				foreach ($guias as $guia) {
					$array_guia[] = $guia->serie.'-'.$guia->numero;
				}

				$orden->guia_remitente = implode(', ', $array_guia);

				/** PAGOS */
				$orden->fecha_pago = '';

				if($orden->fl_pagado == 1)
				{
					$pago = $this->Orden_pago_m->where('id_orden', $orden->id)
					->orderBy('fecha', 'desc')
					->first();

					$orden->fecha_pago = date("d/m/Y", strtotime($pago->fecha));
				}				
			}

			$row->ordenes = $ordenes;
			$row->cantidad_ordenes = count($ordenes);
			$row->total_importe_ordenes = $total_importe_ordenes;

			/** GUIAS DE TRANSPORTISTA */
			$row->guia_transportista = $this->Viaje_guia_m->where('tipo', 'TRANSPORTISTA')
			->where('fl_estado', 1)
			->where('id_viaje', $row->id)->findAll();

			/** GUIAS DE TERCERO */
			$row->guia_transportista = $this->Viaje_guia_m->where('tipo', 'TERCERO')
			->where('fl_estado', 1)
			->where('id_viaje', $row->id)->findAll();

			/** GASTOS OPERATIVOS */
			$row->gasto_operativo = $this->Gasto_operativo_m->select('gasto_operativo.*')
			->select('coalesce(tg.nombre, "") as tipo_gasto_operativo')
			->join('tipo_gasto_operativo tg', 'tg.id = gasto_operativo.id_tipo_gasto_operativo', 'left')
			->where('id_viaje', $row->id)->findAll();

			/** VALE DE COMBUSTIBLE */
			$row->vale_combustible = $this->Vale_combustible_m->select('vale_combustible.*')
			->select('p.razon_social as proveedor')
			->join('proveedor p', 'p.id = vale_combustible.id_proveedor', 'left')
			->where('id_viaje', $row->id)->findAll();

			$total_vale_combustible = 0;
			foreach ($row->vale_combustible as $vale) {
				$total_vale_combustible = $total_vale_combustible + $vale->importe;
			}

			/** CAJA */
			$total_caja = 0;
			$row->salida_caja = $this->Caja_m->where('fl_estado', 3)
			->where('id_viaje', $row->id)->findAll();

			$total_gasto_operativo = 0;
			$total_combustible = 0;

			foreach ($row->salida_caja as $caja) {
				if($caja->motivo == 'GASTOS OPERATIVOS')
				{
					$total_gasto_operativo = $total_gasto_operativo + $caja->importe;
				}
				else if($caja->motivo == 'COMBUSTIBLE')
				{
					$total_combustible = $total_combustible + $caja->importe;
				}				
			}
			
			$row->total_gasto_operativo = $total_gasto_operativo;
			$row->total_combustible = $total_combustible;

			$row->total_utilidad = $row->total_importe_ordenes - ($total_gasto_operativo + $total_combustible + $row->costo_tercerizado);
			$row->total_utilidad = number_format($row->total_utilidad, 2, '.', '');

		}
		
		return $this->respond(['data' => $response], 200);
	}
		
}
