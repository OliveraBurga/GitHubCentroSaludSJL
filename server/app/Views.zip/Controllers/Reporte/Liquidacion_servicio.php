<?php namespace App\Controllers\Reporte;

use App\Controllers\BaseController;

use App\Models\Operacion\Viaje_orden_model;
use App\Models\Operacion\Viaje_guia_model;

class Liquidacion_servicio extends BaseController
{
	public function index()
	{
		$data_request = $this->request->getGet();

		$Viaje_orden_m = new Viaje_orden_model();
		$Viaje_guia_m = new Viaje_guia_model();

		$response = $Viaje_orden_m->select('orden.id as id_orden, concat(orden.serie,"-",orden.numero) as orden, orden.cantidad_medida, orden.orden_servicio, orden.total_orden')
		->select('viaje.id as id_viaje, concat(viaje.serie,"-",viaje.numero) as viaje')
		->select('concat(ruta.punto_inicio, " - ", ruta.punto_final) as ruta')
		->select('cond.nombre_completo as conductor')
		->select('cliente.razon_social as cliente')
		->select('v.placa as vehiculo, v.serie_chasis')
		->select('vr.placa as remolque')
		->select('coalesce(concat(f.serie,"-",f.numero), "") as factura, f.total_importe as total_factura, f.total_igv')
		->select('lt.numero_factura as factura_tercero')
		->select('m.nombre as moneda, m.simbolo as moneda_simbolo')
		->select('coalesce(l.descripcion, "") as local')
		->select('pr.razon_social as proveedor')
		->select('tf.tipo_medida')

		->join('orden', 'orden.id = viaje_orden.id_orden', 'left')
		->join('static_moneda m', 'm.id = orden.id_moneda', 'left')
		->join('viaje', 'viaje.id = viaje_orden.id_viaje', 'left')
		->join('ruta', 'ruta.id = orden.id_ruta', 'left', 'left')
		->join('personal cond', 'cond.id = viaje.id_conductor', 'left')
		->join('cliente', 'cliente.id = orden.id_cliente', 'left')
		->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
		->join('vehiculo vr', 'vr.id = viaje.id_remolque', 'left')
		->join('proveedor pr', 'pr.id = v.id_proveedor', 'left')
		->join('factura f', 'f.id = orden.id_factura', 'left')
		->join('liquidacion_tercero lt', 'lt.id = viaje.id_liquidacion_tercero', 'left')
		->join('local l', 'l.id = orden.id_local', 'left')
		->join('tarifa tf', 'tf.id = orden.id_tarifa', 'left')
		->where('DATE_FORMAT(orden.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(orden.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"]);

		if($data_request["id_orden"] != '')
		{
			$response->where('viaje_orden.id_orden', $data_request["id_orden"]);
		}

		if($data_request["id_viaje"] != '')
		{
			$response->where('viaje_orden.id_viaje', $data_request["id_viaje"]);
		}

		$response = $response->where('orden.id_empresa', ID_EMPRESA)		
		->findAll();	

		foreach ($response as $row) {

			if($row->id_viaje != null)
			{
				$guias = $Viaje_guia_m->where('(id_orden = '.$row->id_orden.' or id_viaje = '.$row->id_viaje.')')->where('fl_estado', 1)->findAll();
			}
			else
			{
				$guias = $Viaje_guia_m->where('id_orden', $row->id_viaje)->where('fl_estado', 1)->findAll();
			}
			

			$guia_remitente = [];
			$guia_transportista = [];
			$guia_tercero = [];

			foreach ($guias as $guia) {
				
				switch ($guia->tipo) {
					case 'REMITENTE':
						$guia_remitente[] = $guia->serie.'-'.$guia->numero;
					break;
					
					case 'TRANSPORTISTA':
						$guia_transportista[] = $guia->serie.'-'.$guia->numero;
					break;

					case 'TERCERO':
						$guia_tercero[] = $guia->serie.'-'.$guia->numero;
					break;
				}
			}

			$row->guia_remitente = implode(', ', $guia_remitente);
			$row->guia_transportista = implode(', ', $guia_transportista);
			$row->guia_tercero = implode(', ', $guia_tercero);

		}

		return $this->respond(['data' => $response], 200);
	}	
		
}