<?php namespace App\Controllers\Reporte;

use App\Controllers\BaseController;

use App\Models\Operacion\Viaje_model;
use App\Models\Operacion\Orden_model;
use App\Models\Operacion\Viaje_guia_model;
use App\Models\Operacion\Viaje_orden_model;
use App\Models\Operacion\Gasto_operativo_model;
use App\Models\Operacion\Vale_combustible_model;
use App\Models\Tesoreria\Orden_pago_model;
use App\Models\Tesoreria\Caja_model;
use App\Models\Configuracion\Ajuste_avanzado_model;
use App\Models\Configuracion\Empresa_model;

class Orden_viaje extends BaseController
{
	public function __construct()
	{
		$this->Viaje_m = new Viaje_model();
		$this->Viaje_guia_m = new Viaje_guia_model();
		$this->Orden_m = new Orden_model();
		$this->Viaje_orden_m = new Viaje_orden_model();
		$this->Orden_pago_m = new Orden_pago_model();
		$this->Gasto_operativo_m = new Gasto_operativo_model();
		$this->Vale_combustible_m = new Vale_combustible_model();
		$this->Caja_m = new Caja_model();
		$this->Empresa_m = new Empresa_model();
	}

	public function index()
	{
		$data_request = $this->request->getGet();

		$ajuste = $this->Ajuste_avanzado_m->where('id_empresa', ID_EMPRESA)->first();
		
		$response = $this->Viaje_m->select('viaje.*, concat(serie,"-",numero) as viaje')
		->select('cond.nombre_completo as conductor')
		->select('r.punto_inicio, r.punto_final')
		->select('v.placa as vehiculo, v.serie_chasis as serie_chasis')
		->select('vr.placa as remolque')
		->join('personal cond', 'cond.id = viaje.id_conductor', 'left')
		->join('ruta r', 'r.id = viaje.id_ruta', 'left')
		->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
		->join('vehiculo vr', 'vr.id = viaje.id_remolque', 'left')

		->where('DATE_FORMAT(viaje.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(viaje.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])
		->where('viaje.id_empresa', ID_EMPRESA)		
		->where('viaje.fl_estado', 1)
		->findAll();
		
		return $this->respond(['data' => $response], 200);
	}

	public function print($id_viaje)
	{
		$ajuste = $this->Ajuste_avanzado_m->where('id_empresa', ID_EMPRESA)->first();
		$empresa = $this->Empresa_m->find(ID_EMPRESA);


		$response = $this->Viaje_m->select('viaje.*, concat(serie,"-",numero) as viaje')
		->select('cond.nombre_completo as conductor')
		->select('r.punto_inicio, r.punto_final')
		->select('v.placa as vehiculo, v.serie_chasis as serie_chasis, coalesce(v.marca, "") as vehiculo_marca, coalesce(v.modelo, "") as vehiculo_modelo, coalesce(v.serie_chasis) as vehiculo_serie_chasis')
		->select('vr.placa as remolque')
		->select('coalesce(vc.nombre, "") as vehiculo_clase')
		->join('personal cond', 'cond.id = viaje.id_conductor', 'left')
		->join('ruta r', 'r.id = viaje.id_ruta', 'left')
		->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
		->join('vehiculo vr', 'vr.id = viaje.id_remolque', 'left')
		->join('vehiculo_clase vc', 'vc.id = v.id_vehiculo_clase', 'left')
		->where('viaje.id', $id_viaje)	
		->first();

		$ordenes = $this->Viaje_orden_m->select('concat(orden.serie,"-",orden.numero) as orden, orden.total_orden, orden.tipo_cambio')
		->select('coalesce(c.razon_social, "") as cliente')
		->join('orden', 'orden.id = viaje_orden.id_orden', 'left')
		->join('cliente c', 'c.id = orden.id_cliente', 'left')
		->where('viaje_orden.id_viaje', $response->id)
		->findAll();

		$ordenes_servicio = [];
		$clientes = [];
		$total_importe_ordenes = 0;

		foreach ($ordenes as $row) {
			$ordenes_servicio[] = $row->orden;
			$clientes[] = $row->cliente;

			if(is_numeric($row->tipo_cambio))
			{
				$row->total_orden = $row->total_orden * $row->tipo_cambio;
			}

			$total_importe_ordenes = $total_importe_ordenes + $row->total_orden;
		}
		
		$response->ordenes_servicio = implode(", ", $ordenes_servicio);
		$response->clientes = implode(", ", $clientes);
		$response->total_importe_ordenes = number_format($total_importe_ordenes, 2, '.', '');

		/** GUIAS DE TRANSPORTISTA */
		$guias = $this->Viaje_guia_m->where('tipo', 'TRANSPORTISTA')
		->where('fl_estado', 1)
		->where('id_viaje', $response->id)
		->findAll();

		$guias_transportista = [];

		foreach ($guias as $row) {
			$guias_transportista[] = $row->serie.'-'.$row->numero;
		}

		$response->guias_transportista = implode(", ", $guias_transportista);

		/** GASTOS OPERATIVOS */
		$response->gastos_operativos = $this->Gasto_operativo_m->select('gasto_operativo.*')
		->select('coalesce(tg.nombre, "") as tipo_gasto_operativo')
		->select('coalesce(m.simbolo, "") as simbolo_moneda')
		->join('tipo_gasto_operativo tg', 'tg.id = gasto_operativo.id_tipo_gasto_operativo', 'left')
		->join('static_moneda m', 'm.id = gasto_operativo.id_moneda', 'left')
		->where('id_viaje', $response->id)->findAll();

		$total_gasto_operativo = 0;

		foreach ($response->gastos_operativos as $row) {

			if(is_numeric($row->tipo_cambio))
			{
				$row->importe = $row->importe * $row->tipo_cambio;
			}

			$total_gasto_operativo = $total_gasto_operativo + $row->importe;
		}
		
		$response->total_gasto_operativo = number_format($total_gasto_operativo, 2, '.', '');

		/** VALE DE COMBUSTIBLE */
		$response->vales_combustible = $this->Vale_combustible_m->select('vale_combustible.*')
		->select('p.razon_social as proveedor')
		->select('coalesce(m.simbolo, "") as simbolo_moneda')
		->join('proveedor p', 'p.id = vale_combustible.id_proveedor', 'left')
		->join('static_moneda m', 'm.id = vale_combustible.id_moneda', 'left')
		->where('id_viaje', $response->id)->findAll();

		$total_combustible = 0;

		foreach ($response->vales_combustible as $row) {

			if(is_numeric($row->tipo_cambio))
			{
				$row->importe = $row->importe * $row->tipo_cambio;
			}

			$total_combustible = $total_combustible + $row->importe;
		}
		
		$response->total_combustible = number_format($total_combustible, 2, '.', '');

		/** CAJA */
		$response->cajas = $this->Caja_m->select('caja.*')
		->select('m.simbolo as simbolo_moneda')
		->join('static_moneda m', 'm.id = caja.id_moneda')
		->where('fl_estado', 3)
		->where('fl_no_liquidacion_viaje', null)
		->where('id_viaje', $response->id)
		->where('motivo', 'GASTOS OPERATIVOS')
		->findAll();	

		$total_caja = 0;

		foreach ($response->cajas as $row) {

			if(is_numeric($row->tipo_cambio))
			{
				$row->importe = $row->importe * $row->tipo_cambio;
			}
			
			$total_caja = $total_caja + $row->importe;
		}
		
		$response->total_caja = number_format($total_caja, 2, '.', '');

		$diferencia_pago_conductor  = $total_gasto_operativo - $total_caja;
		$response->total_pagar_conductor = ($diferencia_pago_conductor > 0) ? $diferencia_pago_conductor : 0;
		$response->total_pagar_conductor = number_format($response->total_pagar_conductor, 2, '.', '');

		// GANANCIA
		$response->total_ganancia = $total_importe_ordenes - ($total_gasto_operativo + $total_combustible + $response->costo_tercerizado);
		$response->total_ganancia = number_format($response->total_ganancia, 2, '.', '');

		$response->ajuste = $ajuste;
		$response->empresa = $empresa;

		return $this->respond($response, 200);
	}
		
}
