<?php namespace App\Controllers\Reporte;

use App\Controllers\BaseController;

use App\Models\Tesoreria\Liquidacion_tercero_model;

class Sunat_detraccion extends BaseController
{
	public function __construct()
	{
		$this->Liquidacion_tercero_m = new Liquidacion_tercero_model();
	}

	public function index()
	{
		$data_request = $this->request->getGet();

		$response = $this->Liquidacion_tercero_m->select('liquidacion_tercero.*')
		->select('pr.razon_social as razon_social_proveedor, pr.numero_documento as numero_documento_proveedor')
		->select('d.codigo_sunat as codigo_sunat_documento_proveedor')
		->join('viaje', 'viaje.id = liquidacion_tercero.id_viaje')
		->join('vehiculo vh', 'vh.id = viaje.id_vehiculo', 'left')
		->join('proveedor pr', 'pr.id = vh.id_proveedor', 'left')
		->join('static_documento d', 'd.id = pr.id_documento', 'left')

		->where('DATE_FORMAT(liquidacion_tercero.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(liquidacion_tercero.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])
		->where('liquidacion_tercero.id_empresa', ID_EMPRESA)		
		->where('liquidacion_tercero.fl_estado', 1)
		->findAll();

		$contador = 0;
		foreach ($response as $row) {
			$contador++;

			$row->periodo = date("Ym", strtotime($row->fecha));
			$row->numero_prod = '00';
			$row->tipo_operacion = '01';
			$row->tipo_comprobante = '01';

			$row->numero_registro = $contador;
		}

		if(!isset($data_request["exportar"]))
		{
			return $this->respond(['data' => $response], 200);
		}
		else
		{
			/** EXPORTAR EXCEL */
			require_once APPPATH."Libraries/phpexcel/PHPExcel.php";
			$this->excel = \PHPExcel_IOFactory::load(WRITEPATH.'formatos/reportes/sunat_detraccion.xlsx');
			$this->excel->setActiveSheetIndex(0);

			$sheet = $this->excel->getActiveSheet();

			$n_fila = 9;

			foreach ($response as $row) {				

				$sheet->setCellValue("A".$n_fila, $row->numero_registro);
				$sheet->setCellValue("B".$n_fila, $row->codigo_sunat_documento_proveedor);
				$sheet->setCellValue("C".$n_fila, $row->numero_documento_proveedor);
				$sheet->setCellValue("D".$n_fila, $row->razon_social_proveedor);
				$sheet->setCellValue("E".$n_fila, $row->numero_prod);
				$sheet->setCellValue("F".$n_fila, $row->bien_servicio);
				$sheet->setCellValue("G".$n_fila, $row->banco_detraccion);
				$sheet->setCellValue("H".$n_fila, $row->total_detraccion);
				$sheet->setCellValue("I".$n_fila, $row->tipo_operacion);
				$sheet->setCellValue("J".$n_fila, $row->periodo);
				$sheet->setCellValue("K".$n_fila, $row->tipo_comprobante);
				$sheet->setCellValue("L".$n_fila, $row->serie_factura);
				$sheet->setCellValue("M".$n_fila, $row->numero_factura);

				$n_fila++;
			}

			header('Content-Type: application/vnd.ms-excel');
			header('Content-Disposition: attachment;filename="SUNAT_DETRACCION.xls"');
			header('Cache-Control: max-age=0');

			$objWriter = \PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');
			$objWriter->save('php://output');
		}
		
		
	}
		
}
