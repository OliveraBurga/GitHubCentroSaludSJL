<?php namespace App\Controllers\Reporte;

use App\Controllers\BaseController;

use App\Models\Configuracion\Personal_model;
use App\Models\Operacion\Viaje_model;

class Conductor extends BaseController
{
	public function __construct()
	{
		$this->Personal_m = new Personal_model();
		$this->Viaje_m = new Viaje_model();
	}

	public function index($retorno = false)
	{
		$data_request = $this->request->getGet();

		$response = $this->Personal_m->select('personal.*')
		->select('d.nombre as documento')
		->join('static_documento d', 'd.id = personal.id_documento', 'left')
		->where('tipo_personal', 'CONDUCTOR')
		->where('personal.id_empresa', ID_EMPRESA);

		if($data_request["id_conductor"] != '')
		{
			$response->where('personal.id', $data_request["id_conductor"]);
		}

		$response = $response->findAll();		

		foreach ($response as $row) {
			
			$viajes = $this->Viaje_m->select('viaje.fecha, concat(viaje.serie,"-",viaje.numero) as viaje')
			->select('concat(r.punto_inicio," - ",r.punto_final) as ruta')
			->select('v.placa as vehiculo')
			->select('vr.placa as remolque')
			->select('coalesce(p.razon_social, "") as proveedor')
			->select('c.razon_social as cliente')
			
			->join('ruta r', 'r.id = viaje.id_ruta', 'left')
			->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
			->join('vehiculo vr', 'vr.id = viaje.id_remolque', 'left')
			->join('proveedor p', 'p.id = v.id_proveedor', 'left')			
			
			->join('viaje_orden vo', 'vo.id_viaje = viaje.id')
			->join('orden o', 'o.id = vo.id_orden', 'left')
			->join('cliente c', 'c.id = o.id_cliente', 'left')
			
			->where('viaje.id_conductor', $row->id)
			->where('viaje.fl_estado', 1)
			->where('estado_operacion !=', 'REGISTRADO')

			->where('DATE_FORMAT(viaje.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        	->where('DATE_FORMAT(viaje.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])

			->findAll();

			$ultimo_viaje = $this->Viaje_m->select('concat(viaje.serie,"-",viaje.numero) as viaje, date_format(viaje.fecha, "%d/%m/%Y") as fecha')			
			->where('id_conductor', $row->id)
			->where('viaje.fl_estado', 1)
			->where('estado_operacion !=', 'REGISTRADO')
			->orderBy('viaje.id', 'desc')->findAll();

			$row->cantidad_viaje = count($viajes);
			$row->viajes = $viajes;
		}

		return $this->respond(['data' => $response], 200);
	}
		
}
