<?php namespace App\Controllers\Reporte;

use App\Controllers\BaseController;

use App\Models\Configuracion\Cliente_model;
use App\Models\Operacion\Viaje_model;

class Cliente extends BaseController
{
	public function __construct()
	{
		$this->Cliente_m = new Cliente_model();
		$this->Viaje_m = new Viaje_model();
	}

	public function index($retorno = false)
	{
		$data_request = $this->request->getGet();

		$response = $this->Cliente_m->select('cliente.*')
		->select('d.nombre as documento')
		->join('static_documento d', 'd.id = cliente.id_documento', 'left')
		->where('cliente.id_empresa', ID_EMPRESA);

		if($data_request["id_cliente"] != '')
		{
			$response->where('cliente.id', $data_request["id_cliente"]);
		}

		$response = $response->findAll();		

		foreach ($response as $row) {
			
			$viajes = $this->Viaje_m->select('viaje.fecha, concat(serie,"-",numero) as viaje')
			->select('cond.nombre_completo as conductor')
			->select('concat(r.punto_inicio," - ",r.punto_final) as ruta')
			->select('v.placa as vehiculo')
			->select('vr.placa as remolque')
			->select('coalesce(p.razon_social, "") as proveedor')

			->join('personal cond', 'cond.id = viaje.id_conductor', 'left')
			->join('ruta r', 'r.id = viaje.id_ruta', 'left')
			->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
			->join('vehiculo vr', 'vr.id = viaje.id_remolque', 'left')
			->join('proveedor p', 'p.id = v.id_proveedor', 'left')
			
			->where('fl_estado', 1)
			->where('estado_operacion !=', 'REGISTRADO')

			->where('DATE_FORMAT(viaje.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        	->where('DATE_FORMAT(viaje.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])
			->where("viaje.id in (select viaje.id from viaje_orden inner join orden o on o.id = viaje_orden.id_orden where o.id_cliente = ".$row->id.")")
			->findAll();


			$row->cantidad_viaje = count($viajes);
			$row->viajes = $viajes;
			$row->ultimo_viaje = '';
			$row->fecha_ultimo_viaje = '';
		}

		return $this->respond(['data' => $response], 200);
	}
		
}
