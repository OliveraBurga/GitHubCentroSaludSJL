<?php namespace App\Controllers\Reporte;

use App\Controllers\BaseController;

use App\Models\Operacion\Viaje_model;
use App\Models\Operacion\Viaje_orden_model;

class Programacion_viaje extends BaseController
{
	public function index()
	{
		$data_request = $this->request->getGet();

		$Viaje_m = new Viaje_model();
		$Viaje_orden_m = new Viaje_orden_model();

		$response = $Viaje_m->select('viaje.*, concat(serie,"-",numero) as viaje')
		->select('cond.nombre_completo as conductor')
		->select('r.punto_inicio, r.punto_final')
		->select('v.placa as vehiculo, v.serie_chasis')
		->select('vr.placa as remolque')
		->select('coalesce(pr.razon_social, "") as proveedor')
		->join('personal cond', 'cond.id = viaje.id_conductor', 'left')
		->join('ruta r', 'r.id = viaje.id_ruta', 'left')
		->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
		->join('vehiculo vr', 'v.id = viaje.id_remolque', 'left')
		->join('proveedor pr', 'pr.id = v.id_proveedor', 'left')
		->where('viaje.id_empresa', ID_EMPRESA)		
		->where('viaje.fl_estado', 1)
		->where('viaje.estado_operacion', 'REGISTRADO');

		if($data_request["id_cliente"] != '')
		{
			$response->where("viaje.id in (select id_viaje from viaje_orden vo inner join orden o on o.id = vo.id_orden inner join cliente c on c.id = o.id_cliente where o.id_cliente = '".$data_request["id_cliente"]."')");
		}

		$response = $response->findAll();

		foreach ($response as $row) {

			$row->ordenes = $Viaje_orden_m->select('orden.*, concat(orden.serie,"-",orden.numero) as orden')
			->select('coalesce(c.razon_social, "") as cliente')
			->select('sc.razon_social as subcliente')
			->join('orden', 'orden.id = viaje_orden.id_orden', 'left')
			->join('cliente c', 'c.id = orden.id_cliente', 'left')
			->join('subcliente sc', 'sc.id = orden.id_subcliente', 'left')
			->where('viaje_orden.id_viaje', $row->id)
			->findAll();			
		}

		return $this->respond(['data' => $response], 200);
	}	
		
}