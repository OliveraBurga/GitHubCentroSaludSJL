<?php namespace App\Controllers\Reporte;

use App\Controllers\BaseController;

use App\Models\Operacion\Viaje_orden_model;

class Viaje_monitoreo extends BaseController
{
	public function index()
	{
		$data_request = $this->request->getGet();

		$Viaje_orden_m = new Viaje_orden_model();

		$response = $Viaje_orden_m->select('viaje_monitoreo.*')
		->select('em.nombre as estado')
		->select("concat(v.serie,'-',v.numero) as viaje")
		->select('coalesce(p.razon_social, "") as proveedor')
		->select("concat(o.serie,'-',o.numero) as orden")
		->select('c.razon_social as cliente')
		->select('vh.placa as vehiculo, vh.serie_chasis')
		->select('cond.nombre_completo as conductor')
		->select('coalesce(concat(r.punto_inicio," - ",r.punto_final), "") as ruta')
		->join('orden o', 'o.id = viaje_orden.id_orden')
		->join('cliente c', 'c.id = o.id_cliente', 'left')
		->join('viaje v', 'v.id = viaje_orden.id_viaje')	
		->join('vehiculo vh', 'vh.id = v.id_vehiculo')	
		->join('proveedor p', 'p.id = vh.id_proveedor', 'left')	
		->join('personal cond', 'cond.id = v.id_conductor', 'left')	
		->join('ruta r', 'r.id = v.id_ruta', 'left')	
		->join('viaje_monitoreo', 'viaje_monitoreo.id_viaje = viaje_orden.id_viaje')
		->join('estado_monitoreo em', 'em.id = viaje_monitoreo.id_estado_monitoreo');
		
		if($data_request["id_viaje"] != '' or $data_request["id_orden"] != '')
		{
			if($data_request["id_viaje"] != '')
			{
				$response->where('viaje_orden.id_viaje', $data_request["id_viaje"]);
			}
			else
			{
				$response->where('viaje_orden.id_orden', $data_request["id_orden"]);
			}
		}
		else
		{
			$response->where('DATE_FORMAT(viaje_monitoreo.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        	->where('DATE_FORMAT(viaje_monitoreo.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"]);
		}

		$response = $response->where('v.id_empresa', ID_EMPRESA)		
		->findAll();	

		return $this->respond(['data' => $response], 200);
	}	
		
}