<?php namespace App\Controllers\Reporte;

use App\Controllers\BaseController;

use App\Models\Facturacion\Factura_model;
use App\Models\Operacion\Orden_model;

class Factura extends BaseController
{
	public function __construct()
	{
		$this->Factura_m = new Factura_model();
		$this->Orden_m = new Orden_model();
	}

	public function index($retorno = false)
	{
		$data_request = $this->request->getGet();

		$response = $this->Factura_m->select('factura.*, concat(factura.serie,"-",factura.numero) as factura')		
		->select('c.nombre as comprobante, c.codigo_sunat as comprobante_codigo_sunat')	
		->select('ca.nombre as comprobante_afectado, ca.codigo_sunat as afectado_comprobante_codigo_sunat')		
		->select('d.codigo_sunat as documento_codigo_sunat')
		->select('m.simbolo as moneda_simbolo, m.codigo_contasis as moneda_codigo_contasis, m.nombre as moneda, m.codigo as codigo_moneda')
		->select('o.fl_pagado')
		->join('static_moneda m', 'm.id = factura.id_moneda', 'left')
		->join('static_documento d', 'd.id = factura.cliente_id_documento', 'left')
		->join('static_comprobante c', 'c.id = factura.id_comprobante', 'left')
		->join('static_comprobante ca', 'ca.id = factura.afectado_id_comprobante', 'left')
		->join('orden o', 'o.id = factura.id', 'left');

		if($data_request["serie"] != '' && $data_request["numero"] != '')
		{
			$response->where('factura.serie', $data_request["serie"]);
			$response->where('CAST(factura.numero AS UNSIGNED)', $data_request["numero"]);
		}
		else
		{
			$response->where('DATE_FORMAT(factura.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
			->where('DATE_FORMAT(factura.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"]);

			if($data_request["id_comprobante"] != '')
			{
				$response->where('factura.id_comprobante', $data_request["id_comprobante"]);
			}

			if($data_request["serie"] != '')
			{
				$response->where('factura.serie', $data_request["serie"]);
			}

			if($data_request["id_cliente"] != '')
			{
				$response->where('factura.id_cliente', $data_request["id_cliente"]);
			}
		}

		$response = $response->where('factura.id_empresa', ID_EMPRESA)	
		->where('factura.estado !=', 'ANULADO')		
		->findAll();

		foreach ($response as $row) {

			$notas_credito = $this->Factura_m->where('afectado_id_factura', $row->id)
			->where('id_tipo_nota_credito', 1)
			->orWhere("(afectado_serie = '".$row->serie."' and afectado_numero = '".$row->numero."')")
			->first();

			$row->fl_nota_credito = (is_object($notas_credito)) ? 1 : 0;
			
			$row->ordenes = $this->Orden_m->select('orden.fl_pagado')
			->select('op.*')			
			->join('(select * from orden_pago group by orden_pago.id_orden) op', 'op.id_orden = orden.id', 'left')
			->where('orden.id_factura', $row->id)
			->findAll();

		}

		return $this->respond(['data' => $response], 200);
	}
	
}
