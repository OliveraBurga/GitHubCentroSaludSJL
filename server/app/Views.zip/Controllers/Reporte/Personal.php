<?php namespace App\Controllers\Reporte;

use App\Controllers\BaseController;

use App\Models\Configuracion\Personal_model;

class Personal extends BaseController
{
	public function __construct()
	{
		$this->Personal_m = new Personal_model();
	}

	public function index($retorno = false)
	{
		$data_request = $this->request->getGet();

		$response = $this->Personal_m->select('personal.*')
		->select('e.razon_social as empresa')
		->select('c.razon_social as cliente')
		->select('d.nombre as documento')
		->join('empresa e', 'e.id = personal.id_empresa')
		->join('cliente c', 'c.id = personal.id_cliente', 'left')
		->join('static_documento d', 'd.id = personal.id_documento', 'left');

		if($data_request["id_cliente"] != '')
		{
			$response->where('personal.id_cliente', $data_request["id_cliente"]);
		}


		$response = $response->where('personal.id_empresa', ID_EMPRESA)		
		->findAll();		


		if($retorno)
		{
			return $response;
		}

		return $this->respond(['data' => $response], 200);
	}

	public function excel()
	{
		$response = $this->index(true);

		/** EXPORTAR EXCEL */
		require_once APPPATH."Libraries/phpexcel/PHPExcel.php";
		$this->excel = \PHPExcel_IOFactory::load(WRITEPATH.'formatos/reportes/personal.xlsx');
		$this->excel->setActiveSheetIndex(0);

		$sheet = $this->excel->getActiveSheet();

		$n_fila = 4;
		$item = 0;

		foreach ($response as $row) {
			$item++;

			$sheet->setCellValue("A".$n_fila, $item);
			$sheet->setCellValue("B".$n_fila, $row->apellido.' '.$row->nombre);
			$sheet->setCellValue("C".$n_fila, $row->empresa);
			$sheet->setCellValue("D".$n_fila, $row->cliente);
			$sheet->setCellValue("E".$n_fila, $row->numero_licencia);
			$sheet->setCellValue("F".$n_fila, $row->categoria_licencia);
			$sheet->setCellValue("G".$n_fila, $row->numero_documento);
			$sheet->setCellValue("H".$n_fila, $row->codigo_sap);
			$sheet->setCellValue("I".$n_fila, $row->pais);
			$sheet->setCellValue("J".$n_fila, $row->filtro_security);
			$sheet->setCellValue("K".$n_fila, $row->vigencia_filtro);
			$sheet->setCellValue("L".$n_fila, $row->fotocheck);
			$sheet->setCellValue("M".$n_fila, $row->licencia_interna);
			$sheet->setCellValue("N".$n_fila, $row->tipo_personal);
			$sheet->setCellValue("O".$n_fila, $row->hazmati);
			$sheet->setCellValue("P".$n_fila, $row->hazmatii);
			$sheet->setCellValue("Q".$n_fila, $row->capacitacion_mtc);
			$sheet->setCellValue("R".$n_fila, $row->certi_prim_auxilio);
			$sheet->setCellValue("S".$n_fila, $row->certi_man_defensivo);
			$sheet->setCellValue("T".$n_fila, $row->certi_man_extintor);
			$sheet->setCellValue("U".$n_fila, $row->portuaria_seguridad);
			$sheet->setCellValue("V".$n_fila, $row->proteccion_portuaria);
			$sheet->setCellValue("W".$n_fila, $row->curriculum);
			$sheet->setCellValue("X".$n_fila, $row->record);
			$sheet->setCellValue("Y".$n_fila, $row->otro);
			$sheet->setCellValue("Z".$n_fila, $row->antecedente_policial);
			$sheet->setCellValue("AA".$n_fila, $row->antecedente_penal);
			$sheet->setCellValue("AB".$n_fila, $row->trabajo_altura);
			$sheet->setCellValue("AC".$n_fila, $row->observacion);

			$n_fila++;
		}

		header('Content-Type: application/vnd.ms-excel');
		header('Content-Disposition: attachment;filename="PERSONAL_TRANSPORTE.xls"');
		header('Cache-Control: max-age=0');

		$objWriter = \PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');
		$objWriter->save('php://output');
	}
		
}
