<?php namespace App\Controllers\Reporte;

use App\Controllers\BaseController;

use App\Models\Configuracion\Vehiculo_model;
use App\Models\Configuracion\Vehiculo_compartimiento_model;

class Vehiculo extends BaseController
{
	public function __construct()
	{
		$this->Vehiculo_m = new Vehiculo_model();
		$this->Vehiculo_compartimiento_m = new Vehiculo_compartimiento_model();
	}

	public function index($retorno = false)
	{
		$data_request = $this->request->getGet();

		$response = $this->Vehiculo_m->select('vehiculo.*')
		->select('c.nombre_completo as conductor')
		->select('p.razon_social as proveedor')
		->select('vc.nombre as clase, vc.fl_compartimiento')
		->select('vr.placa as remolque')
		->select('e.razon_social as empresa')
		->select('pr.razon_social as proveedor')
		->join('personal c', 'c.id = vehiculo.id_conductor', 'left')
		->join('proveedor p', 'p.id = vehiculo.id_proveedor', 'left')
		->join('vehiculo_clase vc', 'vc.id = vehiculo.id_vehiculo_clase', 'left')
		->join('vehiculo vr', 'vr.id = vehiculo.id_remolque', 'left')
		->join('empresa e', 'e.id = vehiculo.id_empresa', 'left')
		->join('proveedor pr', 'pr.id = vehiculo.id_proveedor', 'left');

		if($data_request["id_vehiculo_clase"] != '')
		{
			$response->where('vehiculo.id_vehiculo_clase', $data_request["id_vehiculo_clase"]);
		}

		$response = $response->where('vehiculo.id_empresa', ID_EMPRESA)		
		->findAll();		

		foreach ($response as $row) {
			$row->compartimientos = $this->Vehiculo_compartimiento_m->where('id_vehiculo', $row->id)->findAll();
		}

		

		if($retorno)
		{
			return $response;
		}

		return $this->respond(['data' => $response], 200);
	}

	public function excel()
	{
		$data_request = $this->request->getGet();

		$response = $this->index(true);

		/** EXPORTAR EXCEL */
		require_once APPPATH."Libraries/phpexcel/PHPExcel.php";
		$this->excel = \PHPExcel_IOFactory::load(WRITEPATH.'formatos/reportes/vehiculo.xlsx');
		$this->excel->setActiveSheetIndex(0);

		$sheet = $this->excel->getActiveSheet();

		$n_fila = 7;
		$item = 0;

		foreach ($response as $row) {
			$item++;		
			

			$sheet->setCellValue("A".$n_fila, '');
			$sheet->setCellValue("B".$n_fila, $item);
			$sheet->setCellValue("C".$n_fila, $row->region);
			$sheet->setCellValue("D".$n_fila, $row->planta);
			$sheet->setCellValue("E".$n_fila, ($row->tipo_contratacion == 'PROPIO') ? $row->empresa : $row->proveedor);
			$sheet->setCellValue("F".$n_fila, $data_request["aprobacion_plan_contingencia"]);
			$sheet->setCellValue("G".$n_fila, $row->plan_contingencia);
			$sheet->setCellValue("H".$n_fila, $data_request["productos"]);
			$sheet->setCellValue("I".$n_fila, $row->ruta);
			$sheet->setCellValue("J".$n_fila, $row->clase);
			$sheet->setCellValue("K".$n_fila, $row->placa);
			$sheet->setCellValue("L".$n_fila, $row->tipo_contratacion);
			$sheet->setCellValue("M".$n_fila, $row->marca);
			$sheet->setCellValue("N".$n_fila, $row->modelo);
			$sheet->setCellValue("O".$n_fila, $row->ano_fabricacion);
			$sheet->setCellValue("P".$n_fila, '');
			$sheet->setCellValue("Q".$n_fila, '');
			$sheet->setCellValue("R".$n_fila, '');
			$sheet->setCellValue("S".$n_fila, '');
			$sheet->setCellValue("T".$n_fila, $row->capacidad_carga);			

			/*** COMPARTIMIENTOS  */

			if($row->fl_compartimiento == 1)
			{
				$sheet->setCellValue("U".$n_fila, count($row->compartimientos));

				$contador_comp = 0;

				foreach ($row->compartimientos as $compartimiento) {
					$contador_comp++;

					switch ($contador_comp) {
						case 1:
							$sheet->setCellValue("V".$n_fila, $compartimiento->capacidad_carga);
						break;
						
						case 2:
							$sheet->setCellValue("W".$n_fila, $compartimiento->capacidad_carga);
						break;

						case 3:
							$sheet->setCellValue("X".$n_fila, $compartimiento->capacidad_carga);
						break;

						case 4:
							$sheet->setCellValue("Y".$n_fila, $compartimiento->capacidad_carga);
						break;

						case 5:
							$sheet->setCellValue("Z".$n_fila, $compartimiento->capacidad_carga);
						break;

						case 6:
							$sheet->setCellValue("AA".$n_fila, $compartimiento->capacidad_carga);
						break;

						case 7:
							$sheet->setCellValue("AB".$n_fila, $compartimiento->capacidad_carga);
						break;

						case 8:
							$sheet->setCellValue("AC".$n_fila, $compartimiento->capacidad_carga);
						break;

						case 9:
							$sheet->setCellValue("AD".$n_fila, $compartimiento->capacidad_carga);
						break 2;
						
					}
				}
			}
			

			$sheet->setCellValue("AE".$n_fila, date("d-m-Y", strtotime($row->vencimiento_tarjeta_circu_tracto)));
			$sheet->setCellValue("AF".$n_fila, date("d-m-Y", strtotime($row->vencimiento_tarjeta_circu_cisterna)));
			$sheet->setCellValue("AG".$n_fila, $row->empresa_cubicacion);
			$sheet->setCellValue("AH".$n_fila, $row->numero_tarjeta_cubicacion);
			$sheet->setCellValue("AI".$n_fila, date("d-m-Y", strtotime($row->vencimiento_cubicacion)));
			$sheet->setCellValue("AJ".$n_fila, $row->tabla_aforo);
			$sheet->setCellValue("AK".$n_fila, $row->tapa_manhole);
			$sheet->setCellValue("AL".$n_fila, $row->scull_valvula_fondo);
			$sheet->setCellValue("AM".$n_fila, date("d-m-Y", strtotime($row->vencimiento_soat))); 
			$sheet->setCellValue("AN".$n_fila, date("d-m-Y", strtotime($row->vencimiento_inspec_tracto))); 
			$sheet->setCellValue("AO".$n_fila, date("d-m-Y", strtotime($row->vencimiento_inspec_cisterna)));
			$sheet->setCellValue("AP".$n_fila, $row->numero_dgh);
			$sheet->setCellValue("AQ".$n_fila, date("d-m-Y", strtotime($row->vencimiento_matpel))); 
			$sheet->setCellValue("AR".$n_fila, $row->empresa_aseguradora);
			$sheet->setCellValue("AS".$n_fila, date("d-m-Y", strtotime($row->vencimiento_poliza_millon_anual)));
			$sheet->setCellValue("AT".$n_fila, date("d-m-Y", strtotime($row->vencimiento_poliza_millon_mensual)));
			$sheet->setCellValue("AU".$n_fila, $row->tipologia_unidad);
			$sheet->setCellValue("AV".$n_fila, $row->unidad_dedicada);
			$sheet->setCellValue("AW".$n_fila, date("d-m-Y", strtotime($row->vencimiento_iqbf))); 
			$sheet->setCellValue("AX".$n_fila, $row->proveedor_gps);
			$sheet->setCellValue("AY".$n_fila, $row->plataforma_primax);
			$sheet->setCellValue("AZ".$n_fila, date("d-m-Y", strtotime($row->ultimo_mantenimiento_gps)));
			$sheet->setCellValue("BA".$n_fila, date("d-m-Y", strtotime($row->fecha_fabricacion_gps)));
			$sheet->setCellValue("BB".$n_fila, $row->modelo_gps);
			$sheet->setCellValue("BC".$n_fila, $row->tablet);
			$sheet->setCellValue("BD".$n_fila, $row->care_drive);
			$sheet->setCellValue("BE".$n_fila, $row->camara);
			$sheet->setCellValue("BF".$n_fila, $row->balones);
			$sheet->setCellValue("BG".$n_fila, $row->lanzas);
			$sheet->setCellValue("BH".$n_fila, $row->parches);
			$sheet->setCellValue("BI".$n_fila, $row->pagina_web_gps);
			$sheet->setCellValue("BJ".$n_fila, $row->pagina_usuario);
			$sheet->setCellValue("BK".$n_fila, $row->pagina_clave);

			$n_fila++;
		}

		header('Content-Type: application/vnd.ms-excel');
		header('Content-Disposition: attachment;filename="VEHICULOS_TRANSPORTE.xls"');
		header('Cache-Control: max-age=0');

		$objWriter = \PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');
		$objWriter->save('php://output');
	}
		
}
