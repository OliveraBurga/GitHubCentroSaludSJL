<?php namespace App\Controllers\Configuracion;

use App\Controllers\BaseController;

use App\Models\Configuracion\Vehiculo_marca_model;
use App\Models\Configuracion\Vehiculo_modelo_model;

class Vehiculo_marca extends BaseController
{
	public function __construct()
	{
		$this->Vehiculo_marca_m = new Vehiculo_marca_model();
		$this->Vehiculo_modelo_m = new Vehiculo_modelo_model();
	}

	public function get_select_modelo()
	{
		$data_request = $this->request->getGet();

		$response = $this->Vehiculo_modelo_m->select("vehiculo_modelo.id, vehiculo_modelo.nombre as text")
		->join('vehiculo_marca vm', 'vm.id = vehiculo_modelo.id_vehiculo_marca')
		->where('vm.nombre', $data_request["marca"])
		->where('vm.id_empresa', ID_EMPRESA)
		->findAll();

		return $this->respond($response, 200);
	}

	public function get_select_vehiculo_modelo()
	{
		$response = $this->Vehiculo_modelo_m->select('vehiculo_modelo.id, concat(vm.nombre," / ",vehiculo_modelo.nombre) as text')
		->join('vehiculo_marca vm', 'vm.id = vehiculo_modelo.id_vehiculo_marca')
		->where('vm.id_empresa', ID_EMPRESA)
		->findAll();

		return $this->respond($response, 200);
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response = $this->Vehiculo_marca_m->select("id, nombre as text")
		->where('id_empresa', ID_EMPRESA)
		->findAll();

		return $this->respond($response, 200);
	}

	public function index()
	{		
		$response = $this->Vehiculo_marca_m->where('id_empresa', ID_EMPRESA)		
		->findAll();

		foreach ($response as $row) {
			$row->modelos = $this->Vehiculo_modelo_m->where('id_vehiculo_marca', $row->id)->findAll();
		}

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('configuracion-vehiculo', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('configuracion-vehiculo', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			/** GUARDAR */
			$data = [
				'nombre'               => trim($data_request["nombre"]),
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$data["id_empresa"] = ID_EMPRESA;
			}

			$this->Vehiculo_marca_m->save($data);

			$id_vehiculo_marca = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			/******* SAVE MODELOS */

			$this->Vehiculo_modelo_m->where('id_vehiculo_marca', $id_vehiculo_marca)->delete();

			$data_detalle_modelo = [];

			foreach (json_decode($data_request["detalle_modelo"]) as $row) {

				$data_detalle_modelo[] = [
					'id_vehiculo_marca'				=> $id_vehiculo_marca,
					'nombre'						=> $row->nombre,
				];
			}

			if(count($data_detalle_modelo) > 0)
			{
				$this->Vehiculo_modelo_m->insertbatch($data_detalle_modelo);
			}


			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'CONFIGURACIÓN',
				'menu'			=> 'MARCA DE VEHÍCULOS',
				'accion'		=> (isset($data_request["id"])) ? 'EDITAR' : 'NUEVO',
				'descripcion'	=> trim($data_request["nombre"])
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */

			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('configuracion-vehiculo', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$vehiculo_marca = $this->Vehiculo_marca_m->find($data_request["id"]);

			$this->Vehiculo_marca_m->where('id', $data_request["id"])->delete();
			$this->Vehiculo_modelo_m->where('id_vehiculo_marca', $data_request["id"])->delete();

			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'CONFIGURACIÓN',
				'menu'			=> 'MARCA DE VEHÍCULOS',
				'accion'		=> 'ELIMINAR',
				'descripcion'	=> $vehiculo_marca->nombre
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */

			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
