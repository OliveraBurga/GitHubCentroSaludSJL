<?php namespace App\Controllers\Configuracion;

use App\Controllers\BaseController;

use App\Models\Configuracion\Cliente_model;
use App\Models\Configuracion\Subcliente_model;
use App\Models\Configuracion\Cliente_contacto_model;
use App\Models\Configuracion\Cuenta_bancaria_persona_model;
use App\Models\Configuracion\Tarifa_model;
use App\Models\Image_model;

class Cliente extends BaseController
{
	public function __construct()
	{
		$this->Cliente_m = new Cliente_model();
		$this->Cliente_contacto_m = new Cliente_contacto_model();
		$this->Subcliente_m = new Subcliente_model();
		$this->Cuenta_bancaria_persona_m = new Cuenta_bancaria_persona_model();
		$this->Tarifa_m = new Tarifa_model();
	}

	public function get_select_subcliente($id_cliente)
	{
		$response = $this->Subcliente_m->select("id, razon_social as text")
		->where('id_cliente', $id_cliente)
		->findAll();

		return $this->respond($response, 200);
	}

	public function get_select_contacto($id_cliente)
	{
		$response = $this->Cliente_contacto_m->select("id, nombre as text")
		->where('id_cliente', $id_cliente)
		->findAll();

		return $this->respond($response, 200);
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response = $this->Cliente_m->select("id, razon_social as text")
		->where('id_empresa', ID_EMPRESA)
		->findAll();

		return $this->respond($response, 200);
	}

	public function get_unique($id_cliente)
	{		
		$response = $this->Cliente_m->select('cliente.*')
		->select('coalesce(concat(u.id, " - ", u.departamento, " - ", u.provincia, " - ", u.distrito), "") as ubigeo')
		->join('static_ubigeo u', 'u.id = cliente.id_ubigeo', 'left')
		->where('cliente.id', $id_cliente)
		->where('id_empresa', ID_EMPRESA)		
		->first();

        return $this->respond($response, 200);
	}

	public function index()
	{		
		$response = $this->Cliente_m->select('cliente.*')
		->select('coalesce(concat(u.id, " - ", u.departamento, " - ", u.provincia, " - ", u.distrito), "") as ubigeo')
		->select('d.nombre as documento')
		->join('static_ubigeo u', 'u.id = cliente.id_ubigeo', 'left')
		->join('static_documento d', 'd.id = cliente.id_documento', 'left')
		->where('id_empresa', ID_EMPRESA)		
		->findAll();

		foreach ($response as $row) {
			
			$row->cuentas_bancarias = $this->Cuenta_bancaria_persona_m->where('id_cliente', $row->id)->findAll();
			$row->tarifas = $this->Tarifa_m->where('id_cliente', $row->id)->findAll();

			$row->subclientes = $this->Subcliente_m->select('subcliente.*, (select o.id as id_orden from orden as o where o.id_subcliente = subcliente.id limit 1) as id_orden')
			->where('id_cliente', $row->id)->findAll();

			$row->contactos = $this->Cliente_contacto_m->select('cliente_contacto.*, (select o.id as id_orden from orden as o where o.id_cliente_contacto = cliente_contacto.id limit 1) as id_orden')
			->where('id_cliente', $row->id)->findAll();
		}

        return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('configuracion-cliente', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('configuracion-cliente', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			/** GUARDAR IMAGEN */
			$Imagen_upload = new Image_model();			
			$imagen = $Imagen_upload->guardar($this->request->getFile('imagen'), 'cliente', (isset($data_request["imagen_anterior"])) ? $data_request["imagen_anterior"] : null);
					
			/** GUARDAR */
			$data = [
				'imagen'          			=> $imagen,
				'id_documento'              => trim($data_request["id_documento"]),
				'numero_documento'          => trim($data_request["numero_documento"]),
				'razon_social'              => trim($data_request["razon_social"]),
				'id_ubigeo'                 => (isset($data_request["id_ubigeo"])) ? trim($data_request["id_ubigeo"]) : null,
				'direccion'                 => trim($data_request["direccion"]),
				'telefono'                  => trim($data_request["telefono"]),
				'persona_encargado'         => trim($data_request["persona_encargado"]),
				'email'         			=> trim($data_request["email"]),
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$data["id_empresa"] = ID_EMPRESA;
			}

			$this->Cliente_m->save($data);

			$id_cliente = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			/****** SAVE CUENTAS BANCARIAS */

			$this->Helper->eliminar_registros_detalle('cuenta_bancaria_persona', 'id_cliente', $id_cliente, json_decode($data_request["detalle_cuenta_bancaria"]));

			foreach (json_decode($data_request["detalle_cuenta_bancaria"]) as $row) {
				$data_detalle_cuenta = [
					'id_cliente'	=> $id_cliente,
					'banco'			=> $row->banco,
					'tipo'			=> $row->tipo,
					'numero'		=> $row->numero,
					'full_data'		=> $row->banco.' - '.$row->tipo.' - '.$row->numero,
					'fl_detraccion'	=> $row->fl_detraccion,
				];

				if(is_numeric($row->id))
				{
					$data_detalle_cuenta["id"] = $row->id;
				}

				$this->Cuenta_bancaria_persona_m->save($data_detalle_cuenta);
			}

			/****** SAVE TARIFAS */

			$this->Helper->eliminar_registros_detalle('tarifa', 'id_cliente', $id_cliente, json_decode($data_request["detalle_tarifa"]));

			foreach (json_decode($data_request["detalle_tarifa"]) as $row) {

				$data_detalle_tarifa = [
					'id_cliente'			=> $id_cliente,
					'id_empresa'			=> ID_EMPRESA,
					'id_ruta'				=> $row->id_ruta,
					'tipo_servicio'			=> $row->tipo_servicio,
					'tipo_medida'			=> $row->tipo_medida,
					'costo_medida'			=> $row->costo_medida,
					'id_vehiculo_modelo'	=> (is_numeric($row->id_vehiculo_modelo)) ? $row->id_vehiculo_modelo  : null
				];

				if(is_numeric($row->id))
				{
					$data_detalle_tarifa["id"] = $row->id;
				}

				$this->Tarifa_m->save($data_detalle_tarifa);
			}

			/*** SAVE SUBCLIENTE */

			$this->Helper->eliminar_registros_detalle('subcliente', 'id_cliente', $id_cliente, json_decode($data_request["detalle_subcliente"]));

			foreach (json_decode($data_request["detalle_subcliente"]) as $row) {

				$data_detalle_subcliente = [
					'id_cliente'			=> $id_cliente,
					'id_documento'			=> $row->id_documento,
					'razon_social'			=> $row->razon_social,
					'numero_documento'		=> $row->numero_documento,
					'direccion'				=> $row->direccion,
					'email'					=> $row->email,
					'telefono'				=> $row->telefono,
				];

				if(is_numeric($row->id))
				{
					$data_detalle_subcliente["id"] = $row->id;
				}

				$this->Subcliente_m->save($data_detalle_subcliente);
			}


			/*** SAVE CONTACTOS DE CLIENTE */

			$this->Helper->eliminar_registros_detalle('cliente_contacto', 'id_cliente', $id_cliente, json_decode($data_request["detalle_contacto"]));

			foreach (json_decode($data_request["detalle_contacto"]) as $row) {

				$data_detalle_contacto = [
					'id_cliente'		=> $id_cliente,
					'nombre'			=> $row->nombre,
					'telefono'			=> $row->telefono,
					'email'				=> $row->email,
					'otros'				=> $row->otros,
				];

				if(is_numeric($row->id))
				{
					$data_detalle_contacto["id"] = $row->id;
				}

				$this->Cliente_contacto_m->save($data_detalle_contacto);
			}

			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'CONFIGURACIÓN',
				'menu'			=> 'CLIENTES',
				'accion'		=> (isset($data_request["id"])) ? 'EDITAR' : 'NUEVO',
				'descripcion'	=> trim($data_request["razon_social"])
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */

			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('configuracion-cliente', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$cliente = $this->Cliente_m->find($data_request["id"]);

			$this->Cuenta_bancaria_persona_m->where('id_cliente', $data_request["id"])->delete();
			$this->Cliente_m->where('id', $data_request["id"])
			->delete();
			
			/** ELIMINAR IMAGEN */
			$Imagen_upload = new Image_model();
			$Imagen_upload->eliminar($cliente->imagen);

			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'CONFIGURACIÓN',
				'menu'			=> 'CLIENTES',
				'accion'		=> 'ELIMINAR',
				'descripcion'	=> 	$cliente->razon_social
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
            
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
