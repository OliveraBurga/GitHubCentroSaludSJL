<?php namespace App\Controllers\Configuracion;

use App\Controllers\BaseController;

use App\Models\Configuracion\Ajuste_avanzado_model;
use App\Models\Configuracion\Moneda_model;

class Ajuste_avanzado extends BaseController
{
	public function __construct()
	{
		$this->Ajuste_avanzado_m = new Ajuste_avanzado_model();
		$this->Moneda_m = new Moneda_model();
	}

	public function index()
	{		 
		$data_request = $this->request->getGet();

		$response = $this->Ajuste_avanzado_m->find(ID_EMPRESA);

        return $this->respond($response, 200);
	}

	public function save()
	{
		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('configuracion-ajuste_avanzado', 'edit');

		$data_request = $this->request->getPost();
		
		try {
			
			$db = \Config\Database::connect();
			$db->transStart();		

			/** GUARDAR */
			$data = [
				'fl_viaje_cantidad_opcional'					=> (isset($data_request["fl_viaje_cantidad_opcional"])) ? 1: 0,
				'fl_factura_formato_customer'					=> (isset($data_request["fl_factura_formato_customer"])) ? 1: 0,
				'fl_proforma_formato_customer'					=> (isset($data_request["fl_proforma_formato_customer"])) ? 1: 0,
				'fl_orden_crear_viaje_autoselect'				=> (isset($data_request["fl_orden_crear_viaje_autoselect"])) ? 1: 0,
				'fl_viaje_monitoreo'							=> (isset($data_request["fl_viaje_monitoreo"])) ? 1: 0,
				'viaje_inicio_estado'							=> (isset($data_request["viaje_inicio_estado"])) ? trim($data_request["viaje_inicio_estado"]): null,
				'viaje_retornar_estado'							=> (isset($data_request["viaje_retornar_estado"])) ? trim($data_request["viaje_retornar_estado"]): null,
				'viaje_finalizar_estado'						=> (isset($data_request["viaje_finalizar_estado"])) ? trim($data_request["viaje_finalizar_estado"]): null,
				'fl_tesoreria_bloqueo_caja_orden_facturado'		=> (isset($data_request["fl_tesoreria_bloqueo_caja_orden_facturado"])) ? 1: 0,
				'fl_liquidacion_tercero_print_custom'			=> (isset($data_request["fl_liquidacion_tercero_print_custom"])) ? 1: 0,
				'operacion_viaje_terc_detraccion_opcion'		=> $data_request["operacion_viaje_terc_detraccion_opcion"],
				'operacion_viaje_terc_igv_opcion'				=> $data_request["operacion_viaje_terc_igv_opcion"],
				'fl_sistema_logo'								=> (isset($data_request["fl_sistema_logo"])) ? 1: 0,
				'fl_sistema_change_color'						=> (isset($data_request["fl_sistema_change_color"])) ? 1: 0,
				'sistema_color_bg'								=> $data_request["sistema_color_bg"],
				'fl_tesoreria_pago_importe_orden'				=> (isset($data_request["fl_tesoreria_pago_importe_orden"])) ? 1: 0,
				'fl_tesoreria_pago_detraccion_no_descuento'		=> (isset($data_request["fl_tesoreria_pago_detraccion_no_descuento"])) ? 1: 0,
				'fl_rep_ord_serv_custom'						=> (isset($data_request["fl_rep_ord_serv_custom"])) ? 1: 0,
				'fl_config_vehiculo_no_duplicidad'				=> (isset($data_request["fl_config_vehiculo_no_duplicidad"])) ? 1: 0,
				'fl_tesoreria_liq_tercero_desc_detrac'			=> (isset($data_request["fl_tesoreria_liq_tercero_desc_detrac"])) ? 1: 0,
				'fl_tesoreria_liq_escolta_desc_detrac'			=> (isset($data_request["fl_tesoreria_liq_escolta_desc_detrac"])) ? 1: 0,
				'id_empresa'									=> ID_EMPRESA
			];

			$this->Ajuste_avanzado_m->save($data);
			

			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'CONFIGURACIÓN',
				'menu'			=> 'AJUSTE AVANZADO',
				'accion'		=> 'EDITAR',
				'descripcion'	=> 'Ajuste general del sistema'
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */

			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function save_serie()
	{
		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('configuracion-ajuste_avanzado', 'edit');

		$data_request = $this->request->getPost();
		
		try {
			
			$db = \Config\Database::connect();
			$db->transStart();		

			/** GUARDAR */
			$data = [
				'operacion_serie_orden'							=> $data_request["operacion_serie_orden"],
				'operacion_serie_viaje'							=> $data_request["operacion_serie_viaje"],
				'operacion_serie_vale_combu'					=> $data_request["operacion_serie_vale_combu"],
				'operacion_serie_vale_pago'						=> $data_request["operacion_serie_vale_pago"],
				'tesoreria_serie_caja'							=> $data_request["tesoreria_serie_caja"],
				'almacen_serie_orden_comp'						=> $data_request["almacen_serie_orden_comp"],
				'id_empresa'									=> ID_EMPRESA
			];
			
			$this->Ajuste_avanzado_m->save($data);
			

			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'CONFIGURACIÓN',
				'menu'			=> 'AJUSTE AVANZADO',
				'accion'		=> 'EDITAR',
				'descripcion'	=> 'Series internos del Sistema'
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */

			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function save_global()
	{
		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('configuracion-ajuste_avanzado', 'edit');

		$data_request = $this->request->getPost();
		
		try {
			
			$db = \Config\Database::connect();
			$db->transStart();		

			/** GUARDAR */
			$data = [
				'porcentaje_detraccion'			=> $data_request["porcentaje_detraccion"],
				'porcentaje_igv'				=> $data_request["porcentaje_igv"],
				'id_empresa'					=> ID_EMPRESA
			];

			$this->Ajuste_avanzado_m->save($data);

			/*** VISTA PANEL TIPO CAMBIO */

			if(!is_numeric($data_request["id_moneda"]))
			{
				return $this->respond(['tipo' => 'warning', 'mensaje' => 'Moneda Tipo Cambio no establecido'], 400);
			}
			
			$data_tipo_cambio = [
				'tipo_cambio' 	=> $data_request["tipo_cambio"],
				'id'			=> $data_request["id_moneda"]
			];

			$this->Moneda_m->save($data_tipo_cambio);

			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'CONFIGURACIÓN',
				'menu'			=> 'AJUSTE AVANZADO',
				'accion'		=> 'EDITAR',
				'descripcion'	=> 'Parametros Globales'
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */

			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
			
}
