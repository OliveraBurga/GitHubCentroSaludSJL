<?php namespace App\Controllers\Configuracion;

use App\Controllers\BaseController;

use App\Models\Configuracion\Serie_model;

class Serie extends BaseController
{
	public function __construct()
	{
		$this->Serie_m = new Serie_model();
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response = $this->Serie_m->select("serie as id, serie as text");

		if(isset($data_request["tipo"]))
		{			
			$response->where('tipo', $data_request["tipo"]);
		}		

		if(isset($data_request["id_comprobante"]))
		{			
			$response->where('id_comprobante', $data_request["id_comprobante"]);
		}
		
		$response = $response->where('id_empresa', ID_EMPRESA)
		->findAll();
		
		return $this->respond($response, 200);
	}

	public function index()
	{		
		$response = $this->Serie_m->select('serie.*')
		->select('c.nombre as comprobante')
		->join('static_comprobante c', 'c.id = serie.id_comprobante', 'left')
		->where('id_empresa', ID_EMPRESA)		
		->findAll();

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('configuracion-serie', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('configuracion-serie', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			/** GUARDAR */
			$data = [
				'id_comprobante'            => trim($data_request["id_comprobante"]),
				'serie'          			=> trim($data_request["serie"]),
				'numero'              		=> trim($data_request["numero"]),
				'tipo'                 		=> trim($data_request["tipo"])
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$data["id_empresa"] = ID_EMPRESA;
			}

			$this->Serie_m->save($data);

			$id_serie = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			/****************** SAVE CENTINELA *****************/
			$serie = $this->Serie_m->select('c.nombre as comprobante, serie.*')
			->join('static_comprobante c', 'c.id = serie.id_comprobante')
			->where('serie.id', $id_serie)
			->first();

			$data_centinela = [
				'modulo'		=> 'CONFIGURACIÓN',
				'menu'			=> 'SERIES',
				'accion'		=> (isset($data_request["id"])) ? 'EDITAR' : 'NUEVO',
				'descripcion'	=> $serie->serie.'-'.$serie->numero.', '.$serie->comprobante
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('configuracion-serie', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$serie = $this->Serie_m->select('c.nombre as comprobante, serie.*')
			->join('static_comprobante c', 'c.id = serie.id_comprobante')
			->where('serie.id', $data_request["id"])
			->first();

			$this->Serie_m->where('id', $data_request["id"])->delete();

			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'CONFIGURACIÓN',
				'menu'			=> 'SERIES',
				'accion'		=> 'ELIMINAR',
				'descripcion'	=> $serie->serie.'-'.$serie->numero.', '.$serie->comprobante
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
