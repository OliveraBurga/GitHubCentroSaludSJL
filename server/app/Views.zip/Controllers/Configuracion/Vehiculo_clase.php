<?php namespace App\Controllers\Configuracion;

use App\Controllers\BaseController;

use App\Models\Configuracion\Vehiculo_clase_model;

class Vehiculo_clase extends BaseController
{
	public function __construct()
	{
		$this->Vehiculo_clase_m = new Vehiculo_clase_model();
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response = $this->Vehiculo_clase_m->select("id, nombre as text");

		$response = $response->where('id_empresa', ID_EMPRESA)	
		->findAll();
		return $this->respond($response, 200);
	}

	public function get_unique($id)
	{		
		$response = $this->Vehiculo_clase_m->find($id);

		return $this->respond($response, 200);
	}

	public function index()
	{		
		$response = $this->Vehiculo_clase_m->where('id_empresa', ID_EMPRESA)		
		->findAll();

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('configuracion-vehiculo', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('configuracion-vehiculo', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			/** GUARDAR */
			$data = [
				'nombre'             		=> trim($data_request["nombre"]),
				'json_config'        		=> trim($data_request["json_config"]),
				'fl_remolque'    			=> isset($data_request["fl_remolque"]) ? 1 : 0,
				'fl_compartimiento'    		=> isset($data_request["fl_compartimiento"]) ? 1 : 0,
				'identificador_vehiculo'	=> $data_request["identificador_vehiculo"],
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$data["id_empresa"] = ID_EMPRESA;
			}

			$this->Vehiculo_clase_m->save($data);

			$id_vehiculo_clase = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'CONFIGURACIÓN',
				'menu'			=> 'CLASES DE VEHÍCULOS',
				'accion'		=> (isset($data_request["id"])) ? 'EDITAR' : 'NUEVO',
				'descripcion'	=> trim($data_request["nombre"])
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('configuracion-vehiculo', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$vehiculo_clase = $this->Vehiculo_clase_m->find($data_request["id"]);

			$this->Vehiculo_clase_m->where('id', $data_request["id"])->delete();

			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'CONFIGURACIÓN',
				'menu'			=> 'CLASES DE VEHÍCULOS',
				'accion'		=> 'ELIMINAR',
				'descripcion'	=> $vehiculo_clase->nombre
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
