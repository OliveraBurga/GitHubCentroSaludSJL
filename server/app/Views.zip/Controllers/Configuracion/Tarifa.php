<?php namespace App\Controllers\Configuracion;

use App\Controllers\BaseController;

use App\Models\Configuracion\Tarifa_model;
use App\Models\Configuracion\Ruta_model;

class Tarifa extends BaseController
{
	public function __construct()
	{
		$this->Tarifa_m = new Tarifa_model();
		$this->Ruta_m = new Ruta_model();
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$select_query = "tarifa.costo_medida, '/', tarifa.tipo_medida, coalesce(concat(' / ', vma.nombre,' - ',vmo.nombre), '')";

		if(FL_OCULTAR_DATA == 1)
		{
			$select_query = "tarifa.tipo_medida, coalesce(concat(' / ', vma.nombre,' - ',vmo.nombre), '')";
		}

		$response_cliente = $this->Tarifa_m->select("tarifa.id, concat(tipo_servicio,' ', ".$select_query.") as text")

		->join('vehiculo_modelo vmo', 'vmo.id = tarifa.id_vehiculo_modelo', 'left')
		->join('vehiculo_marca vma', 'vma.id = vmo.id_vehiculo_marca', 'left')

		->where('tarifa.id_cliente', $data_request["id_cliente"])
		->where('tarifa.id_ruta', $data_request["id_ruta"])
		->where('tarifa.id_empresa', ID_EMPRESA)
		->findAll();

		$response = $this->Tarifa_m->select("tarifa.id, concat(tipo_servicio,' ', ".$select_query.") as text")

		->join('vehiculo_modelo vmo', 'vmo.id = tarifa.id_vehiculo_modelo', 'left')
		->join('vehiculo_marca vma', 'vma.id = vmo.id_vehiculo_marca', 'left')
		
		->where('tarifa.id_cliente', null)
		->where('tarifa.id_ruta', $data_request["id_ruta"])
		->where('tarifa.id_empresa', ID_EMPRESA)
		->findAll();

		$response = [
			'cliente'	=> $response_cliente,
			'libre'		=> $response
		];
		
		return $this->respond($response, 200);
	}

	public function get_unique($id_tarifa)
	{
		$response = $this->Tarifa_m->find($id_tarifa);

		return $this->respond($response, 200);
	}

	public function index()
	{		
		$response = $this->Tarifa_m->select('tarifa.*')
		->select("concat(r.punto_inicio, ' - ', r.punto_final) as ruta")
		->select('c.razon_social as cliente')
		->select("coalesce(concat(vma.nombre,' / ',vmo.nombre), '') as vehiculo_modelo")
		->join('ruta r', 'r.id = tarifa.id_ruta', 'left')
		->join('cliente c', 'c.id = tarifa.id_cliente', 'left')
		->join('vehiculo_modelo vmo', 'vmo.id = tarifa.id_vehiculo_modelo', 'left')
		->join('vehiculo_marca vma', 'vma.id = vmo.id_vehiculo_marca', 'left')
		->where('tarifa.id_empresa', ID_EMPRESA)		
		->findAll();

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('configuracion-tarifa', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('configuracion-tarifa', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			/** GUARDAR */
			$data = [
				'id_ruta'              	=> trim($data_request["id_ruta"]),
				'tipo_servicio'        	=> trim($data_request["tipo_servicio"]),
				'tipo_medida'          	=> trim($data_request["tipo_medida"]),
				'costo_medida'         	=> trim($data_request["costo_medida"]),
				'id_vehiculo_modelo'	=> (is_numeric($data_request["id_vehiculo_modelo"])) ? $data_request["id_vehiculo_modelo"] : null,
				'id_cliente'			=> (isset($data_request["id_cliente"]) and is_numeric($data_request["id_cliente"])) ? $data_request["id_cliente"] : null
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$data["id_empresa"] = ID_EMPRESA;
			}

			$this->Tarifa_m->save($data);

			$id_tarifa = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			/****************** SAVE CENTINELA *****************/
			$ruta = $this->Ruta_m->find($data_request["id_ruta"]);

			$data_centinela = [
				'modulo'		=> 'CONFIGURACIÓN',
				'menu'			=> 'TARIFAS',
				'accion'		=> (isset($data_request["id"])) ? 'EDITAR' : 'NUEVO',
				'descripcion'	=> trim($data_request["tipo_servicio"]).', '.$ruta->punto_inicio.' - '.$ruta->punto_final
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente', 'id_tarifa' => $id_tarifa], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('configuracion-tarifa', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$ruta = $this->Tarifa_m->join('ruta r', 'r.id = tarifa.id_ruta')
			->where('tarifa.id', $data_request["id"])
			->first();

			$this->Tarifa_m->where('id', $data_request["id"])->delete();

			/****************** SAVE CENTINELA *****************/			
			$data_centinela = [
				'modulo'		=> 'CONFIGURACIÓN',
				'menu'			=> 'TARIFAS',
				'accion'		=> 'ELIMINAR',
				'descripcion'	=> $ruta->tipo_servicio.', '.$ruta->punto_inicio.' - '.$ruta->punto_final
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
