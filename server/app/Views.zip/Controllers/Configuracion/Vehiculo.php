<?php namespace App\Controllers\Configuracion;

use App\Controllers\BaseController;

use App\Models\Configuracion\Vehiculo_model;
use App\Models\Configuracion\Vehiculo_km_model;
use App\Models\Configuracion\Vehiculo_clase_model;
use App\Models\Configuracion\Vehiculo_mantenimiento_model;
use App\Models\Configuracion\Vehiculo_llanta_model;
use App\Models\Configuracion\Vehiculo_compartimiento_model;
use App\Models\Configuracion\Tarifa_model;
use App\Models\Configuracion\Config_modulo_model;
use App\Models\Image_model;

class Vehiculo extends BaseController
{
	public function __construct()
	{
		$this->Vehiculo_m = new Vehiculo_model();
		$this->Vehiculo_km_m = new Vehiculo_km_model();
		$this->Vehiculo_clase_m = new Vehiculo_clase_model();
		$this->Config_modulo_m = new Config_modulo_model();
		$this->Vehiculo_mantenimiento_m = new Vehiculo_mantenimiento_model();
		$this->Vehiculo_llanta_m = new Vehiculo_llanta_model();
		$this->Tarifa_m = new Tarifa_model();
		$this->Vehiculo_compartimiento_m = new Vehiculo_compartimiento_model();
	}

	function get_configuracion()
	{
		$config_modulo = $this->Config_modulo_m->where('id_empresa', ID_EMPRESA)
		->first();

		$response = [
			'view_datatable'	=> $config_modulo->dt_configuracion_vehiculo
		];

		return $this->respond($response, 200);
	}

	public function get_select_tipo_carga()
	{

		$response = $this->Vehiculo_m->distinct('tipo_carga')
		->select("tipo_carga as text")
		->where('id_empresa', ID_EMPRESA)
		->findAll();

		return $this->respond($response, 200);
	}

	public function get_select_llanta($id_vehiculo)
	{
		$response = $this->Vehiculo_llanta_m->select("id, concat(codigo,' - ', posicion) as text")
		->where('id_vehiculo', $id_vehiculo)
		->findAll();

		return $this->respond($response, 200);
	}

	public function get_select_mantenimiento($id_vehiculo)
	{
		$response = $this->Vehiculo_mantenimiento_m->select("mantenimiento as text")
		->where('id_vehiculo', $id_vehiculo)
		->where('id_empresa', ID_EMPRESA)
		->findAll();

		return $this->respond($response, 200);
	}

	public function get_select_marca()
	{

		$response = $this->Vehiculo_m->distinct('marca')
		->select("marca as text")
		->where('id_empresa', ID_EMPRESA)
		->findAll();

		return $this->respond($response, 200);
	}

	public function get_select_modelo()
	{

		$response = $this->Vehiculo_m->distinct('modelo')
		->select("modelo as text")
		->where('id_empresa', ID_EMPRESA)
		->findAll();

		return $this->respond($response, 200);
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response = $this->Vehiculo_m->select("vehiculo.id, vehiculo.placa as text, placa, serie_chasis, vc.identificador_vehiculo")
		->join('vehiculo_clase vc', 'vc.id = vehiculo.id_vehiculo_clase', 'left');

		if(isset($data_request["tipo"]))
		{
			if($data_request["tipo"] == 'REMOLQUE')
			{
				$response->where('vc.fl_remolque', 1);
			}
			else
			{
				$response->where('vc.fl_remolque', 0);
			}			
		}

		$response = $response->where('vehiculo.id_empresa', ID_EMPRESA)
		->findAll();

		foreach ($response as $row) {
			
			if($row->identificador_vehiculo == 'PLACA')
			{
				$row->text = $row->placa;
			}
			else
			{
				$row->text = $row->serie_chasis.' '.(($row->placa != null && $row->placa != '') ? '('.$row->placa.')' : '');
			}
		}

		return $this->respond($response, 200);
	}

	public function get_unique($id_vehiculo)
	{		
		$response = $this->Vehiculo_m->select('vehiculo.*')
		->select('vc.nombre as clase, vc.fl_compartimiento, vc.fl_remolque')
		->join('vehiculo_clase vc', 'vc.id = vehiculo.id_vehiculo_clase')
		->where('vehiculo.id', $id_vehiculo)->first();

		$response->compartimientos = $this->Vehiculo_compartimiento_m->where('id_vehiculo', $response->id)->findAll();

        return $this->respond($response, 200);
	} 

	public function index()
	{		
		$response = $this->Vehiculo_m->select('vehiculo.*')
		->select('c.nombre_completo as conductor')
		->select('p.razon_social as proveedor')
		->select('vc.nombre as clase')
		->select('vr.placa as remolque')
		->join('personal c', 'c.id = vehiculo.id_conductor', 'left')
		->join('proveedor p', 'p.id = vehiculo.id_proveedor', 'left')
		->join('vehiculo_clase vc', 'vc.id = vehiculo.id_vehiculo_clase', 'left')
		->join('vehiculo vr', 'vr.id = vehiculo.id_remolque', 'left')
		->where('vehiculo.id_empresa', ID_EMPRESA)		
		->findAll();

		foreach ($response as $row) {
			$row->mantenimientos = $this->Vehiculo_mantenimiento_m->where('id_vehiculo', $row->id)->findAll();
			$row->llantas = $this->Vehiculo_llanta_m->where('id_vehiculo', $row->id)->findAll();
			$row->compartimientos = $this->Vehiculo_compartimiento_m->where('id_vehiculo', $row->id)->findAll();

			$row->cantidad_compartimientos = count($row->compartimientos);

			$ultimo_km = $this->Vehiculo_km_m->where('id_vehiculo', $row->id)->orderBy('fecha', 'desc')->orderBy('id', 'desc')->first();
			$row->km_actual = (is_object($ultimo_km)) ? $ultimo_km->km.'KM' : '0KM';
		}

        return $this->respond(['data' => $response], 200);
	}

	public function validar_duplicado($titulo, $tabla, $campo, $value, $id, $id_clase)
	{
		$db = \Config\Database::connect();

		$registro = $db->table($tabla)
		->where($campo, $value)
		->where('id_empresa', ID_EMPRESA)
		->where('id_vehiculo_clase', $id_clase)
		->get()->getRow();

		if($id != null)
		{
		if(is_object($registro))
		{
			if($registro->id != $id)
			{
			return ['tipo' => 'warning', 'mensaje' => $titulo. ' => '.$value.' ya existente'];
			}
		}
		}
		else
		{
		if(is_object($registro))
		{
			return ['tipo' => 'warning', 'mensaje' => $titulo. ' => '.$value.' ya existente'];
		}
		}

		return true;
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('configuracion-vehiculo', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('configuracion-vehiculo', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$ajuste = $this->Ajuste_avanzado_m->where('id_empresa', ID_EMPRESA)->first();

			if($ajuste->fl_config_vehiculo_no_duplicidad != 1)
			{
				/** VALIDAR DUPLICADO */
				$clase = $this->Vehiculo_clase_m->find($data_request["id_vehiculo_clase"]);			

				$campo_evaluar = 'placa';
				$dato_evaluar = trim($data_request["placa"]);

				if($clase->identificador_vehiculo == 'CHASIS')
				{
					$campo_evaluar = 'serie_chasis';
					$dato_evaluar = trim($data_request["serie_chasis"]);
				}

				$result_duplicado = $this->validar_duplicado($clase->identificador_vehiculo, 'vehiculo', $campo_evaluar,  $dato_evaluar, ((isset($data_request["id"])) ? $data_request["id"] : null), $data_request["id_vehiculo_clase"]);
				if(is_array($result_duplicado))
				{
					return $this->respond($result_duplicado, 400);
				}
			}			

			/** GUARDAR IMAGEN */
			$Imagen_upload = new Image_model();			
			$imagen = $Imagen_upload->guardar($this->request->getFile('imagen'), 'vehiculo', (isset($data_request["imagen_anterior"])) ? $data_request["imagen_anterior"] : null);
					
			/** GUARDAR */
			$data = [
				'imagen'          						=> $imagen,
				'placa'                     			=> (isset($data_request["placa"])) ? trim($data_request["placa"]) : null,
				'tipo_contratacion'         			=> (isset($data_request["tipo_contratacion"])) ? trim($data_request["tipo_contratacion"]) : null,
				'ano_fabricacion'           			=> (isset($data_request["ano_fabricacion"])) ? trim($data_request["ano_fabricacion"]) : null,
				'ano_modelo'                			=> (isset($data_request["ano_modelo"])) ? trim($data_request["ano_modelo"]) : null,
				'id_vehiculo_clase'         			=> $data_request["id_vehiculo_clase"],
				'marca'         						=> (isset($data_request["marca"])) ? trim($data_request["marca"]) : null,
				'modelo'        						=> (isset($data_request["modelo"])) ? trim($data_request["modelo"]) : null,
				'tipo_carga'       						=> (isset($data_request["tipo_carga"])) ? trim($data_request["tipo_carga"]) : '',
				'capacidad_carga'       				=> (isset($data_request["capacidad_carga"])) ? trim($data_request["capacidad_carga"]) : 0,
				'galones'                   			=> (isset($data_request["galones"])) ? trim($data_request["galones"]) : null,
				'id_remolque'           				=> (isset($data_request["id_remolque"]) && $data_request["id_remolque"] != '') ? trim($data_request["id_remolque"]) : null,
				'id_conductor'              			=> (isset($data_request["id_conductor"]) && $data_request["id_conductor"] != '') ? trim($data_request["id_conductor"]) : null,
				'id_proveedor'              			=> (isset($data_request["id_proveedor"]) && $data_request["id_proveedor"] != '') ? trim($data_request["id_proveedor"]) : null,
				'numero_motor'              			=> (isset($data_request["numero_motor"])) ? trim($data_request["numero_motor"]) : null,
				'serie_chasis'              			=> (isset($data_request["serie_chasis"])) ? trim($data_request["serie_chasis"]) : null,
				'color'                     			=> (isset($data_request["color"])) ? trim($data_request["color"]) : null,
				'cantidad_ruedas'           			=> (isset($data_request["cantidad_ruedas"])) ? trim($data_request["cantidad_ruedas"]) : null,
				'cantidad_cilindros'        			=> (isset($data_request["cantidad_cilindros"])) ? trim($data_request["cantidad_cilindros"]) : null,
				'cantidad_asientos'         			=> (isset($data_request["cantidad_asientos"])) ? trim($data_request["cantidad_asientos"]) : null,
				'cantidad_pasajeros'        			=> (isset($data_request["cantidad_pasajeros"])) ? trim($data_request["cantidad_pasajeros"]) : null,
				'cantidad_ejes'             			=> (isset($data_request["cantidad_ejes"])) ? trim($data_request["cantidad_ejes"]) : null,
				'mtc'                       			=> (isset($data_request["mtc"])) ? trim($data_request["mtc"]) : null,
				'peso_seco'                 			=> (isset($data_request["peso_seco"])) ? trim($data_request["peso_seco"]) : null,
				'peso_bruto'                			=> (isset($data_request["peso_bruto"])) ? trim($data_request["peso_bruto"]) : null,
				'carga_util'                			=> (isset($data_request["carga_util"])) ? trim($data_request["carga_util"]) : null,
				'hp_motor'                  			=> (isset($data_request["hp_motor"])) ? trim($data_request["hp_motor"]) : null,
				'longitud'                  			=> (isset($data_request["longitud"])) ? trim($data_request["longitud"]) : null,
				'altura'                    			=> (isset($data_request["altura"])) ? trim($data_request["altura"]) : null,
				'ancho'                     			=> (isset($data_request["ancho"])) ? trim($data_request["ancho"]) : null,
				'cantidad_pinas'            			=> (isset($data_request["cantidad_pinas"])) ? trim($data_request["cantidad_pinas"]) : null,
				'combustible'               			=> (isset($data_request["combustible"])) ? trim($data_request["combustible"]) : null,
				'carroceria'                			=> (isset($data_request["carroceria"])) ? trim($data_request["carroceria"]) : null,	

				'region'								=> (isset($data_request["region"])) ? trim($data_request["region"]) : null,	
				'planta'								=> (isset($data_request["planta"])) ? trim($data_request["planta"]) : null,	
				'plan_contingencia'						=> (isset($data_request["plan_contingencia"])) ? trim($data_request["plan_contingencia"]) : null,		
				'ruta'									=> (isset($data_request["ruta"])) ? trim($data_request["ruta"]) : null,	
				'vencimiento_tarjeta_circu_tracto'		=> (isset($data_request["vencimiento_tarjeta_circu_tracto"])) ? trim($data_request["vencimiento_tarjeta_circu_tracto"]) : null,	
				'vencimiento_tarjeta_circu_cisterna'	=> (isset($data_request["vencimiento_tarjeta_circu_cisterna"])) ? trim($data_request["vencimiento_tarjeta_circu_cisterna"]) : null,	
				'empresa_cubicacion'					=> (isset($data_request["empresa_cubicacion"])) ? trim($data_request["empresa_cubicacion"]) : null,	
				'numero_tarjeta_cubicacion'				=> (isset($data_request["numero_tarjeta_cubicacion"])) ? trim($data_request["numero_tarjeta_cubicacion"]) : null,	
				'vencimiento_cubicacion'				=> (isset($data_request["vencimiento_cubicacion"])) ? trim($data_request["vencimiento_cubicacion"]) : null,	
				'tabla_aforo'							=> (isset($data_request["tabla_aforo"])) ? trim($data_request["tabla_aforo"]) : null,	
				'tapa_manhole'							=> (isset($data_request["tapa_manhole"])) ? trim($data_request["tapa_manhole"]) : null,	
				'scull_valvula_fondo'					=> (isset($data_request["scull_valvula_fondo"])) ? trim($data_request["scull_valvula_fondo"]) : null,	
				'vencimiento_soat'						=> (isset($data_request["vencimiento_soat"])) ? trim($data_request["vencimiento_soat"]) : null,	
				'vencimiento_inspec_tracto'				=> (isset($data_request["vencimiento_inspec_tracto"])) ? trim($data_request["vencimiento_inspec_tracto"]) : null,		
				'vencimiento_inspec_cisterna'			=> (isset($data_request["vencimiento_inspec_cisterna"])) ? trim($data_request["vencimiento_inspec_cisterna"]) : null,	
				'numero_dgh'							=> (isset($data_request["numero_dgh"])) ? trim($data_request["numero_dgh"]) : null,	
				'vencimiento_matpel'					=> (isset($data_request["vencimiento_matpel"])) ? trim($data_request["vencimiento_matpel"]) : null,	
				'empresa_aseguradora'					=> (isset($data_request["empresa_aseguradora"])) ? trim($data_request["empresa_aseguradora"]) : null,		
				'vencimiento_poliza_millon_anual'		=> (isset($data_request["vencimiento_poliza_millon_anual"])) ? trim($data_request["vencimiento_poliza_millon_anual"]) : null,	
				'vencimiento_poliza_millon_mensual'		=> (isset($data_request["vencimiento_poliza_millon_mensual"])) ? trim($data_request["vencimiento_poliza_millon_mensual"]) : null,	
				'tipologia_unidad'						=> (isset($data_request["tipologia_unidad"])) ? trim($data_request["tipologia_unidad"]) : null,	
				'unidad_dedicada'						=> (isset($data_request["unidad_dedicada"])) ? trim($data_request["unidad_dedicada"]) : null,		
				'vencimiento_iqbf'						=> (isset($data_request["vencimiento_iqbf"])) ? trim($data_request["vencimiento_iqbf"]) : null,		
				'proveedor_gps'							=> (isset($data_request["proveedor_gps"])) ? trim($data_request["proveedor_gps"]) : null,		
				'plataforma'							=> (isset($data_request["plataforma"])) ? trim($data_request["plataforma"]) : null,	
				'ultimo_mantenimiento_gps'				=> (isset($data_request["ultimo_mantenimiento_gps"])) ? trim($data_request["ultimo_mantenimiento_gps"]) : null,		
				'fecha_fabricacion_gps'					=> (isset($data_request["fecha_fabricacion_gps"])) ? trim($data_request["fecha_fabricacion_gps"]) : null,		
				'modelo_gps'							=> (isset($data_request["modelo_gps"])) ? trim($data_request["modelo_gps"]) : null,	
				'tablet'								=> (isset($data_request["tablet"])) ? trim($data_request["tablet"]) : null,	
				'care_drive'							=> (isset($data_request["care_drive"])) ? trim($data_request["care_drive"]) : null,	
				'camara'								=> (isset($data_request["camara"])) ? trim($data_request["camara"]) : null,	
				'balones'								=> (isset($data_request["balones"])) ? trim($data_request["balones"]) : null,		
				'lanzas'								=> (isset($data_request["lanzas"])) ? trim($data_request["lanzas"]) : null,	
				'parches'								=> (isset($data_request["parches"])) ? trim($data_request["parches"]) : null,		
				'pagina_web_gps'						=> (isset($data_request["pagina_web_gps"])) ? trim($data_request["pagina_web_gps"]) : null,	
				'pagina_usuario'						=> (isset($data_request["pagina_usuario"])) ? trim($data_request["pagina_usuario"]) : null,	
				'pagina_clave'							=> (isset($data_request["pagina_clave"])) ? trim($data_request["pagina_clave"]) : null
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$data["id_empresa"] = ID_EMPRESA;
			}

			$this->Vehiculo_m->save($data);

			$id_vehiculo = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			/****** SAVE MANTENIMIENTOS */

			$this->Helper->eliminar_registros_detalle('vehiculo_mantenimiento', 'id_vehiculo', $id_vehiculo, json_decode($data_request["detalle_mantenimiento"]));

			foreach (json_decode($data_request["detalle_mantenimiento"]) as $row) {

				$data_detalle_mantenimiento = [
					'id_vehiculo'	=> $id_vehiculo,
					'mantenimiento'	=> $row->mantenimiento,
					'ciclo_km'		=> $row->ciclo_km,
					'alerta_km'		=> $row->alerta_km,
					'id_empresa'	=> ID_EMPRESA
				];

				if(is_numeric($row->id))
				{
					$data_detalle_mantenimiento["id"] = $row->id;
				}

				$this->Vehiculo_mantenimiento_m->save($data_detalle_mantenimiento);

			}

			/****** SAVE LLANTA */

			$this->Helper->eliminar_registros_detalle('vehiculo_llanta', 'id_vehiculo', $id_vehiculo, json_decode($data_request["detalle_llanta"]));

			foreach (json_decode($data_request["detalle_llanta"]) as $row) {

				if($row->codigo == '')
				{
					return $this->respond(['tipo' => 'warning', 'mensaje' => 'Debe digitar un código único a la llanta'], 400);
					exit;
				}

				$data_detalle_llanta = [
					'id_vehiculo'			=> $id_vehiculo,
					'configuracion'       	=> $row->configuracion,
					'kilometraje'           => $row->kilometraje,
					'posicion'            	=> $row->posicion,
					'codigo'              	=> $row->codigo,
					'marca'               	=> $row->marca,
					'medida'              	=> $row->medida,
					'diseno'              	=> $row->diseno,
					'condicion'           	=> $row->condicion,
					'vida'                	=> $row->vida,
					'remanente'           	=> $row->remanente,
					'presion_recomendada' 	=> $row->presion_recomendada,
					'presion_actual'      	=> $row->presion_actual,
					'codigo_unico'			=> $id_vehiculo.'-'.$row->codigo
				];

				if(is_numeric($row->id))
				{
					$data_detalle_llanta["id"] = $row->id;
				}

				$this->Vehiculo_llanta_m->save($data_detalle_llanta);

			}

			/****** SAVE COMPARTIMIENTOS */

			$this->Helper->eliminar_registros_detalle('vehiculo_compartimiento', 'id_vehiculo', $id_vehiculo, json_decode($data_request["detalle_compartimiento"]));

			$total_capacidad_carga = 0;

			foreach (json_decode($data_request["detalle_compartimiento"]) as $row) {

				$data_detalle_compartimiento = [
					'id_vehiculo'		=> $id_vehiculo,
					'nombre'			=> $row->nombre,
					'capacidad_carga'	=> $row->capacidad_carga,
					'id_empresa'		=> ID_EMPRESA
				];

				if(is_numeric($row->id))
				{
					$data_detalle_llanta["id"] = $row->id;
				}

				$this->Vehiculo_compartimiento_m->save($data_detalle_compartimiento);

				$total_capacidad_carga = $total_capacidad_carga + ((is_numeric($row->capacidad_carga)) ? $row->capacidad_carga : 0);
			}

			if(count(json_decode($data_request["detalle_compartimiento"])) > 0)
			{				
				$update_vehiculo = [
					'id'					=> $id_vehiculo,
					'capacidad_carga'		=> $total_capacidad_carga
				];

				$this->Vehiculo_m->save($update_vehiculo);
			}
					
			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'CONFIGURACIÓN',
				'menu'			=> 'VEHÍCULOS',
				'accion'		=> (isset($data_request["id"])) ? 'EDITAR' : 'NUEVO',
				'descripcion'	=> trim($data_request["placa"])
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */

			$db->transComplete();

			$vehiculo_clase = $this->Vehiculo_clase_m->select('fl_remolque')->find($data_request["id_vehiculo_clase"]);

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente', 'fl_remolque' => $vehiculo_clase->fl_remolque, 'id_vehiculo' => $id_vehiculo], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('configuracion-vehiculo', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$vehiculo = $this->Vehiculo_m->find($data_request["id"]);

			$this->Vehiculo_mantenimiento_m->where('id_vehiculo', $data_request["id"])->delete();
			$this->Vehiculo_llanta_m->where('id_vehiculo', $data_request["id"])->delete();
			$this->Vehiculo_compartimiento_m->where('id_vehiculo', $data_request["id"])->delete();

			$this->Vehiculo_m->where('id', $data_request["id"])
			->delete();
			
			/** ELIMINAR IMAGEN */
			$Imagen_upload = new Image_model();
			$Imagen_upload->eliminar($vehiculo->imagen);

			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'CONFIGURACIÓN',
				'menu'			=> 'VEHÍCULO',
				'accion'		=> 'ELIMINAR',
				'descripcion'	=> 	$vehiculo->placa
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
            
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function save_importacion()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('configuracion-vehiculo', 'new');

		$respuesta = explode(".", $_FILES["archivo"]['name']);
		$extension = $respuesta[(count($respuesta))-1];
	
		if($extension == 'xlsx')
		{
			require_once APPPATH."Libraries/phpexcel/PHPExcel.php";

			$tmpfname = $_FILES["archivo"]['tmp_name'];
			$excelReader = \PHPExcel_IOFactory::createReaderForFile($tmpfname);
			$excelObj = $excelReader->load($tmpfname);
			$hoja = $excelObj->getSheet(0);

			$ultima_fila = $hoja->getHighestRow();
			$total_registros = 0;
			$detalle = Array();

			try {
				
				$db = \Config\Database::connect();
				$db->transStart();

				$array_batch = [];					

				for ($fila = 3; $fila <= $ultima_fila; $fila++) {

					$guardar = true;

					$placa = $hoja->getCell('D'.$fila)->getValue();

					if($placa != '')
					{					
						$tipo_flete = trim($hoja->getCell('F'.$fila)->getValue());

						$data_save = [
							'placa'				=> $placa,
							'capacidad_carga'	=> trim($hoja->getCell('E'.$fila)->getValue()),
							'tipo_flete'		=> $tipo_flete,
							'costo_flete'		=> ($tipo_flete == 'FLETE FIJO') ?  trim($hoja->getCell('G'.$fila)->getValue()) : 0,
							'tipo_carga'		=> 'TONELADAS',
							'imagen'			=> 'sin_imagen.jpg',
							'id_empresa'		=> ID_EMPRESA
						];						

						$array_batch[] = $data_save;
					}	
					else
					{
						break;
					}					

				}

				if(count($array_batch) > 0)
				{
					$this->Vehiculo_m->insertBatch($array_batch);
					$db->transComplete();

					return $this->respond(['tipo' => 'success', 'mensaje' => 'Excelente!'], 200);
				}
				else
				{
					return $this->respond(['tipo' => 'warning', 'mensaje' => 'No hay datos para guardar'], 200);
				}					

			} catch (\Exception $e) {
				return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
			}
			
		}
		else
		{
			return $this->respond(['tipo' => 'danger', 'mensaje' => 'Archivo con formato incorrecto'], 400);
		}
	}

	public function save_configuracion()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('configuracion-ajuste_avanzado', 'edit');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			/** GUARDAR */
			$data = [
				'dt_configuracion_vehiculo'     => trim($data_request["view_datatable"]),
				'id_empresa'					=> ID_EMPRESA
			];

			$this->Config_modulo_m->save($data);

			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'CONFIGURACIÓN',
				'menu'			=> 'VEHÍCULOS',
				'accion'		=> 'CONFIGURAR',
				'descripcion'	=> 'Configuración'
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
