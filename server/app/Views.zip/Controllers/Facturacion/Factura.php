<?php namespace App\Controllers\Facturacion;

use App\Controllers\BaseController;

use App\Models\Operacion\Orden_model;
use App\Models\Operacion\Viaje_guia_model;
use App\Models\Configuracion\Empresa_model;
use App\Models\Configuracion\Cliente_model;
use App\Models\Configuracion\Ajuste_avanzado_model;
use App\Models\Configuracion\Cuenta_bancaria_empresa_model;
use App\Models\Facturacion\Factura_model;
use App\Models\Facturacion\Factura_orden_model;
use App\Models\Facturacion\Factura_detalle_model;
use App\Models\Facturacion_electronica\Emision_model;

class Factura extends BaseController
{
	public function __construct()
	{
		$this->Cliente_m = new Cliente_model();
		$this->Orden_m = new Orden_model();
		$this->Viaje_guia_m = new Viaje_guia_model();
		$this->Factura_m = new Factura_model();
		$this->Factura_orden_m = new Factura_orden_model();
		$this->Factura_detalle_m = new Factura_detalle_model();
		$this->Emision_m = new Emision_model();
		$this->Empresa_m = new Empresa_model();
		$this->Ajuste_avanzado_m = new Ajuste_avanzado_model();
		$this->Cuenta_bancaria_empresa_m = new Cuenta_bancaria_empresa_model();
	}

	public function imprimir($id_factura)
	{		
		$data_request = $this->request->getGet();

		$response = $this->Factura_m->select('factura.*')
		->select('factura.*, concat(factura.serie,"-",factura.numero) as factura')		
		->select('c.nombre as comprobante')	
		->select('ca.nombre as comprobante_afectado')	
		->select('d.nombre as documento') 
		->select('m.nombre as moneda, m.simbolo as moneda_simbolo, m.codigo as moneda_codigo')		
		->select('tnc.nombre as tipo_nota_credito')
		->select('tnd.nombre as tipo_nota_debito')
		->join('static_comprobante c', 'c.id = factura.id_comprobante', 'left')
		->join('static_comprobante ca', 'ca.id = factura.afectado_id_comprobante', 'left')
		->join('static_documento d', 'd.id = factura.cliente_id_documento', 'left')
		->join('static_moneda m', 'm.id = factura.id_moneda', 'left')
		->join('static_tipo_nota tnc', 'tnc.id = factura.id_tipo_nota_credito', 'left')
		->join('static_tipo_nota tnd', 'tnd.id = factura.id_tipo_nota_debito', 'left')		
		->find($id_factura);

		$response->detalle = $this->Factura_detalle_m->select('factura_detalle.*')
		->select('coalesce(codigo_producto,  "") as codigo_producto')
		->select('o.id as id_orden, o.costo_medida, o.producto, coalesce(date_format(o.fecha, "%d/%m/%Y"), "") as fecha, coalesce(o.orden_servicio, "") as orden_servicio')
		->select('t.tipo_medida')
		->select('r.punto_inicio, r.punto_final')
		->select('vo.id_viaje')
		->select('um.codigo_sunat as unidad_medida')
		->join('viaje_orden vo', 'vo.id_orden = factura_detalle.id_orden', 'left')
		->join('orden o', 'o.id = factura_detalle.id_orden', 'left')
		->join('tarifa t', 't.id = o.id_tarifa', 'left')
		->join('ruta r', 'r.id = t.id_ruta', 'left')
		->join('static_unidad_medida um', 'um.codigo_sunat = factura_detalle.codigo_unidad_medida', 'left')
		->where('factura_detalle.id_factura', $id_factura)
		->orderBy('factura_detalle.id', 'asc')
		->findAll();

		$response->producto = '';
		$response->tipo_medida = '';
		$response->punto_inicio = '';
		$response->punto_final = '';

		foreach ($response->detalle as $row) {

			$guia_remitente = [];
			$guia_transportista = [];
			$guia_tercero = [];

			if($row->id_orden != null)
			{
				if($row->id_orden != null && $row->id_viaje != null)
				{
					$guias = $this->Viaje_guia_m->where('(id_orden = '.$row->id_orden.' or id_viaje = '.$row->id_viaje.')')->where('fl_estado', 1)->findAll();
				}
				else
				{
					$guias = $this->Viaje_guia_m->where('id_orden', $row->id_orden)->where('fl_estado', 1)->findAll();
				}

				foreach ($guias as $guia) {
					
					switch ($guia->tipo) {
						case 'REMITENTE':
							$guia_remitente[] = $guia->serie.'-'.$guia->numero;
						break;
						
						case 'TRANSPORTISTA':
							$guia_transportista[] = $guia->serie.'-'.$guia->numero;
						break;

						case 'TERCERO':
							$guia_tercero[] = $guia->serie.'-'.$guia->numero;
						break;
					}
				}

				/*** DATA ENCABEZADOS DETALLE */

				$response->producto = $row->producto;
				$response->tipo_medida = $row->tipo_medida;
				$response->punto_inicio = $row->punto_inicio;
				$response->punto_final = $row->punto_final;
			}

			$row->guia_remitente = implode(', ', $guia_remitente);
			$row->guia_transportista = implode(', ', $guia_transportista);
			$row->guia_tercero = implode(', ', $guia_tercero);

		}		

		$response->empresa = $this->Empresa_m->find(ID_EMPRESA);

		$response->cuentas_bancarias = $this->Cuenta_bancaria_empresa_m->where('id_empresa', ID_EMPRESA)->where('fl_publico', 1)->findAll();

		$response->ajuste = $this->Ajuste_avanzado_m->where('id_empresa', ID_EMPRESA)->first();


		/*** 
		 * CREAR IMAGEN QR 
		 * 
		 * */
		require_once APPPATH."/Libraries/phpqrcode/qrlib.php"; 

		$path = ROOT_PUBLIC_WRITABLE.'images/qrcode';
		if (!file_exists($path)) {
			mkdir($path, 0777, true);
		}

		$ruta_qr = ROOT_PUBLIC_WRITABLE.'images/qrcode/FACTURA_'.$response->codigo_unico.'.png';       
		\QRcode::png($response->qr, $ruta_qr, 'Q', 2, 0);

		/****** */

		return $this->respond($response, 200);
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response =	$this->Factura_m->select("id, concat('FECHA: ', date_format(fecha, '%d/%m/%Y'), ' ', serie, ' - ', numero,'| RAZÓN SOCIAL: ', cliente_razon_social, ' IMPORTE: ', total_importe) as text");

		$serie_numero = explode('-', $data_request["buscar"]);
		$fecha = explode('/', $data_request["buscar"]);

		if(count($serie_numero) == 2)
		{
			/** SERIE NUMERO */
			$response->where('serie', $serie_numero[0]);
			$response->like('numero', '%'.$serie_numero[1]);
		}

		if(count($fecha) == 3)
		{
			/** FECHA */
			if($fecha[2] == '')
			{          
				$fecha[2] = date("Y");          
			}
			
			$response->where('DATE_FORMAT(fecha, "%Y-%m-%d")', $fecha[2].'-'.$fecha[1].'-'.$fecha[0]);
			
		}
		
		$response = $response->where('id_empresa', ID_EMPRESA)
		->findAll();
		
		return $this->respond($response, 200);
	}

	public function get_correlativo($id_comprobante, $serie)
	{
		$secuencia = $this->Factura_m->get_correlativo($id_comprobante, $serie);

		return $this->respond($secuencia, 200);
	}

	public function get_unique($id_factura)
	{		
		$data_request = $this->request->getGet();

		$response = $this->Factura_m->find($id_factura);
		$response->detalle = $this->Factura_detalle_m->where('id_factura', $id_factura)->findAll();

		return $this->respond($response, 200);
	}


	public function index()
	{		
		$data_request = $this->request->getGet();

		$response = $this->Factura_m->select('factura.*, concat(factura.serie,"-",factura.numero) as factura')		
		->select('c.nombre as comprobante, c.codigo_sunat as comprobante_codigo_sunat')	
		->select('ca.nombre as comprobante_afectado, ca.codigo_sunat as afectado_comprobante_codigo_sunat')		
		->select('d.codigo_sunat as documento_codigo_sunat')
		->select('m.simbolo as moneda_simbolo, m.codigo_contasis as moneda_codigo_contasis')
		->join('static_moneda m', 'm.id = factura.id_moneda', 'left')
		->join('static_documento d', 'd.id = factura.cliente_id_documento', 'left')
		->join('static_comprobante c', 'c.id = factura.id_comprobante', 'left')
		->join('static_comprobante ca', 'ca.id = factura.afectado_id_comprobante', 'left');

		if($data_request["serie"] != '' && $data_request["numero"] != '')
		{
			$response->where('factura.serie', $data_request["serie"]);
			$response->where('CAST(factura.numero AS UNSIGNED)', $data_request["numero"]);
		}
		else
		{
			$response->where('DATE_FORMAT(factura.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
			->where('DATE_FORMAT(factura.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"]);

			if($data_request["id_comprobante"] != '')
			{
				$response->where('factura.id_comprobante', $data_request["id_comprobante"]);
			}

			if($data_request["serie"] != '')
			{
				$response->where('factura.serie', $data_request["serie"]);
			}

			if($data_request["id_cliente"] != '')
			{
				$response->where('factura.id_cliente', $data_request["id_cliente"]);
			}
		}	
		
		if(isset($data_request["tipo_exportar"]))
		{
			$response->where('c.codigo_sunat !=', null);
		}

		$response = $response->where('factura.id_empresa', ID_EMPRESA)		
		->findAll();

		/*** TIPO RESPUESTA */

		if(isset($data_request["tipo_exportar"]))
		{
			if($data_request["tipo_exportar"] == 'CONTASIS')
			{
				return $this->exportar_contasis($response);
			}
			else if($data_request["tipo_exportar"] == 'VENTA_14_1')
			{
				return $this->exportar_venta_14_1($response);
			}
		}
		else
		{
			return $this->respond(['data' => $response], 200);
		}
		
	}


	public function consultar($id_factura, $anulado = 0)
	{
		$db = \Config\Database::connect();

		$db->query('SET AUTOCOMMIT = 0');
		$db->transStart();
		$db->query('LOCK TABLES factura write,  factura_detalle read, empresa read, static_documento read, static_comprobante read, static_tipo_nota read');

		$data_conexion = [
			'tipo_operacion' 	=> ($anulado == 1) ? 'consultar_anulacion' : 'consultar_comprobante',
			'id_factura'  		=> $id_factura
		];

		$response = $this->Emision_m->conexion($data_conexion);

		if($response["tipo"] == 'danger')
		{
			return $this->respond($response, 400);
		}

		$db->query('UNLOCK TABLES');
		$db->transComplete();

		return $this->respond($response, 200);
	}

	public function anular()
	{
		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('facturacion-comprobante', 'delete');

		$data_request = $this->request->getPost();

		try {

			$db = \Config\Database::connect();

			$db->query('SET AUTOCOMMIT = 0');
			$db->transStart();
			$db->query('LOCK TABLES factura write,  factura_detalle read, empresa read, static_documento read, static_comprobante read, static_tipo_nota read, centinela write, factura_orden read, orden write');
		
			
			$factura = $this->Factura_m->find($data_request["id"]);

			/*** VERIFICAR SI ES RECIBO INTERNO */
			$comprobante = $db->table('static_comprobante')->where('id', $factura->id_comprobante)->get()->getRow();

			/****************** SAVE CENTINELA *****************/
			$factura_cent = $this->Factura_m->select('concat(factura.serie,"-",factura.numero) as numero, static_comprobante.nombre as comprobante, factura.total_importe')
			->join('static_comprobante', 'static_comprobante.id = factura.id_comprobante')
			->find($data_request["id"]);

			$data_centinela = [
				'modulo'		=> 'FACTURACIÓN',
				'menu'			=> 'COMPROBANTE',
				'accion'		=> 'ANULAR',
				'descripcion'	=> $factura_cent->comprobante.' '.$factura_cent->numero.', Importe: '.$factura_cent->total_importe
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */

			/**** DESVINCULAR DE ORDEN */

			$factura_orden = $this->Factura_orden_m->where('id_factura', $data_request["id"])->findAll();

			foreach ($factura_orden as $row) {
				
				if($row->id_orden != null)
				{
					$data_orden = [
						'id'			=> $row->id_orden,
						'id_factura'	=> null
					];

					$this->Orden_m->save($data_orden);
				}
			}

			/******* */

			if($comprobante->nombre == 'RECIBO INTERNO')
			{
				/** SAVE */
				$data_factura = [
					'id'				=> $data_request["id"],
					'motivo_anulacion'	=> 'ANULADO',
					'estado'			=> 'ANULADO'
				];

				$this->Factura_m->save($data_factura);

				$db->query('UNLOCK TABLES');
				$db->transComplete();

				return $this->respond(['tipo' => 'success', 'mensaje' => 'Anulado Correctamente', 'id_factura'	=> $data_request["id"]], 200);
			}
			else
			{
				/** SAVE */
				$data_factura = [
					'id'				=> $data_request["id"],
					'motivo_anulacion'	=> 'ANULADOOOO'
				];

				$this->Factura_m->save($data_factura);

				/** EMITIR */
				$data_conexion = [
					'tipo_operacion' 	=> 'generar_anulacion',
					'id_factura'  		=> $data_request["id"]
				];

				$response = $this->Emision_m->conexion($data_conexion);

				if($response["tipo"] == 'danger')
				{
					return $this->respond($response, 400);
				}

				$db->query('UNLOCK TABLES');
				$db->transComplete();

				return $this->respond($response, 200);
			}

		} catch (\Exception $e)
		{
		return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
		
	}

	public function nuevo_comprobante()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('facturacion-nuevo_comprobante', 'new');

		try {

			$db = \Config\Database::connect();
			$db->query('SET AUTOCOMMIT = 0');
			$db->transStart();
			$db->query('LOCK TABLES factura write,  factura_detalle write, empresa read, orden write, static_documento read, static_comprobante read, serie read, static_tipo_nota read, cliente read, centinela write, factura_orden write');

			$codigo_unico = ID_EMPRESA.'-'.trim($data_request["id_comprobante"]).'-'.trim($data_request["serie"]).'-'.trim($data_request["numero"]);

			/*** IDENTIFICAR CLIENTE */

			$cliente = $this->Cliente_m->where('id_documento', trim($data_request["id_documento"]))
			->where('numero_documento', trim($data_request["numero_documento"]))
			->first();
			
			/** GUARDAR */
			$data = [
				'fecha'							=> date("Y-m-d"),
				'id_comprobante'				=> trim($data_request["id_comprobante"]),
				'serie'							=> trim($data_request["serie"]),
				'id_cliente'					=> (is_object($cliente)) ? $cliente->id : null,
				'total_gravada'					=> trim($data_request["total_gravada"]),
				'total_igv'						=> trim($data_request["total_igv"]),
				'total_importe'					=> trim($data_request["total_importe"]),
				'afectado_id_comprobante'		=> isset($data_request["afectado_id_comprobante"]) ? trim($data_request["afectado_id_comprobante"]) : null,
				'afectado_serie'				=> isset($data_request["afectado_serie"]) ? trim($data_request["afectado_serie"]) : null,
				'afectado_numero'				=> isset($data_request["afectado_numero"]) ? trim($data_request["afectado_numero"]) : null,
				'afectado_fecha'				=> isset($data_request["afectado_fecha"]) ? trim($data_request["afectado_fecha"]) : null,
				'id_tipo_nota_credito'			=> isset($data_request["id_tipo_nota_credito"]) ? trim($data_request["id_tipo_nota_credito"]) : null,
				'id_tipo_nota_debito'			=> isset($data_request["id_tipo_nota_debito"]) ? trim($data_request["id_tipo_nota_debito"]) : null,
				'codigo_unico'					=> $codigo_unico,
				'descripcion_motivo'			=> isset($data_request["descripcion_motivo"]) ? trim($data_request["descripcion_motivo"]) : null,
				'comentario'					=> trim($data_request["comentario"]),
				'cliente_id_documento'			=> trim($data_request["id_documento"]),
				'cliente_numero_documento'		=> trim($data_request["numero_documento"]),
				'cliente_razon_social'			=> trim($data_request["razon_social"]),
				'cliente_direccion'				=> trim($data_request["direccion"]),
				'cliente_ubigeo'				=> (isset($data_request["id_ubigeo"])) ? trim($data_request["id_ubigeo"]) : null,
				'cliente_email'					=> trim($data_request["email"]),
				'condicion_pago'				=> trim($data_request["condicion_pago"]),
				'id_moneda'						=> trim($data_request["id_moneda"]),
				'dias_pagar'					=> (isset($data_request["dias_pagar"])) ? trim($data_request["dias_pagar"]) : null,
				'fl_detraccion'					=> (isset($data_request["fl_detraccion"])) ? 1 : 0,
				'porcentaje_detraccion'			=> (isset($data_request["porcentaje_detraccion"])) ? trim($data_request["porcentaje_detraccion"]) : null,
				'tipo_cambio'					=> (isset($data_request["tipo_cambio"])) ? trim($data_request["tipo_cambio"]) : null,
				'total_detraccion'				=> (isset($data_request["porcentaje_detraccion"])) ? ($data_request["total_importe"] * ($data_request["porcentaje_detraccion"] / 100)) : 0,
				'fl_masivo'						=> (isset($data_request["array_orden"]) && count(json_decode($data_request["array_orden"])) > 1) ? 1 : 0
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$correlativo = $this->Factura_m->get_correlativo($data_request["id_comprobante"], $data_request["serie"]);
				$data["numero"] = $correlativo->numero;

				$data["fecha_sistema"] = date("Y-m-d H:i:s");
				$data["estado"] = 'REGISTRADO';
				$data["id_empresa"] = ID_EMPRESA;
				$data["id_usuario"] = ID_USUARIO;
			}

			$this->Factura_m->save($data);

			$id_factura = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			/** SAVE DETALLE */
			$data_detalle = [];

			$this->Factura_detalle_m->where('id_factura', $id_factura)->delete();

			foreach (json_decode($data_request["detalle"]) as $row) {
				$data_detalle[] = [
					'id_factura'				=> $id_factura,
					'codigo_unidad_medida'		=> $row->id_unidad_medida,
					'cantidad'					=> $row->cantidad,
					'descripcion'				=> $row->descripcion,
					'valor_unitario'			=> $row->valor_unitario,
					'precio_unitario'			=> $row->precio_unitario,
					'subtotal'					=> $row->subtotal,
					'tipo_igv'					=> 1, // GRAVADA
					'igv'						=> $row->igv,
					'importe'					=> $row->importe,
					'porcentaje_igv'			=> $row->porcentaje_igv,
					'id_orden'					=> (isset($row->id_orden) && $row->id_orden != '' && $row->id_orden != 'null') ? $row->id_orden : null
				];
			}

			$this->Factura_detalle_m->insertbatch($data_detalle);

			/*** VINCULAR FACTURA A ORDENES */
			if(isset($data_request["array_orden"]) && count(json_decode($data_request["array_orden"])) > 0)
			{

				$array_factura_orden = [];

				foreach (json_decode($data_request["array_orden"]) as $orden) {

					$array_factura_orden[] = [
						'id_factura'	=> $id_factura,
						'id_orden'		=> $orden->id_orden
					];


					/*** VINCULAR FACTURA A ORDEN SI ES DIFERENTE A NOTA*/
					if(!isset($data_request["afectado_id_comprobante"]))
					{
						$orden_update = [
							'id'        		=>  $orden->id_orden,
							'id_factura'  		=>  $id_factura
						];					
						
						$this->Orden_m->save($orden_update);
					}					

				}

				if(count($array_factura_orden) > 0)
				{
					$this->Factura_orden_m->insertBatch($array_factura_orden);
				}				
			}
			else
			{
				/**** FACTURA LIBRE SIN ORDEN */
				$data = [
					'id_factura'	=> $id_factura
				];

				$this->Factura_orden_m->save($data);
			}


			/****************** SAVE CENTINELA *****************/
			$factura_cent = $this->Factura_m->select('concat(factura.serie,"-",factura.numero) as numero, static_comprobante.nombre as comprobante, factura.total_importe')
			->join('static_comprobante', 'static_comprobante.id = factura.id_comprobante')
			->find($id_factura);

			$data_centinela = [
				'modulo'		=> 'FACTURACIÓN',
				'menu'			=> 'NUEVO COMPROBANTE',
				'accion'		=> 'NUEVO',
				'descripcion'	=> $factura_cent->comprobante.' '.$factura_cent->numero.', Importe: '.$factura_cent->total_importe
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */


			/*** VERIFICAR SI ES RECIBO INTERNO*/
			$comprobante = $db->table('static_comprobante')->where('id', $data_request["id_comprobante"])->get()->getRow();

			if($comprobante->nombre == 'RECIBO INTERNO')
			{
				$db->query('UNLOCK TABLES');
        		$db->transComplete();

				return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente', 'id_factura'	=> $id_factura], 200);
			}


			/*** MÉTODO PARA ENVIAR A PROVEEDOR ELECTRÓNICO */
			$data_conexion = [
				'tipo_operacion'  	=> 'generar_comprobante',
				'id_factura'  		=> $id_factura
			];

			$response = $this->Emision_m->conexion($data_conexion);			

			if($response["tipo"] == 'danger')
			{
				return $this->respond($response, 400);
			}			
			
			$db->query('UNLOCK TABLES');
        	$db->transComplete();

			$response["id_factura"] = $id_factura;

			return $this->respond($response, 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function exportar_contasis($response)
	{
		/** EXPORTAR EXCEL */
        require_once APPPATH."Libraries/phpexcel/PHPExcel.php";
        $this->excel = \PHPExcel_IOFactory::load(WRITEPATH.'formatos/reportes/factura_contasis.xlsx');
        $this->excel->setActiveSheetIndex(0);

        $sheet = $this->excel->getActiveSheet();
        
        $n_fila = 5;
        foreach ($response as $row) {
            $sheet->setCellValue("A".$n_fila, date("d/m/Y", strtotime($row->fecha)));
            $sheet->setCellValue("B".$n_fila, date("d/m/Y", strtotime($row->fecha)));
            $sheet->setCellValue("C".$n_fila, $row->comprobante_codigo_sunat);
            $sheet->setCellValue("D".$n_fila, '00'.$row->serie);
            $sheet->setCellValue("E".$n_fila, '00000'.$row->numero);
            $sheet->setCellValue("F".$n_fila, $row->documento_codigo_sunat);
            $sheet->setCellValue("G".$n_fila, $row->cliente_numero_documento);
            $sheet->setCellValue("H".$n_fila, $row->cliente_razon_social);
            $sheet->setCellValue("J".$n_fila, $row->total_gravada);
            $sheet->setCellValue("N".$n_fila, $row->total_igv);
            $sheet->setCellValue("P".$n_fila, $row->total_importe);

            $sheet->setCellValue("R".$n_fila, ($row->afectado_fecha != null) ? date("d/m/Y", strtotime($row->afectado_fecha)) : null);
            $sheet->setCellValue("S".$n_fila, $row->afectado_comprobante_codigo_sunat);
            $sheet->setCellValue("T".$n_fila, $row->afectado_serie);
            $sheet->setCellValue("U".$n_fila, ($row->afectado_numero != null) ? '00000'.$row->afectado_numero : '');

            $sheet->setCellValue("V".$n_fila, $row->moneda_codigo_contasis); //MONEDA
            $sheet->setCellValue("Y".$n_fila, substr($row->condicion_pago, 0, 3)); // CONDICIÓN CONTADO / CRÉDITO
            $sheet->setCellValue("AB".$n_fila, ''); // CUENTA CONTABLE BASE IMPONIBLE
            $sheet->setCellValue("AD".$n_fila, ''); // CUENTA CONTABLE TOTAL
            $sheet->setCellValue("AL".$n_fila, '18'); // PORCENTAJE IGV
            $sheet->setCellValue("AM".$n_fila, ''); // GLOSA
            $n_fila++;
        }

        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="Registro_venta_contasis.xls"');
        header('Cache-Control: max-age=0');

        $objWriter = \PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');
        $objWriter->save('php://output');
	}

	public function exportar_venta_14_1($response)
	{
		/** EXPORTAR EXCEL */
        require_once APPPATH."Libraries/phpexcel/PHPExcel.php";
        $this->excel = \PHPExcel_IOFactory::load(WRITEPATH.'formatos/reportes/factura_venta_14_1.xlsx');
        $this->excel->setActiveSheetIndex(0);
		

        $sheet = $this->excel->getActiveSheet();
        
        $n_fila = 11;
		$contador = 0;

		$meses = [
			'ENERO', 'FEBRERO', 'MARZO', 'ABRIL', 'MAYO', 'JUNIO', 'JULIO', 'AGOSTO', 'SEPTIEMBTE', 'OCTUBRE', 'NOVIEMBRE', 'DICIEMBRE'
		];
		
		if(count($response) > 0)
		{
			$explode_fecha = explode('-', $response[0]->fecha);
			$sheet->setCellValue("E3", $meses[($explode_fecha[1] - 1)].' '.$explode_fecha[0]);
		}
		
		$t_total_gravada = 0;
		$t_total_igv = 0;
		$t_total_importe = 0;

        foreach ($response as $row) {
			$contador++;

			$sheet->setCellValue("A".$n_fila, $contador);
            $sheet->setCellValue("B".$n_fila, date("d/m/Y", strtotime($row->fecha)));
            $sheet->setCellValue("C".$n_fila, date("d/m/Y", strtotime($row->fecha)));
            $sheet->setCellValue("D".$n_fila, $row->comprobante_codigo_sunat);
            $sheet->setCellValue("E".$n_fila, $row->serie);
            $sheet->setCellValue("F".$n_fila, $row->numero);
            $sheet->setCellValue("G".$n_fila, (($row->fl_anulado == 1) ? '' : $row->documento_codigo_sunat));
            $sheet->setCellValue("H".$n_fila, (($row->fl_anulado == 1) ? '' : $row->cliente_numero_documento));
            $sheet->setCellValue("I".$n_fila, (($row->fl_anulado == 1) ? 'ANULADO' : $row->cliente_razon_social));

			$total_gravada = $row->total_gravada;
			$total_igv = $row->total_igv;
			$total_importe = $row->total_importe;
			$tipo_cambio = $row->tipo_cambio;

			if($row->tipo_cambio != null)
			{
				$total_gravada = $row->total_gravada * $row->tipo_cambio;
				$total_igv = $row->total_igv * $row->tipo_cambio;
				$total_importe = $row->total_importe * $row->tipo_cambio;
			}

			if($row->fl_anulado == 1)
			{
				$total_gravada = 0;
				$total_igv = 0;
				$total_importe = 0;
				$tipo_cambio = 0;
			}

            $sheet->setCellValue("K".$n_fila,  number_format((($row->afectado_serie != null) ? '-' : '').$total_gravada, 2, '.', ''));
            $sheet->setCellValue("O".$n_fila,  number_format((($row->afectado_serie != null) ? '-' : '').$total_igv, 2, '.', ''));
            $sheet->setCellValue("Q".$n_fila,  number_format((($row->afectado_serie != null) ? '-' : '').$total_importe, 2, '.', ''));
			$sheet->setCellValue("R".$n_fila, $tipo_cambio);

            $sheet->setCellValue("S".$n_fila, ($row->afectado_fecha != null) ? date("d/m/Y", strtotime($row->afectado_fecha)) : null);
            $sheet->setCellValue("T".$n_fila, $row->afectado_comprobante_codigo_sunat);
            $sheet->setCellValue("U".$n_fila, $row->afectado_serie);
            $sheet->setCellValue("V".$n_fila, ($row->afectado_numero != null) ? '00000'.$row->afectado_numero : '');

			if($row->afectado_serie == null)
			{
				$t_total_gravada = $t_total_gravada + $total_gravada;
				$t_total_igv = $t_total_igv + $total_igv;
				$t_total_importe = $t_total_importe + $total_importe;
			}
			else
			{
				$t_total_gravada = $t_total_gravada - $total_gravada;
				$t_total_igv = $t_total_igv - $total_igv;
				$t_total_importe = $t_total_importe - $total_importe;
			}

            $n_fila++;
        }
		
		$sheet->setCellValue("I".$n_fila, 'TOTALES');
		$sheet->setCellValue("K".$n_fila, number_format($t_total_gravada, 2, '.',''));
		$sheet->setCellValue("O".$n_fila, number_format($t_total_igv, 2, '.',''));
		$sheet->setCellValue("Q".$n_fila, number_format($t_total_importe, 2, '.',''));

        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="Registro_venta_14_1.xls"');
        header('Cache-Control: max-age=0');

        $objWriter = \PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');
        $objWriter->save('php://output');
	}

	public function enviar_email()
	{
		$data_request = $this->request->getPost();

		try {

			$db = \Config\Database::connect();

			$factura = $this->Factura_m->select('factura.*')
			->select('factura.*, concat(factura.serie,"-",factura.numero) as factura')		
			->select('c.nombre as comprobante')	
			->select('ca.nombre as comprobante_afectado')	
			->select('d.nombre as documento') 
			->select('m.nombre as moneda, m.simbolo as moneda_simbolo, m.codigo as moneda_codigo')		
			->select('tnc.nombre as tipo_nota_credito')
			->select('tnd.nombre as tipo_nota_debito')
			->select('e.razon_social as empresa, e.numero_documento as ruc_empresa')
			->join('static_comprobante c', 'c.id = factura.id_comprobante', 'left')
			->join('static_comprobante ca', 'ca.id = factura.afectado_id_comprobante', 'left')
			->join('static_documento d', 'd.id = factura.cliente_id_documento', 'left')
			->join('static_moneda m', 'm.id = factura.id_moneda', 'left')
			->join('static_tipo_nota tnc', 'tnc.id = factura.id_tipo_nota_credito', 'left')
			->join('static_tipo_nota tnd', 'tnd.id = factura.id_tipo_nota_debito', 'left')		
			->join('empresa e', 'e.id = factura.id_empresa', 'left')		
			->find($data_request["id"]);

			/****  */
			$configuracion = $db->table('static_system')->get()->getRow();

			$email = \Config\Services::email();

			$config['mailType'] = 'html';

			$email->initialize($config);

			$email->setFrom($configuracion->email_robot, $configuracion->empresa);
			$email->setTo($data_request["email"]);

			$data = [
				'factura'	=> $factura
			];

			$htmlContent = view('email/factura', $data);

			$email->setSubject('Comprobante '.$factura->comprobante.' '.$factura->factura.' | '.$factura->cliente_razon_social);
			$email->setMessage($htmlContent);

			$file = $this->request->getFile('archivo');

			if($file->getTempName() != "")
			{
				$email->attach($file->getTempName(), 'attachment', $file->getClientName(), $file->getClientMimeType());
			}

			$email->send();
			return $this->respond(['mensaje' => 'Enviado Correctamente'], 200);

		} catch (\Exception $e)
		{
		return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
		
	}
		
}
