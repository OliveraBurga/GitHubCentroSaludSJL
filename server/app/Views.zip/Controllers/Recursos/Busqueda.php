<?php namespace App\Controllers\Recursos;

use App\Controllers\BaseController;

class Busqueda extends BaseController
{
	public function __construct()
	{
		$this->db = \Config\Database::connect();
		$this->curl = \Config\Services::curlrequest();
	}

	public function reniec_sunat()
	{
		$data_request = $this->request->getGet();
		
		if(strlen($data_request["numero"]) == 11)
		{
			/** BUSCAR RUC */
			$ruc = $this->curl->request('POST', 'https://titanicsoft.com/titanic/interfaz/verruc.php', [
				'form_params' => [
					'ruc' => $data_request["numero"]
				]
			]);

			$ruc = json_decode($ruc->getBody(), true);

			$response = [
				'numero' 		=> $ruc["0"],
				'razon_social' 	=> $ruc["razonsocial"],
				'direccion'		=> $ruc["7"].' '.$ruc["8"].' '.$ruc["9"],
				'ubigeo' 	    => $ruc["ubigeo"],
			];

			return $this->respond($response, 200);
		}

		if(strlen($data_request["numero"]) == 8)
		{
			/** BUSCAR DNI
			 * 
			 * https://apiperu.dev/
			 * usuario:  genaro@titanicsoft.com
			 * contraseña: peru@2021
			 * 
			 */
			$ruc = $this->curl->request('GET', 'https://apiperu.dev/api/dni/'.$data_request["numero"], [
				'headers' => [
					'Authorization' => 'Bearer 6a6cfa5959fc68da3de4e7faf0edb38e0bf7dfe137ee2413ada1cb098ef08f77'
				]
			]);

			$dni = json_decode($ruc->getBody(), true);

			$response = [
				'response' 			=> $dni,
				'numero' 			=> (isset($dni["data"])) ? $dni["data"]["numero"] : '',
				'razon_social' 		=> (isset($dni["data"])) ? $dni["data"]["nombre_completo"] : '',
				'nombre' 			=> (isset($dni["data"])) ? $dni["data"]["nombres"] : '',
				'apellido' 			=> (isset($dni["data"])) ? $dni["data"]["apellido_paterno"].' '.$dni["data"]["apellido_materno"] : '',
				'fecha_nacimiento'	=> (isset($dni["data"])) ? $dni["data"]["fecha_nacimiento"] : '',
				'direccion'			=> '',
				'ubigeo' 	    	=> '',
			];

			return $this->respond($response, 200);
		}
		else
		{
			$response = [
				'mensaje' => 'Número de Documento no válido',
				'tipo'	=> 'danger'
			];
			return $this->respond($response, 400);
		}
		
	}
		
}
