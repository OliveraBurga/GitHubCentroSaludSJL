<?php namespace App\Controllers\Operacion;

use App\Controllers\BaseController;

use App\Models\Operacion\Vale_pago_model;
use App\Models\Configuracion\Proveedor_model;
use App\Models\Operacion\Viaje_model;
use App\Models\Tesoreria\Caja_model;
use App\Models\Tesoreria\Flujo_caja_model;

class Vale_pago extends BaseController
{
	public function __construct()
	{
		$this->Vale_pago_m = new Vale_pago_model();
		$this->Caja_m = new Caja_model();
		$this->Flujo_caja_m = new Flujo_caja_model();
	}

	public function get_correlativo($serie)
	{
		$secuencia = $this->Vale_pago_m->get_correlativo($serie);

		return $this->respond($secuencia, 200);
	}

	public function index()
	{		
		$data_request = $this->request->getGet();

		$response = $this->Vale_pago_m->select('vale_pago.*, concat(vale_pago.serie,"-",vale_pago.numero) as vale_pago')
		->select('pr.razon_social as proveedor')
		->select('v.placa as vehiculo')
		->select('concat(vi.serie,"-",vi.numero) as viaje')
		->select('coalesce(m.simbolo, "") as simbolo_moneda, m.nombre as moneda')

		->join('proveedor pr', 'pr.id = vale_pago.id_proveedor', 'left')
		->join('vehiculo v', 'v.id = vale_pago.id_vehiculo', 'left')
		->join('viaje vi', 'vi.id = vale_pago.id_viaje', 'left')
		->join('static_moneda m', 'm.id = vale_pago.id_moneda', 'left')

		->where('DATE_FORMAT(vale_pago.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(vale_pago.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])
		->where('vale_pago.id_empresa', ID_EMPRESA)		
		->findAll();

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('operacion-vale_pago', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('operacion-vale_pago', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->query('SET AUTOCOMMIT = 0');
			$db->transStart();
			$db->query('LOCK TABLES vale_pago write, centinela write, proveedor read, viaje read, caja write, flujo_caja write, ajuste_avanzado read');


			$id_caja = null;

			// CREAR CAJA RÁPIDA
			if(isset($data_request["modalidad"]))
			{
				$Proveedor_m = new Proveedor_model();
				$proveedor = $Proveedor_m->select('razon_social')->find($data_request["id_proveedor"]);

				if($data_request["porcentaje_detraccion"] != '')
				{
					$monto_detraccion = $data_request["importe"] * ($data_request["porcentaje_detraccion"] / 100);
					$porcentaje_detraccion = $data_request["porcentaje_detraccion"];
				}

				/** GUARDAR */
				$data = [
					'fecha'									=> $data_request["fecha"],
					'id_viaje'								=> (isset($data_request["id_viaje"])) ? $data_request["id_viaje"] : null,
					'tipo_persona'							=> 'PROVEEDOR',
					'id_tipo_persona'						=> $data_request["id_proveedor"],
					'nombre_persona'						=> $proveedor->razon_social,
					'motivo'								=> trim($data_request["motivo"]),
					'id_moneda'								=> trim($data_request["id_moneda"]),
					'tipo_cambio'         					=> (isset($data_request["tipo_cambio"])) ? trim($data_request["tipo_cambio"]) : null,
					'descripcion'							=> trim($data_request["descripcion"]),
					'modalidad'								=> $data_request["modalidad"],
					'importe'								=> trim($data_request["importe"]),
					'id_cuenta_bancaria_empresa'			=> ($data_request["id_cuenta_bancaria_empresa"] != '') ? trim($data_request["id_cuenta_bancaria_empresa"]) : null,
					'id_cuenta_bancaria_persona'			=> (isset($data_request["id_cuenta_bancaria_persona"])) ? trim($data_request["id_cuenta_bancaria_persona"]): null,
					'id_cuenta_bancaria_detraccion_persona'	=> ($data_request["porcentaje_detraccion"] != '') ? trim($data_request["id_cuenta_bancaria_detraccion_persona"]): null,
					'monto_detraccion'						=> ($data_request["porcentaje_detraccion"] != '') ? $monto_detraccion : null,
					'porcentaje_detraccion'					=> ($data_request["porcentaje_detraccion"] != '') ? $porcentaje_detraccion : null,
				];

				$correlativo = $this->Caja_m->get_correlativo(date("Y"));
				$data["serie"] = $correlativo->serie;
				$data["numero"] = $correlativo->numero;
				$data["tipo"] = 'CAJA_RAPIDA';
				$data["fl_estado"] = 3;
				$data["id_empresa"] = ID_EMPRESA;
				$data["id_usuario"] = ID_USUARIO;

				$this->Caja_m->save($data);

				$id_caja = $db->insertID();

				/** SAVE FLUJO CAJA */
				$this->Flujo_caja_m->where('id_caja', $id_caja)->delete();

				$data =  [
					'fecha'       					=> $data_request["fecha"],
					'tipo'        					=> 'EGRESO',
					'descripcion' 					=> trim($data_request["descripcion"]),
					'id_caja'						=> $id_caja,
					'id_usuario'  					=> ID_USUARIO,
					'id_empresa' 					=> ID_EMPRESA,
					'id_cuenta_bancaria_empresa'   	=> ($data_request["id_cuenta_bancaria_empresa"] != '') ? $data_request["id_cuenta_bancaria_empresa"] : null,
					'monto'       					=> trim($data_request["importe"]),
					'id_moneda'						=> trim($data_request["id_moneda"]),
					'tipo_cambio'					=> (isset($data_request["tipo_cambio"])) ? trim($data_request["tipo_cambio"]) : null,
					
				];

				$this->Flujo_caja_m->save($data);
			}	

			/** GUARDAR */
			$data = [
				'fecha'                 => trim($data_request["fecha"]), 
				'id_viaje'              => (isset($data_request["id_viaje"])) ? trim($data_request["id_viaje"]) : null, 
				'id_vehiculo'           => trim($data_request["id_vehiculo"]), 
				'id_proveedor'          => trim($data_request["id_proveedor"]), 
				'numero_comprobante'    => trim($data_request["numero_comprobante"]), 
				'numero_ticket'         => trim($data_request["numero_ticket"]), 
				'tipo_pago'          	=> trim($data_request["tipo_pago"]), 
				'dias_credito'         	=> (isset($data_request["dias_credito"])) ? trim($data_request["dias_credito"]) : null, 
				'motivo'          		=> trim($data_request["motivo"]), 
				'descripcion'          	=> trim($data_request["descripcion"]), 
				'importe'         		=> trim($data_request["importe"]), 
				'observacion'           => trim($data_request["observacion"]),
				'id_moneda'         	=> trim($data_request["id_moneda"]),
				'tipo_cambio'         	=> (isset($data_request["tipo_cambio"])) ? trim($data_request["tipo_cambio"]) : null,
				'porcentaje_detraccion'			=> ($data_request["porcentaje_detraccion"] != '') ? $data_request["porcentaje_detraccion"] : 0,
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$data["serie"] = trim($data_request["serie"]);
				$data["numero"] = str_pad(trim($data_request["numero"]),  8, "0", STR_PAD_LEFT);
				$data["fl_estado"] = 1;
				$data["id_empresa"] = ID_EMPRESA;
				$data["id_usuario"] = ID_USUARIO;
			}

			if($id_caja != null)
			{
				$data["id_caja"] = $id_caja;
			}				

			$this->Vale_pago_m->save($data);

			$id_vale_pago = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			/****************** SAVE CENTINELA *****************/
			$vale = $this->Vale_pago_m->find($id_vale_pago);

			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'VALES DE PAPGO',
				'accion'		=> (isset($data_request["id"])) ? 'EDITAR' : 'NUEVO',
				'descripcion'	=> $vale->serie.'-'.$vale->numero
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->query('UNLOCK TABLES');
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente', 'id_caja' => $id_caja], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('operacion-vale_pago', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$data = [
				'id'		=> $data_request["id"],
				'fl_estado'	=> 0
			];

			$this->Vale_pago_m->save($data);

			/****************** SAVE CENTINELA *****************/
			$vale = $this->Vale_pago_m->find($data_request["id"]);

			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'VALES DE COMBUSTIBLE',
				'accion'		=> 'ANULAR',
				'descripcion'	=> $vale->serie.'-'.$vale->numero
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
