<?php namespace App\Controllers\Operacion;

use App\Controllers\BaseController;

use App\Models\Operacion\Viaje_orden_model;
use App\Models\Operacion\Viaje_model;
use App\Models\Operacion\Viaje_guia_model;
use App\Models\Operacion\Viaje_ayudante_model;
use App\Models\Operacion\Viaje_monitoreo_model;
use App\Models\Operacion\Viaje_concepto_tercerizado_model;
use App\Models\Operacion\Viaje_escolta_model;
use App\Models\Configuracion\Personal_model;
use App\Models\Configuracion\Vehiculo_model;
use App\Models\Configuracion\Vehiculo_km_model;
use App\Models\Configuracion\Vehiculo_compartimiento_model;
use App\Models\Operacion\Devolucion_contenedor_model;
use App\Models\Tesoreria\Liquidacion_gasto_operativo_model;
use App\Models\Tesoreria\Caja_model;

class Viaje extends BaseController
{
	public function __construct()
	{
		$this->Viaje_m = new Viaje_model();
		$this->Viaje_guia_m = new Viaje_guia_model();
		$this->Viaje_orden_m = new Viaje_orden_model();
		$this->Vehiculo_m = new Vehiculo_model();
		$this->Vehiculo_km_m = new Vehiculo_km_model();
		$this->Vehiculo_compartimiento_m = new Vehiculo_compartimiento_model();
		$this->Devolucion_contenedor_m = new Devolucion_contenedor_model();
		$this->Viaje_ayudante_m = new Viaje_ayudante_model();
		$this->Viaje_monitoreo_m = new Viaje_monitoreo_model();
		$this->Viaje_concepto_tercerizado_m = new Viaje_concepto_tercerizado_model();
		$this->Viaje_escolta_m = new Viaje_escolta_model();
	}

	public function get_orden_cliente($id_viaje)
	{
		$response = $this->Viaje_orden_m->select('c.razon_social as cliente, c.email')
		->select("concat(o.serie,'-',o.numero) as orden")
		->join('orden o', 'o.id = viaje_orden.id_orden')
		->join('cliente c', 'c.id = o.id_cliente')
		->where('id_viaje', $id_viaje)
		->findAll();

		return $this->respond($response, 200);
	}

	public function get_select_tipo_carga()
	{

		$response = $this->Viaje_m->distinct('tipo_carga')
		->select("tipo_carga as text")
		->where('id_empresa', ID_EMPRESA)
		->findAll();

		return $this->respond($response, 200);
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response =	$this->Viaje_m->select("id, concat(serie, ' - ', numero) as text");

		$serie_numero = explode('-', $data_request["buscar"]);
		$fecha = explode('/', $data_request["buscar"]);

		if(count($serie_numero) == 2)
		{
			/** SERIE NUMERO */
			$response->where('serie', $serie_numero[0]);
			$response->like('numero', '%'.$serie_numero[1]);
		}

		if(count($fecha) == 3)
		{
			/** FECHA */
			if($fecha[2] == '')
			{          
				$fecha[2] = date("Y");          
			}
			
			$response->where('DATE_FORMAT(fecha, "%Y-%m-%d")', $fecha[2].'-'.$fecha[1].'-'.$fecha[0]);
			
		}
		
		$response = $response->where('id_empresa', ID_EMPRESA)
		->findAll();
		
		return $this->respond($response, 200);
	}

	public function get_select_sin_liquidar_gasto()
	{
		$data_request = $this->request->getGet();

		$response =	$this->Viaje_m->select("viaje.id, concat(serie, '-', numero, ' | Fecha:', date_format(viaje.fecha, '%d/%m/%Y')  ,' | Vehículo: ', v.placa,' | Conductor: ', cond.nombre_completo) as text")
		->join('vehiculo v', 'v.id = viaje.id_vehiculo')
		->join('personal cond', 'cond.id = viaje.id_conductor', 'left')
		->where('id_liquidacion_gasto_operativo', null)
		->where("viaje.id in (select id_viaje from caja where motivo = 'GASTOS OPERATIVOS' and fl_estado = 3)")
		->where('viaje.id_empresa', ID_EMPRESA);

		if(ID_PERSONAL != null)
		{
			$response->where('viaje.id_conductor', ID_PERSONAL);
		}

		$response = $response->findAll();
		
		return $this->respond($response, 200);
		
		return $this->respond($response, 200);
	}

	public function get_correlativo($serie)
	{
		$secuencia = $this->Viaje_m->get_correlativo($serie);

		return $this->respond($secuencia, 200);
	}

	public function get_unique($id_viaje, $minimal = false)
	{		
		$response = $this->Viaje_m->select('viaje.*')
		->select('vc.fl_remolque, vc.fl_compartimiento')	
		->select('v.placa as vehiculo, v.tipo_contratacion')
		->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
		->join('vehiculo_clase vc', 'vc.id = v.id_vehiculo_clase', 'left')
		->where('viaje.id_empresa', ID_EMPRESA)	
		->where('viaje.id', $id_viaje)
		->first();

		if($minimal == false)
		{
			$response->compartimientos = $this->Vehiculo_compartimiento_m->where('id_vehiculo', $response->id_vehiculo)->findAll();

			$response->ordenes = $this->Viaje_orden_m->select('viaje_orden.id_vehiculo_compartimiento')
			->select('orden.*, concat(serie,"-",numero) as orden')
			->select('c.razon_social as cliente')
			->select('concat(r.punto_inicio," - ",r.punto_final) as ruta')
			->select('m.nombre as moneda')
			->select('t.tipo_medida')		
			->join('orden', 'orden.id = viaje_orden.id_orden', 'left')
			->join('cliente c', 'c.id = orden.id_cliente', 'left')
			->join('ruta r', 'r.id = orden.id_ruta', 'left')
			->join('tarifa t', 't.id = orden.id_tarifa', 'left')
			->join('static_moneda m', 'm.id = orden.id_moneda')
			->where('viaje_orden.id_viaje', $response->id)->findAll();

			foreach ($response->ordenes as $orden) {
				
				$guias = $this->Viaje_guia_m->where('id_orden', $orden->id)
				->where('fl_estado', 1)
				->findAll();

				$array_guia = [];

				foreach ($guias as $guia) {
					$array_guia[] = $guia->serie.'-'.$guia->numero;
				}

				$orden->guia_remitente = implode(', ', $array_guia);
			}


			$response->guias_transportista = $this->Viaje_guia_m->where('id_viaje', $response->id)->where('tipo', 'TRANSPORTISTA')->findAll();
			$response->guias_tercero = $this->Viaje_guia_m->where('id_viaje', $response->id)->where('tipo', 'TERCERO')->findAll();
			$response->conceptos_tercerizado = $this->Viaje_concepto_tercerizado_m->where('id_viaje', $response->id)->findAll();
			$response->escoltas = $this->Viaje_escolta_m->where('id_viaje', $response->id)->findAll();

			$response->ayudantes = $this->Viaje_ayudante_m->where('id_viaje', $response->id)->findAll();
		}		

		return $this->respond($response, 200);
	}

	public function index()
	{		
		$data_request = $this->request->getGet();

		$response = $this->Viaje_m->select('viaje.*, concat(serie,"-",numero) as viaje, coalesce(viaje.costo_tercerizado, "") as costo_tercerizado, coalesce(viaje.costo_escolta, "") as costo_escolta')
		->select('cond.nombre_completo as conductor')
		->select('concat(r.punto_inicio," - ",r.punto_final) as ruta')
		->select('v.placa as vehiculo, v.tipo_contratacion')
		->select('vr.placa as remolque')
		->select('coalesce(p.razon_social, "") as proveedor')
		->select('coalesce(m.simbolo, "") as simbolo_moneda_tercerizado')
		->select('coalesce(m_esc.simbolo, "") as simbolo_moneda_escolta')
		->join('personal cond', 'cond.id = viaje.id_conductor', 'left')
		->join('ruta r', 'r.id = viaje.id_ruta', 'left')
		->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
		->join('vehiculo vr', 'vr.id = viaje.id_remolque', 'left')
		->join('proveedor p', 'p.id = v.id_proveedor', 'left')
		->join('static_moneda m', 'm.id = viaje.id_moneda_tercerizado', 'left')
		->join('static_moneda m_esc', 'm_esc.id = viaje.id_moneda_escolta', 'left');

		if($data_request["tipo_busqueda"] == 'SEGUN_FECHA')
		{
			$response->where('DATE_FORMAT(viaje.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        	->where('DATE_FORMAT(viaje.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"]);
		}
		else if($data_request["tipo_busqueda"] == 'NO_FINALIZADO')
		{
			$response->where('estado_operacion !=', 'FINALIZADO')
        	->where('fl_estado', 1);
		}

		$response = $response->where('viaje.id_empresa', ID_EMPRESA)		
		->findAll();

		foreach ($response as $row) {

			$monitoreo = $this->Viaje_monitoreo_m->select('viaje_monitoreo.*, em.nombre as estado, em.color_bg, em.color_text')
			->join('estado_monitoreo em', 'em.id = viaje_monitoreo.id_estado_monitoreo')
			->where('id_viaje', $row->id)
			->orderBy('fecha', 'desc')
			->orderBy('id', 'desc')
			->first();

			$row->ultimo_monitoreo = (is_object($monitoreo)) ? $monitoreo : null;

			$ordenes = $this->Viaje_orden_m->select('coalesce(sc.razon_social, "") as subcliente, coalesce(orden.direccion_llegada, "") as direccion_llegada, orden.total_orden, concat(orden.serie,"-", orden.numero) as orden, orden.total_orden, orden.tipo_cambio, orden.id_moneda')
			->select('coalesce(c.razon_social, "") as cliente')
			->join('orden', 'orden.id = viaje_orden.id_orden', 'left')
			->join('cliente c', 'c.id = orden.id_cliente', 'left')
			->join('subcliente sc', 'sc.id = orden.id_subcliente', 'left')			
			->where('viaje_orden.id_viaje', $row->id)->findAll();

			$row->ordenes = $ordenes;

			$total_importe_ordenes = 0;

			foreach ($ordenes as $orden) {

				if($orden->id_moneda > 1)
				{
					$total_importe_ordenes = $total_importe_ordenes + ($orden->total_orden * $orden->tipo_cambio);
				}
				else
				{
					$total_importe_ordenes = $total_importe_ordenes + $orden->total_orden;
				}
				
			}

			$row->cantidad_ordenes = count($ordenes);
			$row->total_importe_ordenes = number_format($total_importe_ordenes, 2, '.', '');			
		}

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('operacion-viaje', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('operacion-viaje', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->query('SET AUTOCOMMIT = 0');
			$db->transStart();
			$db->query('LOCK TABLES viaje_orden write,  viaje write, viaje_guia write, viaje_ayudante write, liquidacion_gasto_operativo write, caja write, personal read, centinela write, viaje_concepto_tercerizado write, ajuste_avanzado read, viaje_escolta write');

			/** GUARDAR */
			$data = [
				'fecha'								=> trim($data_request["fecha"]),
				'id_vehiculo'						=> trim($data_request["id_vehiculo"]),
				'id_remolque'						=> (isset($data_request["id_remolque"]) && $data_request["id_remolque"] != '') ? trim($data_request["id_remolque"]) : null,
				'id_conductor'						=> trim($data_request["id_conductor"]),
				'id_ruta'							=> trim($data_request["id_ruta"]),
				'modalidad'							=> trim($data_request["modalidad"]),
				'tipo_carga'						=> trim($data_request["tipo_carga"]),
				'cantidad'							=> trim($data_request["cantidad"]),
				'numero_contenedor'					=> isset($data_request["numero_contenedor"]) ? trim($data_request["numero_contenedor"]) : null,
				'costo_flete_tercerizado'			=> isset($data_request["costo_flete_tercerizado"]) ? trim($data_request["costo_flete_tercerizado"]) : 0,
				'costo_tercerizado'					=> isset($data_request["costo_tercerizado"]) ? trim($data_request["costo_tercerizado"]) : 0,
				'porc_detraccion_tercerizado'		=> isset($data_request["porc_detraccion_tercerizado"]) ? trim($data_request["porc_detraccion_tercerizado"]) : 0,
				'mas_inc_igv_tercerizado'			=> isset($data_request["mas_inc_igv_tercerizado"]) ? trim($data_request["mas_inc_igv_tercerizado"]) : null,
				'monto_gasto_operativo'				=> trim($data_request["monto_gasto_operativo"]),
				'descripcion_gasto_operativo'		=> trim($data_request["descripcion_gasto_operativo"]),
				'monto_adelanto_tercerizado'		=> (isset($data_request["monto_adelanto_tercerizado"]) && $data_request["monto_adelanto_tercerizado"] != '') ? trim($data_request["monto_adelanto_tercerizado"]) : 0,
				'id_moneda_tercerizado'				=> (isset($data_request["id_moneda_tercerizado"])) ? trim($data_request["id_moneda_tercerizado"]) : null,
				'tipo_cambio_tercerizado'			=> (isset($data_request["tipo_cambio_tercerizado"])) ? trim($data_request["tipo_cambio_tercerizado"]) : null,

				'id_proveedor_escolta'				=> (is_numeric($data_request["id_proveedor_escolta"])) ? trim($data_request["id_proveedor_escolta"]) : null,
				'id_moneda_escolta'					=> isset($data_request["id_moneda_escolta"]) ? trim($data_request["id_moneda_escolta"]) : null,
				'tipo_cambio_escolta'				=> isset($data_request["tipo_cambio_escolta"]) ? trim($data_request["tipo_cambio_escolta"]) : null,
				'costo_escolta'						=> isset($data_request["costo_escolta"]) ? trim($data_request["costo_escolta"]) : null,
				'monto_adelanto_escolta'			=> (isset($data_request["monto_adelanto_escolta"]) && $data_request["monto_adelanto_escolta"] != '') ? trim($data_request["monto_adelanto_escolta"]) : 0,
				'porc_detraccion_escolta'			=> isset($data_request["porc_detraccion_escolta"]) ? trim($data_request["porc_detraccion_escolta"]) : 0,
				'mas_inc_igv_escolta'				=> isset($data_request["mas_inc_igv_escolta"]) ? trim($data_request["mas_inc_igv_escolta"]) : null,
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$correlativo = $this->Viaje_m->get_correlativo(trim($data_request["serie"]));

				$data["serie"] = $correlativo->serie;
				$data["numero"] = $correlativo->numero;

				$data["fl_estado"] = 1;	
				$data["estado_operacion"] = 'REGISTRADO';				
				$data["fecha_sistema"] = date("Y-m-d H:i:s");
				$data["id_empresa"] = ID_EMPRESA;
				$data["id_usuario"] = ID_USUARIO;
			}

			$this->Viaje_m->save($data);

			$id_viaje = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			/*** SAVE GUIAS */
			$this->Viaje_guia_m->where('id_viaje', $id_viaje)->delete();
			/** TRANSPORTISTA */

			$data_detalle_guia = [];

			foreach (json_decode($data_request["detalle_guia_transportista"]) as $row) {
				$data_detalle_guia[] = [
					'id_viaje'			=> $id_viaje,
					'tipo'				=> 'TRANSPORTISTA',
					'serie'				=> strtoupper($row->serie),
					'numero'			=> $row->numero,
					'punto_origen'		=> $row->punto_origen,
					'punto_destino'		=> $row->punto_destino,
					'fl_estado'			=> 1
				];
			}

			if(count($data_detalle_guia) > 0)
			{
				$this->Viaje_guia_m->insertbatch($data_detalle_guia);
			}

			/** TERCERO */
			$data_detalle_guia = [];

			foreach (json_decode($data_request["detalle_guia_tercero"]) as $row) {
				$data_detalle_guia[] = [
					'id_viaje'			=> $id_viaje,
					'tipo'				=> 'TERCERO',
					'serie'				=> strtoupper($row->serie),
					'numero'			=> $row->numero,
					'punto_origen'		=> $row->punto_origen,
					'punto_destino'		=> $row->punto_destino,
					'fl_estado'			=> 1
				];
			}

			if(count($data_detalle_guia) > 0)
			{
				$this->Viaje_guia_m->insertbatch($data_detalle_guia);
			}

			/** AYUDANTE */
			$data_detalle_ayudante = [];
			$this->Viaje_ayudante_m->where('id_viaje', $id_viaje)->delete();

			foreach (json_decode($data_request["detalle_ayudante"]) as $row) {
				$data_detalle_ayudante[] = [
					'id_viaje'			=> $id_viaje,
					'nombre'			=> $row->nombre,
					'tipo'				=> $row->tipo,
				];
			}

			if(count($data_detalle_ayudante) > 0)
			{
				$this->Viaje_ayudante_m->insertbatch($data_detalle_ayudante);
			}

			/*** VIAJE ORDEN	 */

			$data_detalle_orden = [];
			$this->Viaje_orden_m->where('id_viaje', $id_viaje)->delete();

			foreach (json_decode($data_request["detalle_orden"]) as $row) {

				if(($data_request["fl_compartimiento"] == 1) && !is_numeric($row->id_vehiculo_compartimiento))
				{
					return $this->respond(['tipo' => 'warning', 'mensaje' => 'Existe Órdenes sin asignación de compartimiento'], 400);
				}

				$data_detalle_orden[] = [
					'id_viaje'						=> $id_viaje,
					'id_orden'						=> $row->id,
					'id_vehiculo_compartimiento'	=> ($data_request["fl_compartimiento"] == 1) ? $row->id_vehiculo_compartimiento : null,
				];				
			}

			if(count($data_detalle_orden) > 0)
			{
				$this->Viaje_orden_m->insertbatch($data_detalle_orden);
			}

			/** CONCEPTOS TERCERIZADOS */
			$data_detalle_concepto_tercerizado = [];
			$this->Viaje_concepto_tercerizado_m->where('id_viaje', $id_viaje)->delete();

			foreach (json_decode($data_request["detalle_concepto_tercerizado"]) as $row) {
				$data_detalle_concepto_tercerizado[] = [
					'id_viaje'			=> $id_viaje,
					'concepto'			=> $row->concepto,
					'monto'				=> $row->monto,
				];
			}

			if(count($data_detalle_concepto_tercerizado) > 0)
			{
				$this->Viaje_concepto_tercerizado_m->insertbatch($data_detalle_concepto_tercerizado);
			}


			/*** VIAJE ESCOLTA	 */
			$data_detalle = [];
			$this->Viaje_escolta_m->where('id_viaje', $id_viaje)->delete();

			foreach (json_decode($data_request["detalle_escolta"]) as $row) {

				$data_detalle[] = [
					'id_viaje'						=> $id_viaje,
					'vehiculo'						=> $row->vehiculo,
					'descripcion'					=> $row->descripcion,
				];				
			}

			if(count($data_detalle) > 0)
			{
				$this->Viaje_escolta_m->insertbatch($data_detalle);
			}

			/************ SOLO AL CREAR  NUEVO VIAJE */

			if(!isset($data_request["id"]))
			{
				/** VERIFICAR SALDO DE GASTO OPERATIVO PENDIENTE */
				$Liquidacion_gasto_operativo_m = new Liquidacion_gasto_operativo_model();
				$liquidaciones = $Liquidacion_gasto_operativo_m->where('id_empresa', ID_EMPRESA)
				->where('tipo_accion', 'SALDO A SIGUIENTE ORDEN')
				->where('fl_estado', 1)
				->where('fl_tipo_accion', 0)
				->where('id_conductor', $data_request["id_conductor"])
				->findAll();
	  
				if(count($liquidaciones) > 0)
				{
					$monto_caja = 0;
					
					foreach ($liquidaciones as $row) {
						$monto_caja = $monto_caja + $row->total_saldo;

						$data_liquidacion = [
							'id'				=> $row->id,
							'fl_tipo_accion'	=> 1
						];

						$Liquidacion_gasto_operativo_m->save($data_liquidacion);
					}
		
					$Caja_m = new Caja_model();
					$Personal_m = new Personal_model();
		
					$conductor = $Personal_m->select('nombre_completo')
					->find($data_request["id_conductor"]);
		
					/** CREAR CAJA  */

					$correlativo = $Caja_m->get_correlativo(date("Y"));

					$data = [
						'serie'							=> $correlativo->serie,
						'numero'						=> $correlativo->numero,
						'fecha'							=> trim($data_request["fecha"]),
						'id_viaje'						=> $id_viaje,
						'tipo_persona'					=> 'CONDUCTOR',
						'id_tipo_persona'				=> $data_request["id_conductor"],
						'nombre_persona'				=> $conductor->nombre_completo,
						'modalidad'						=> 'EFECTIVO',
						'motivo'						=> 'GASTOS OPERATIVOS',
						'descripcion'					=> 'SALDO DE LIQUIDACIÓN DE GASTOS OPERATIVOS',
						'importe'						=> $monto_caja,
						'id_empresa'					=> ID_EMPRESA,
						'fl_estado'						=> 1
					];

					$Caja_m->save($data);
	  
	  
				}
			}


			/****************** SAVE CENTINELA *****************/
			$viaje = $this->Viaje_m->find($id_viaje);

			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'ÓRDENES DE VIAJE',
				'accion'		=> (isset($data_request["id"])) ? 'EDITAR' : 'NUEVO',
				'descripcion'	=> $viaje->serie.'-'.$viaje->numero
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->query('UNLOCK TABLES');
        	$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('operacion-viaje', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();


			/** ELIMINAR VIAJE ORDEN */
			$this->Viaje_orden_m->where('id_viaje', $data_request["id"])->delete();

			$data = [
				'id'		=> $data_request["id"],
				'fl_estado'	=> 0
			];

			$this->Viaje_m->save($data); 
			
			/****************** SAVE CENTINELA *****************/
			$viaje = $this->Viaje_m->find($data_request["id"]);

			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'ÓRDENES DE VIAJE',
				'accion'		=> 'ANULAR',
				'descripcion'	=> $viaje->serie.'-'.$viaje->numero
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Anulado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function inicio_viaje()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('operacion-viaje', 'edit');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$data = [
				'fecha_inicio'		=> $data_request["fecha_inicio_viaje"],
				'km_inicio'			=> $data_request["km_inicio"],
				'estado_operacion'	=> 'INICIADO',
				'id'				=> $data_request["id"]
			];

			$this->Viaje_m->save($data);

			/** UPDATE KM VEHICULO */
			if($data_request["km_inicio"] != '')
			{
				$viaje = $this->Viaje_m->find($data_request["id"]);

				$data_vehiculo = [
					'id_vehiculo'		=> $viaje->id_vehiculo,
					'fecha'				=> $data_request["fecha_inicio_viaje"],
					'km'				=> $data_request["km_inicio"]
				];

				$this->Vehiculo_km_m->save($data_vehiculo);
			}			
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function retorno_viaje()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('operacion-viaje', 'edit');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$data = [
				'fecha_retorno'		=> $data_request["fecha_retorno_viaje"],
				'km_retorno'		=> $data_request["km_retorno"],
				'estado_operacion'	=> 'RETORNANDO',
				'id'				=> $data_request["id"]
			];

			$this->Viaje_m->save($data);

			/** UPDATE KM VEHICULO */
			if($data_request["km_retorno"] != '')
			{
				$viaje = $this->Viaje_m->find($data_request["id"]);

				$data_vehiculo = [
					'id_vehiculo'		=> $viaje->id_vehiculo,
					'fecha'				=> $data_request["fecha_retorno_viaje"],
					'km'				=> $data_request["km_retorno"]
				];

				$this->Vehiculo_km_m->save($data_vehiculo);
			}			
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function fin_viaje()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('operacion-viaje', 'edit');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$data = [
				'fecha_fin'			=> $data_request["fecha_fin_viaje"],
				'km_fin'			=> $data_request["km_fin"],
				'km_gps'			=> $data_request["km_gps"],
				'estado_operacion'	=> 'FINALIZADO',
				'comentario'		=> $data_request["comentario"],
				'id'				=> $data_request["id"]
			];

			$this->Viaje_m->save($data);

			$viaje = $this->Viaje_m->find($data_request["id"]);

			/** UPDATE KM VEHICULO */
			if($data_request["km_fin"] != '')
			{
				$data_vehiculo = [
					'id_vehiculo'		=> $viaje->id_vehiculo,
					'fecha'				=> $data_request["fecha_fin_viaje"],
					'km'				=> $data_request["km_fin"]
				];

				$this->Vehiculo_km_m->save($data_vehiculo);
			}	
			
			/** DEVOLUCIÓN DE CONTENEDOR */

			if($viaje->tipo_carga == 'CONTENEDOR')
			{
				$data_contenedor = [
					'id_viaje'			=> $viaje->id,
					'numero_contenedor'	=> $viaje->numero_contenedor,
					'id_empresa'		=> ID_EMPRESA,
					'estado'			=> 'PENDIENTE'
				];

				if(isset($data_request["fl_contenedor"]))
				{
					$data_contenedor["fecha"] = $data_request["fecha_fin_viaje"];
					$data_contenedor["estado"] = 'DEVUELTO';
				}

				$this->Devolucion_contenedor_m->save($data_contenedor);
			}
			
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function conductor_monitoreo()
	{		
		$data_request = $this->request->getGet();

		$response = $this->Viaje_m->select('viaje.*, concat(serie,"-",numero) as viaje')
		->select('cond.nombre_completo as conductor')
		->select('concat(r.punto_inicio," - ",r.punto_final) as ruta')
		->select('v.placa as vehiculo, v.tipo_contratacion')
		->select('vr.placa as remolque')
		->select('coalesce(p.razon_social, "") as proveedor')
		->join('personal cond', 'cond.id = viaje.id_conductor', 'left')
		->join('ruta r', 'r.id = viaje.id_ruta', 'left')
		->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
		->join('vehiculo vr', 'vr.id = viaje.id_remolque', 'left')
		->join('proveedor p', 'p.id = v.id_proveedor', 'left')
		->where('viaje.id_conductor', ID_PERSONAL)
		->where('estado_operacion !=', 'REGISTRADO')
		->where('estado_operacion !=', 'FINALIZADO')
        ->where('fl_estado', 1)
		->where('viaje.id_empresa', ID_EMPRESA)		
		->findAll();

		foreach ($response as $row) {

			$monitoreo = $this->Viaje_monitoreo_m->select('viaje_monitoreo.*, em.nombre as estado, em.color_bg, em.color_text')
			->join('estado_monitoreo em', 'em.id = viaje_monitoreo.id_estado_monitoreo')
			->where('id_viaje', $row->id)
			->orderBy('fecha', 'desc')
			->orderBy('id', 'desc')
			->first();

			$row->ultimo_monitoreo = (is_object($monitoreo)) ? $monitoreo : null;

			$row->ordenes = $this->Viaje_orden_m->select('coalesce(sc.razon_social, "") as subcliente, coalesce(orden.direccion_llegada, "") as direccion_llegada, orden.total_orden, concat(orden.serie,"-", orden.numero) as orden')
			->select('coalesce(c.razon_social, "") as cliente')
			->join('orden', 'orden.id = viaje_orden.id_orden', 'left')
			->join('cliente c', 'c.id = orden.id_cliente', 'left')
			->join('subcliente sc', 'sc.id = orden.id_subcliente', 'left')			
			->where('viaje_orden.id_viaje', $row->id)->findAll();
	
		}

		return $this->respond(['data' => $response], 200);
	}

	public function get_viaje_conductor()
	{		
		$data_request = $this->request->getGet();

		if(ID_PERSONAL == null)
		{
			return $this->respond(['tipo' => 'warning', 'mensaje' => 'El usuario actual no está vinculado a un personal'], 400);
		}
		else
		{
			$response = $this->Viaje_m->select('viaje.*, concat(serie,"-",numero) as viaje')
			->select('cond.nombre_completo as conductor')
			->select('concat(r.punto_inicio," - ",r.punto_final) as ruta')
			->select('v.placa as vehiculo, v.tipo_contratacion')
			->select('vr.placa as remolque')
			->select('coalesce(p.razon_social, "") as proveedor')
			->join('personal cond', 'cond.id = viaje.id_conductor', 'left')
			->join('ruta r', 'r.id = viaje.id_ruta', 'left')
			->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
			->join('vehiculo vr', 'vr.id = viaje.id_remolque', 'left')
			->join('proveedor p', 'p.id = v.id_proveedor', 'left')
			->where('viaje.id_conductor', ID_PERSONAL)
			->where('viaje.estado_operacion !=', 'REGISTRADO')
			->where('viaje.estado_operacion !=', 'FINALIZADO')
			->where('viaje.fl_estado', 1)
			->where('viaje.id_empresa', ID_EMPRESA)		
			->first();

			if(is_object($response))
			{
				return $this->respond($response, 200);
			}
			else
			{
				return $this->respond(['tipo' => 'warning', 'mensaje' => 'No existe viajes iniciados'], 400);
			}
			
		}
		
	}
			
}
