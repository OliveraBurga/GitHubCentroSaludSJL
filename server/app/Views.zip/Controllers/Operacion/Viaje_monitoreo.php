<?php namespace App\Controllers\Operacion;

use App\Controllers\BaseController;

use App\Models\Operacion\Viaje_monitoreo_model;
use App\Models\Image_model;

class Viaje_monitoreo extends BaseController
{
	public function __construct()
	{
		$this->Viaje_monitoreo_m = new Viaje_monitoreo_model();
	}

	public function get_select_tipo_carga()
	{

		$response = $this->Viaje_monitoreo_m->distinct('tipo_carga')
		->select("tipo_carga as text")
		->where('id_empresa', ID_EMPRESA)
		->findAll();

		return $this->respond($response, 200);
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response = $this->Viaje_monitoreo_m->select("id, concat(serie, ' - ', numero) as text");

		$response = $response
		->where('id_empresa', ID_EMPRESA)
		->findAll();
		
		return $this->respond($response, 200);
	}

	public function get_correlativo($serie)
	{
		$secuencia = $this->Viaje_monitoreo_m->get_correlativo($serie);

		return $this->respond($secuencia, 200);
	}

	public function sin_viaje()
	{		
		$response = $this->Viaje_monitoreo_m->select('viaje_monitoreo.*, concat(serie,"-",numero) as viaje_monitoreo')
		->select('c.razon_social as cliente')
		->select('concat(r.punto_inicio," - ",r.punto_final) as ruta')
		->select('m.nombre as moneda')
		->join('cliente c', 'c.id = viaje_monitoreo.id_cliente', 'left')
		->join('ruta r', 'r.id = viaje_monitoreo.id_ruta', 'left')
		->join('static_moneda m', 'm.id = viaje_monitoreo.id_moneda')
		->where('viaje_monitoreo.id_viaje', null)
		->where('viaje_monitoreo.fl_estado', 1)
		->where('viaje_monitoreo.id_empresa', ID_EMPRESA)		
		->findAll();

		return $this->respond(['data' => $response], 200);
	}

	public function index()
	{
		$data_request = $this->request->getGet();

		$response = $this->Viaje_monitoreo_m->select('viaje_monitoreo.*')
		->select('em.nombre as estado')
		->select("concat(v.serie,'-',v.numero) as viaje")
		->join('estado_monitoreo em', 'em.id = viaje_monitoreo.id_estado_monitoreo')
		->join('viaje v', 'v.id = viaje_monitoreo.id_viaje')
		->where('id_viaje', $data_request["id_viaje"])
		->orderBy('fecha', 'asc')
		->orderBy('id', 'asc')
		->findAll();

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$Imagen_upload = new Image_model();
			$foto = $Imagen_upload->guardar($this->request->getFile('foto'), 'viaje_monitoreo', (isset($data_request["foto_anterior"])) ? $data_request["foto_anterior"] : null);

			/** GUARDAR */
			$data = [
				'fecha'                 => trim($data_request["fecha"]).' '.(($data_request["hora"] != '') ? trim($data_request["hora"]) : '00:00'), 
				'id_estado_monitoreo'	=> trim($data_request["id_estado_monitoreo"]), 
				'comentario'			=> trim($data_request["comentario"]), 
				'latitud'				=> trim($data_request["mapa_latitud"]), 
				'longitud'				=> trim($data_request["mapa_longitud"]), 
				'foto'					=> $foto, 
				'fl_mapa'				=> (isset($data_request["fl_mapa"])) ? 1 : 0, 
				'id_usuario'           	=>	ID_USUARIO
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$data["id_viaje"] = trim($data_request["id_viaje"]);
				$data["fecha_sistema"] = date("Y-m-d H:i:s");
			}

			$this->Viaje_monitoreo_m->save($data);

			$id_viaje_monitoreo = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			/****************** SAVE CENTINELA *****************/
			$monitoreo = $this->Viaje_monitoreo_m->select('em.nombre as estado, concat(v.serie,"-",v.numero) as viaje')
			->join('estado_monitoreo em', 'em.id = viaje_monitoreo.id_estado_monitoreo')
			->join('viaje v', 'v.id = viaje_monitoreo.id_viaje')
			->find($id_viaje_monitoreo);

			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'MONITOREO DE VIAJES',
				'accion'		=> (isset($data_request["id"])) ? 'EDITAR' : 'NUEVO',
				'descripcion'	=> $monitoreo->estado.', Viaje: '.$monitoreo->viaje
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('operacion-viaje', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();			

			$monitoreo = $this->Viaje_monitoreo_m->select('em.nombre as estado, concat(v.serie,"-",v.numero) as viaje, viaje_monitoreo.foto')
			->join('estado_monitoreo em', 'em.id = viaje_monitoreo.id_estado_monitoreo')
			->join('viaje v', 'v.id = viaje_monitoreo.id_viaje')
			->find($data_request["id"]);

			$this->Viaje_monitoreo_m->where('id', $data_request["id"])->delete();

			/****************** SAVE CENTINELA *****************/

			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'MONITOREO DE VIAJES',
				'accion'		=> 'ELIMINAR',
				'descripcion'	=> $monitoreo->estado.', Viaje: '.$monitoreo->viaje
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */

			/** ELIMINAR IMAGEN */
			$Imagen_upload = new Image_model();
			$Imagen_upload->eliminar($monitoreo->foto);
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function enviar_email()
	{
		try {

			$data_request = $this->request->getPost();

			/**** ARRAY EMAILS */
			$array_email = [];

			foreach (json_decode($data_request["email"]) as $row) {
				
				$mail_more = explode(",", $row);

				if(count($mail_more) > 1)
				{
					foreach ($mail_more as $mail) {
						$array_email[] = $mail;
					}
				}
				else
				{
					$array_email[] = $row;
				}
			}

			/******** */

			$monitoreo = $this->Viaje_monitoreo_m->select('viaje_monitoreo.*, em.nombre as estado, concat(v.serie,"-",v.numero) as viaje')
			->join('estado_monitoreo em', 'em.id = viaje_monitoreo.id_estado_monitoreo')
			->join('viaje v', 'v.id = viaje_monitoreo.id_viaje')
			->find($data_request["id"]);

			$htmlContent = view('email/viaje_monitoreo', ['data' => $monitoreo]);

			$db = \Config\Database::connect();
			$sistema = $db->table('static_system')->get()->getRow();

			$email = \Config\Services::email();
		
			$config['mailType'] = 'html';

			$email->initialize($config);

			$email->setFrom($sistema->email_robot, $sistema->empresa);
			$email->setTo(implode(", ", $array_email));

			$email->setSubject('MONITOREO DE VIAJE '.$monitoreo->viaje);
			$email->setMessage($htmlContent);

			$email->send();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Proceso completado correctamente'], 200);
			
		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}

	}
		
}
