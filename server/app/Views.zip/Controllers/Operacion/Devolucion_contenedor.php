<?php namespace App\Controllers\Operacion;

use App\Controllers\BaseController;

use App\Models\Operacion\Devolucion_contenedor_model;

class Devolucion_contenedor extends BaseController
{
	public function __construct()
	{
		$this->Devolucion_contenedor_m = new Devolucion_contenedor_model();
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response = $this->Devolucion_contenedor_m->select("id, concat(serie, ' - ', numero) as text");

		$response = $response
		->where('id_empresa', ID_EMPRESA)
		->findAll();
		
		return $this->respond($response, 200);
	}

	public function index()
	{		
		$data_request = $this->request->getGet();

		$response = $this->Devolucion_contenedor_m->select('devolucion_contenedor.*')
		->select('concat(v.serie, "-", v.numero) as viaje')
		->join('viaje v', 'v.id = devolucion_contenedor.id_viaje', 'left')

		->where('DATE_FORMAT(devolucion_contenedor.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(devolucion_contenedor.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])
		->where('devolucion_contenedor.id_empresa', ID_EMPRESA)		
		->findAll();

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('operacion-devolucion_contenedor', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('operacion-devolucion_contenedor', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			/** GUARDAR */
			$data = [
				'fecha' 			=> trim($data_request["fecha"]),
				'numero_contenedor'	=> trim($data_request["numero_contenedor"]),
				'estado'			=> trim($data_request["estado"]),
				'comentario'		=> trim($data_request["comentario"]),
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$data["id_empresa"] = ID_EMPRESA;
			}

			$this->Devolucion_contenedor_m->save($data);

			$id_devolucion_contenedor = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			/****************** SAVE CENTINELA *****************/			
			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'DEVOLUCIÓN DE CONTENEDOR',
				'accion'		=> (isset($data_request["id"])) ? 'EDITAR' : 'NUEVO',
				'descripcion'	=> $data_request["numero_contenedor"]
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('operacion-devolucion_contenedor', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$devolucion = $this->Devolucion_contenedor_m->find($data_request["id"]);

			$this->Devolucion_contenedor_m->where('id', $data_request["id"])->delete();     

			/****************** SAVE CENTINELA *****************/			
			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'DEVOLUCIÓN DE CONTENEDOR',
				'accion'		=> 'ELIMINAR',
				'descripcion'	=> $devolucion->numero_contenedor
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
