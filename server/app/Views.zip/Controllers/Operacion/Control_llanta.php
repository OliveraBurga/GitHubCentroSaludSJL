<?php namespace App\Controllers\Operacion;

use App\Controllers\BaseController;

use App\Models\Operacion\Control_llanta_model;
use App\Models\Configuracion\Vehiculo_llanta_model;

class Control_llanta extends BaseController
{
	public function __construct()
	{
		$this->Control_llanta_m = new Control_llanta_model();
		$this->Vehiculo_llanta_m = new Vehiculo_llanta_model();
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response = $this->Control_llanta_m->select("id, concat(serie, ' - ', numero) as text");

		$response = $response
		->where('id_empresa', ID_EMPRESA)
		->findAll();
		
		return $this->respond($response, 200);
	}

	public function index()
	{		
		$data_request = $this->request->getGet();

		$response = $this->Control_llanta_m->select('control_llanta.*')
		
		->select('v.placa as vehiculo')
		->select('concat(vll.codigo_unico," - ", vll.posicion) as llanta, vll.id_vehiculo')

		
		->join('vehiculo_llanta vll', 'vll.id = control_llanta.id_vehiculo_llanta', 'left')
		->join('vehiculo v', 'v.id = vll.id_vehiculo', 'left')

		->where('DATE_FORMAT(control_llanta.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(control_llanta.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])
		->where('control_llanta.id_empresa', ID_EMPRESA)		
		->findAll();

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('operacion-control_llanta', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('operacion-control_llanta', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			/** GUARDAR */
			$data = [
				'fecha'   				=> trim($data_request["fecha"]),
				'id_vehiculo_llanta'   	=> trim($data_request["id_vehiculo_llanta"]),
				'kilometraje'           => ($data_request["kilometraje"] != '') ? trim($data_request["kilometraje"]) : null,
				'condicion'  			=> trim($data_request["condicion"]),
				'presion'     			=> trim($data_request["presion"]),
				'observacion'         	=> trim($data_request["observacion"]),
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$data["fecha_sistema"] = date("Y-m-d H:i:s");
				$data["id_empresa"] = ID_EMPRESA;
			}

			$this->Control_llanta_m->save($data);

			/****************** SAVE CENTINELA *****************/
			$llanta = $this->Vehiculo_llanta_m->select('vehiculo_llanta.codigo, v.placa')
			->join('vehiculo v', 'v.id = vehiculo_llanta.id_vehiculo')
			->where('vehiculo_llanta.id', $data_request["id_vehiculo_llanta"])
			->first();

			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'CONTROL DE LLANTAS',
				'accion'		=> (isset($data_request["id"])) ? 'EDITAR' : 'NUEVO',
				'descripcion'	=> $llanta->placa.' - '.$llanta->codigo
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('operacion-control_llanta', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$llanta = $this->Control_llanta_m->select('vehiculo_llanta.codigo, v.placa')
			->join('vehiculo_llanta', 'vehiculo_llanta.id = control_llanta.id_vehiculo_llanta')
			->join('vehiculo v', 'v.id = vehiculo_llanta.id_vehiculo')
			->where('control_llanta.id', $data_request["id"])
			->first();

			$this->Control_llanta_m->where('id', $data_request["id"])->delete();    
			
			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'CONTROL DE LLANTAS',
				'accion'		=> 'ELIMINAR',
				'descripcion'	=> $llanta->placa.' - '.$llanta->codigo
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
