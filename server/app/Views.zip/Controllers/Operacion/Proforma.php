<?php namespace App\Controllers\Operacion;

use App\Controllers\BaseController;

use App\Models\Configuracion\Empresa_model;
use App\Models\Configuracion\Ajuste_avanzado_model;
use App\Models\Operacion\Proforma_model;
use App\Models\Operacion\Proforma_detalle_model;
use App\Models\Configuracion\Cuenta_bancaria_empresa_model;
use App\Models\Configuracion\Usuario_model;

class Proforma extends BaseController
{
	public function __construct()
	{
		$this->Proforma_m = new Proforma_model();
		$this->Proforma_detalle_m = new Proforma_detalle_model();
		$this->Empresa_m = new Empresa_model();
		$this->Ajuste_avanzado_m = new Ajuste_avanzado_model();
		$this->Cuenta_bancaria_empresa_m = new Cuenta_bancaria_empresa_model();
	}

	public function imprimir($id_proforma)
	{
		$data_request = $this->request->getGet();

		$response = $this->Proforma_m->select('proforma.*, proforma.empresa as empresa_proforma')
		->select('proforma.*, concat(proforma.serie,"-",proforma.numero) as proforma')
		->select('c.nombre as comprobante')
		->select('m.nombre as moneda, m.simbolo as moneda_simbolo, m.codigo as moneda_codigo')
		->select('p.nombre_completo as usuario_nombre, p.numero_documento as usuario_dni, p.imagen_firma as usuario_firma')
		->join('static_comprobante c', 'c.id = proforma.id_comprobante', 'left')
		->join('static_moneda m', 'm.id = proforma.id_moneda', 'left')
		->join('usuario u', 'u.id = proforma.id_usuario', 'left')
		->join('personal p', 'p.id = u.id_personal', 'left')
		->find($id_proforma);

		$response->detalle = $this->Proforma_detalle_m->where('proforma_detalle.id_proforma', $id_proforma)
		->orderBy('proforma_detalle.id', 'asc')
		->findAll();

		$response->empresa = $this->Empresa_m->find(ID_EMPRESA);

		$response->cuentas_bancarias = $this->Cuenta_bancaria_empresa_m->where('id_empresa', ID_EMPRESA)->findAll();

		$response->ajuste = $this->Ajuste_avanzado_m->where('id_empresa', ID_EMPRESA)->first();

		return $this->respond($response, 200);
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response =	$this->Proforma_m->select("id, concat('FECHA: ', date_format(fecha, '%d/%m/%Y'), ' ', serie, ' - ', numero,'| RAZÓN SOCIAL: ', cliente_razon_social, ' IMPORTE: ', total_importe) as text");

		$serie_numero = explode('-', $data_request["buscar"]);
		$fecha = explode('/', $data_request["buscar"]);

		if(count($serie_numero) == 2)
		{
			/** SERIE NUMERO */
			$response->where('serie', $serie_numero[0]);
			$response->like('numero', '%'.$serie_numero[1]);
		}

		if(count($fecha) == 3)
		{
			/** FECHA */
			if($fecha[2] == '')
			{          
				$fecha[2] = date("Y");          
			}
			
			$response->where('DATE_FORMAT(fecha, "%Y-%m-%d")', $fecha[2].'-'.$fecha[1].'-'.$fecha[0]);
			
		}
		
		$response = $response->where('id_empresa', ID_EMPRESA)
		->findAll();
		
		return $this->respond($response, 200);
	}

	public function get_correlativo($id_comprobante, $serie)
	{
		$secuencia = $this->Proforma_m->get_correlativo($id_comprobante, $serie);

		return $this->respond($secuencia, 200);
	}

	public function get_unique($id_proforma)
	{		
		$data_request = $this->request->getGet();

		$response = $this->Proforma_m->find($id_proforma);
		$response->detalle = $this->Proforma_detalle_m->where('id_proforma', $id_proforma)->findAll();

		return $this->respond($response, 200);
	}


	public function index()
	{		
		$data_request = $this->request->getGet();

		$response = $this->Proforma_m->select('proforma.*, concat(proforma.serie,"-",proforma.numero) as proforma')		
		->select('c.nombre as comprobante')	
		->join('static_comprobante c', 'c.id = proforma.id_comprobante', 'left')
		->where('DATE_FORMAT(proforma.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(proforma.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])
		->where('proforma.id_empresa', ID_EMPRESA)		
		->findAll();

		return $this->respond(['data' => $response], 200);
	}		

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('operacion-proforma', 'new');

		try {

			$db = \Config\Database::connect();
			$db->query('SET AUTOCOMMIT = 0');
			$db->transStart();
			$db->query('LOCK TABLES proforma write,  proforma_detalle write, serie read, centinela write');

			$codigo_unico = ID_EMPRESA.'-'.trim($data_request["id_comprobante"]).'-'.trim($data_request["serie"]).'-'.trim($data_request["numero"]);
			
			/** GUARDAR */
			$data = [
				'fecha'							=> date("Y-m-d"),
				'id_comprobante'				=> trim($data_request["id_comprobante"]),
				'serie'							=> trim($data_request["serie"]),
				'id_cliente'					=> isset($data_request["id_cliente"]) ? trim($data_request["id_cliente"]) : null,
				'total_gravada'					=> trim($data_request["total_gravada"]),
				'total_igv'						=> trim($data_request["total_igv"]),
				'total_importe'					=> trim($data_request["total_importe"]),
				'nombre_contacto'				=> trim($data_request["nombre_contacto"]),
				'empresa'						=> trim($data_request["empresa"]),
				'direccion'						=> trim($data_request["direccion"]),
				'telefono'						=> trim($data_request["telefono"]),
				'email'							=> trim($data_request["email"]),
				'condicion_pago'				=> trim($data_request["condicion_pago"]),
				'id_moneda'						=> trim($data_request["id_moneda"]),
				'dias_pagar'					=> (isset($data_request["dias_pagar"])) ? trim($data_request["dias_pagar"]) : null,
				'medida'						=> trim($data_request["medida"]),
				'salida'						=> trim($data_request["salida"]),
				'llegada'						=> trim($data_request["llegada"]),
				'dias_oferta'					=> trim($data_request["dias_oferta"]),
				'observacion'					=> trim($data_request["observacion"]),
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$correlativo = $this->Proforma_m->get_correlativo($data_request["id_comprobante"], $data_request["serie"]);
				$data["numero"] = $correlativo->numero;

				$data["fecha_sistema"] = date("Y-m-d H:i:s");
				$data["fl_estado"] = 1;
				$data["id_empresa"] = ID_EMPRESA;
				$data["id_usuario"] = ID_USUARIO;
			}

			$this->Proforma_m->save($data);

			$id_proforma = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			/** SAVE DETALLE */

			$data_detalle = [];

			$this->Proforma_detalle_m->where('id_proforma', $id_proforma)->delete();

			foreach (json_decode($data_request["detalle"]) as $row) {
				$data_detalle[] = [
					'id_proforma'				=> $id_proforma,
					'cantidad'					=> $row->cantidad,
					'descripcion'				=> $row->descripcion,
					'valor_unitario'			=> $row->valor_unitario,
					'precio_unitario'			=> $row->precio_unitario,
					'subtotal'					=> $row->subtotal,
					'tipo_igv'					=> 1, // GRAVADA
					'igv'						=> $row->igv,
					'importe'					=> $row->importe,
					'porcentaje_igv'			=> $row->porcentaje_igv,
				];
			}

			$this->Proforma_detalle_m->insertbatch($data_detalle);

			/****************** SAVE CENTINELA *****************/
			$proforma = $this->Proforma_m->find($id_proforma);

			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'PROFORMAS',
				'accion'		=> (isset($data_request["id"])) ? 'EDITAR' : 'NUEVO',
				'descripcion'	=> $proforma->serie.'-'.$proforma->numero
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */

			$db->query('UNLOCK TABLES');
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente', 'id_proforma'	=> $id_proforma], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function anular()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('operacion-proforma', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$data = [
				'id'		=> $data_request["id"],
				'fl_estado'	=> 0
			];

			$this->Proforma_m->save($data);

			/****************** SAVE CENTINELA *****************/
			$proforma = $this->Proforma_m->find($data_request["id"]);

			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'PROFORMAS',
				'accion'		=> 'ANULAR',
				'descripcion'	=> $proforma->serie.'-'.$proforma->numero
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
