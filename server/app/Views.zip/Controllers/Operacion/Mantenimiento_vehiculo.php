<?php namespace App\Controllers\Operacion;

use App\Controllers\BaseController;

use App\Models\Operacion\Mantenimiento_vehiculo_model;
use App\Models\Configuracion\Vehiculo_km_model;
use App\Models\Configuracion\Proveedor_model;
use App\Models\Tesoreria\Caja_model;
use App\Models\Tesoreria\Flujo_caja_model;

class Mantenimiento_vehiculo extends BaseController
{
	public function __construct()
	{
		$this->Mantenimiento_vehiculo_m = new Mantenimiento_vehiculo_model();
		$this->Vehiculo_km_m = new Vehiculo_km_model();
		$this->Caja_m = new Caja_model();
		$this->Flujo_caja_m = new Flujo_caja_model();
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response = $this->Mantenimiento_vehiculo_m->select("id, concat(serie, ' - ', numero) as text");

		$response = $response
		->where('id_empresa', ID_EMPRESA)
		->findAll();
		
		return $this->respond($response, 200);
	}

	public function index()
	{		
		$data_request = $this->request->getGet();

		$response = $this->Mantenimiento_vehiculo_m->select('mantenimiento_vehiculo.*')
		->select('p.razon_social as proveedor')
		->select('v.placa as vehiculo')
		->select('m.nombre as moneda')
		->join('proveedor p', 'p.id = mantenimiento_vehiculo.id_proveedor', 'left')
		->join('vehiculo v', 'v.id = mantenimiento_vehiculo.id_vehiculo', 'left')
		->join('static_moneda m', 'm.id = mantenimiento_vehiculo.id_moneda', 'left')
		->where('DATE_FORMAT(mantenimiento_vehiculo.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(mantenimiento_vehiculo.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])
		->where('mantenimiento_vehiculo.id_empresa', ID_EMPRESA)		
		->findAll();

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('operacion-mantenimiento_vehiculo', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('operacion-mantenimiento_vehiculo', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->query('SET AUTOCOMMIT = 0');
			$db->transStart();
			$db->query('LOCK TABLES mantenimiento_vehiculo write, vehiculo_km write, centinela write, proveedor read, caja write, flujo_caja write, vehiculo read, ajuste_avanzado read');


			// CREAR CAJA RÁPIDA
			$id_caja = null;

			if(isset($data_request["modalidad"]))
			{
				$Proveedor_m = new Proveedor_model();
				$proveedor = $Proveedor_m->select('razon_social')->find($data_request["id_proveedor"]);
				
				/** GUARDAR */
				$data = [
					'fecha'							=> $data_request["fecha"],
					'tipo_persona'					=> 'PROVEEDOR',
					'id_tipo_persona'				=> $data_request["id_proveedor"],
					'nombre_persona'				=> $proveedor->razon_social,
					'motivo'						=> 'MANTENIMIENTO VEHICULO',
					'id_moneda'						=> trim($data_request["id_moneda"]),
					'tipo_cambio'         			=> (isset($data_request["tipo_cambio"])) ? trim($data_request["tipo_cambio"]) : null,
					'descripcion'					=> trim($data_request["descripcion"]),
					'modalidad'						=> $data_request["modalidad"],
					'importe'						=> trim($data_request["costo"]), 
					'cuenta_bancaria_persona'		=> (isset($data_request["cuenta_bancaria_persona"])) ? trim($data_request["cuenta_bancaria_persona"]) : null,
					'titular_cuenta'				=> (isset($data_request["titular_cuenta"])) ? trim($data_request["titular_cuenta"]) : null,
					'id_cuenta_bancaria_empresa'	=> ($data_request["id_cuenta_bancaria_empresa"] != '') ? trim($data_request["id_cuenta_bancaria_empresa"]) : null,
					'id_cuenta_bancaria_persona'	=> (isset($data_request["id_cuenta_bancaria_persona"])) ? trim($data_request["id_cuenta_bancaria_persona"]): null,
				];

				$correlativo = $this->Caja_m->get_correlativo(date("Y"));
				$data["serie"] = $correlativo->serie;
				$data["numero"] = $correlativo->numero;
				$data["tipo"] = 'CAJA_RAPIDA';
				$data["fl_estado"] = 3;
				$data["id_empresa"] = ID_EMPRESA;
				$data["id_usuario"] = ID_USUARIO;

				$this->Caja_m->save($data);

				$id_caja = $db->insertID();

				/** SAVE FLUJO CAJA */
				$this->Flujo_caja_m->where('id_caja', $id_caja)->delete();

				$data =  [
					'fecha'       					=> $data_request["fecha"],
					'tipo'        					=> 'EGRESO',
					'descripcion' 					=> trim($data_request["descripcion"]),
					'id_caja'						=> $id_caja,
					'id_usuario'  					=> ID_USUARIO,
					'id_empresa' 					=> ID_EMPRESA,
					'id_cuenta_bancaria_empresa'   	=> ($data_request["id_cuenta_bancaria_empresa"] != '') ? $data_request["id_cuenta_bancaria_empresa"] : null,
					'monto'       					=> trim($data_request["costo"]),
					'id_moneda'						=> trim($data_request["id_moneda"]),
					'tipo_cambio'					=> (isset($data_request["tipo_cambio"])) ? trim($data_request["tipo_cambio"]) : null,
				];

				$this->Flujo_caja_m->save($data);
			}
			

			/** GUARDAR */
			$data = [
				'id_vehiculo'         	=> trim($data_request["id_vehiculo"]),
				'fecha'               	=> trim($data_request["fecha"]),
				'tipo'  			  	=> trim($data_request["tipo"]),
				'mantenimiento'     	=> trim($data_request["mantenimiento"]),
				'numero_documento'    	=> trim($data_request["numero_documento"]),
				'id_proveedor'        	=> trim($data_request["id_proveedor"]),
				'descripcion'         	=> trim($data_request["descripcion"]),
				'costo'               	=> trim($data_request["costo"]),
				'kilometraje'         	=> trim($data_request["kilometraje"]),
				'id_moneda'         	=> trim($data_request["id_moneda"]),
				'tipo_cambio'         	=> (isset($data_request["tipo_cambio"])) ? trim($data_request["tipo_cambio"]) : null,
				'tipo_pago'         	=> trim($data_request["tipo_pago"]),
				'dias_credito'         	=> (isset($data_request["dias_credito"])) ? trim($data_request["dias_credito"]) : null, 
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$data["fecha_sistema"] = date("Y-m-d H:i:s");
				$data["id_empresa"] = ID_EMPRESA;
				$data["id_usuario"] = ID_USUARIO;
			}

			if($id_caja != null)
			{
				$data["id_caja"] = $id_caja;
			}

			$this->Mantenimiento_vehiculo_m->save($data);

			$id_mantenimiento_vehiculo = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			$data_vehiculo = [
				'id_vehiculo'		=> trim($data_request["id_vehiculo"]),
				'fecha'				=> $data_request["fecha"],
				'km'				=> $data_request["kilometraje"]
			];

			$this->Vehiculo_km_m->save($data_vehiculo);

			
			/****************** SAVE CENTINELA *****************/
			$mantenimiento = $this->Mantenimiento_vehiculo_m->select('mantenimiento_vehiculo.*, vehiculo.placa')
			->join('vehiculo', 'vehiculo.id = mantenimiento_vehiculo.id_vehiculo')
			->where('mantenimiento_vehiculo.id', $id_mantenimiento_vehiculo)
			->first();

			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'MANTENIMIENTO DE VEHÍCULOS',
				'accion'		=> (isset($data_request["id"])) ? 'EDITAR' : 'NUEVO',
				'descripcion'	=> 'Vehículo: '.$mantenimiento->placa.', '.$mantenimiento->descripcion,
				
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->query('UNLOCK TABLES');
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente', 'id_caja' => $id_caja], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('operacion-mantenimiento_vehiculo', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$mantenimiento = $this->Mantenimiento_vehiculo_m->select('mantenimiento_vehiculo.*, v.placa')
			->join('vehiculo v', 'v.id = mantenimiento_vehiculo.id_vehiculo')
			->where('mantenimiento_vehiculo.id', $data_request["id"])
			->first();

			$this->Mantenimiento_vehiculo_m->where('id', $data_request["id"])->delete();     

			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'MANTENIMIENTO DE VEHÍCULOS',
				'accion'		=> 'ELIMINAR',
				'descripcion'	=> 'Vehículo: '.$mantenimiento->placa.', '.$mantenimiento->descripcion
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
