<?php namespace App\Controllers\Operacion;

use App\Controllers\BaseController;

use App\Models\Operacion\Vale_combustible_model;
use App\Models\Configuracion\Personal_model;
use App\Models\Operacion\Viaje_model;
use App\Models\Tesoreria\Caja_model;
use App\Models\Tesoreria\Flujo_caja_model;

class Vale_combustible extends BaseController
{
	public function __construct()
	{
		$this->Vale_combustible_m = new Vale_combustible_model();
		$this->Caja_m = new Caja_model();
		$this->Flujo_caja_m = new Flujo_caja_model();
	}

	public function get_select_tipo_carga()
	{

		$response = $this->Vale_combustible_m->distinct('tipo_carga')
		->select("tipo_carga as text")
		->where('id_empresa', ID_EMPRESA)
		->findAll();

		return $this->respond($response, 200);
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response = $this->Vale_combustible_m->select("id, concat(serie, ' - ', numero) as text");

		$response = $response
		->where('id_empresa', ID_EMPRESA)
		->findAll();
		
		return $this->respond($response, 200);
	}

	public function get_correlativo($serie)
	{
		$secuencia = $this->Vale_combustible_m->get_correlativo($serie);

		return $this->respond($secuencia, 200);
	}

	public function sin_viaje()
	{		
		$response = $this->Vale_combustible_m->select('vale_combustible.*, concat(serie,"-",numero) as vale_combustible')
		->select('c.razon_social as cliente')
		->select('concat(r.punto_inicio," - ",r.punto_final) as ruta')
		->select('m.nombre as moneda')
		->join('cliente c', 'c.id = vale_combustible.id_cliente', 'left')
		->join('ruta r', 'r.id = vale_combustible.id_ruta', 'left')
		->join('static_moneda m', 'm.id = vale_combustible.id_moneda')
		->where('vale_combustible.id_viaje', null)
		->where('vale_combustible.fl_estado', 1)
		->where('vale_combustible.id_empresa', ID_EMPRESA)		
		->findAll();

		return $this->respond(['data' => $response], 200);
	}

	public function index()
	{		
		$data_request = $this->request->getGet();

		$response = $this->Vale_combustible_m->select('vale_combustible.*, concat(vale_combustible.serie,"-",vale_combustible.numero) as vale_combustible')
		->select('pr.razon_social as proveedor')
		->select('v.placa as vehiculo')
		->select('cond.nombre_completo as conductor')
		->select('concat(vi.serie,"-",vi.numero) as viaje')
		->select('coalesce(m.simbolo, "") as simbolo_moneda, m.nombre as moneda')

		->join('proveedor pr', 'pr.id = vale_combustible.id_proveedor', 'left')
		->join('vehiculo v', 'v.id = vale_combustible.id_vehiculo', 'left')
		->join('personal cond', 'cond.id = vale_combustible.id_conductor', 'left')
		->join('viaje vi', 'vi.id = vale_combustible.id_viaje', 'left')
		->join('static_moneda m', 'm.id = vale_combustible.id_moneda', 'left')

		->where('DATE_FORMAT(vale_combustible.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(vale_combustible.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])
		->where('vale_combustible.id_empresa', ID_EMPRESA)		
		->findAll();

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('operacion-vale_combustible', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('operacion-vale_combustible', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->query('SET AUTOCOMMIT = 0');
			$db->transStart();
			$db->query('LOCK TABLES vale_combustible write, centinela write, personal read, viaje read, caja write, flujo_caja write, ajuste_avanzado read');

			$importe = $data_request["costo_galon"] * $data_request["galones"];

			$id_caja = null;

			// CREAR CAJA RÁPIDA
			if(isset($data_request["modalidad"]))
			{
				$Personal_m = new Personal_model();
				$conductor = $Personal_m->select('nombre_completo')->find($data_request["id_conductor"]);

				/** GUARDAR */
				$data = [
					'fecha'							=> $data_request["fecha"],
					'id_viaje'						=> (isset($data_request["id_viaje"])) ? $data_request["id_viaje"] : null,
					'tipo_persona'					=> 'CONDUCTOR',
					'id_tipo_persona'				=> $data_request["id_conductor"],
					'nombre_persona'				=> $conductor->nombre_completo,
					'motivo'						=> 'COMBUSTIBLE',
					'id_moneda'						=> trim($data_request["id_moneda"]),
					'tipo_cambio'         			=> (isset($data_request["tipo_cambio"])) ? trim($data_request["tipo_cambio"]) : null,
					'descripcion'					=> 'VALE DE COMBUSTIBLE SEGÚN COMPROBANTE:'.$data_request["numero_comprobante"],
					'modalidad'						=> $data_request["modalidad"],
					'importe'						=> $importe,
					'cuenta_bancaria_persona'		=> (isset($data_request["cuenta_bancaria_persona"])) ? trim($data_request["cuenta_bancaria_persona"]) : null,
					'titular_cuenta'				=> (isset($data_request["titular_cuenta"])) ? trim($data_request["titular_cuenta"]) : null,
					'id_cuenta_bancaria_empresa'	=> ($data_request["id_cuenta_bancaria_empresa"] != '') ? trim($data_request["id_cuenta_bancaria_empresa"]) : null,
					'id_cuenta_bancaria_persona'	=> (isset($data_request["id_cuenta_bancaria_persona"])) ? trim($data_request["id_cuenta_bancaria_persona"]): null,
				];

				$correlativo = $this->Caja_m->get_correlativo(date("Y"));
				$data["serie"] = $correlativo->serie;
				$data["numero"] = $correlativo->numero;
				$data["tipo"] = 'CAJA_RAPIDA';
				$data["fl_estado"] = 3;
				$data["id_empresa"] = ID_EMPRESA;
				$data["id_usuario"] = ID_USUARIO;

				$this->Caja_m->save($data);

				$id_caja = $db->insertID();

				/** SAVE FLUJO CAJA */
				$this->Flujo_caja_m->where('id_caja', $id_caja)->delete();

				$data =  [
					'fecha'       					=> $data_request["fecha"],
					'tipo'        					=> 'EGRESO',
					'descripcion' 					=> 'VALE DE COMBUSTIBLE SEGÚN COMPROBANTE:'.$data_request["numero_comprobante"],
					'id_caja'						=> $id_caja,
					'id_usuario'  					=> ID_USUARIO,
					'id_empresa' 					=> ID_EMPRESA,
					'id_cuenta_bancaria_empresa'   	=> ($data_request["id_cuenta_bancaria_empresa"] != '') ? $data_request["id_cuenta_bancaria_empresa"] : null,
					'monto'       					=> $importe,
					'id_moneda'						=> trim($data_request["id_moneda"]),
					'tipo_cambio'					=> (isset($data_request["tipo_cambio"])) ? trim($data_request["tipo_cambio"]) : null,
				];

				$this->Flujo_caja_m->save($data);
			}

			/** GUARDAR  VALE */
			$data = [
				'fecha'                 => trim($data_request["fecha"]), 
				'id_viaje'              => (isset($data_request["id_viaje"])) ? trim($data_request["id_viaje"]) : null, 
				'id_vehiculo'           => trim($data_request["id_vehiculo"]), 
				'id_conductor'          => trim($data_request["id_conductor"]), 
				'id_proveedor'          => trim($data_request["id_proveedor"]), 
				'estacion'              => trim($data_request["estacion"]), 
				'numero_comprobante'    => trim($data_request["numero_comprobante"]), 
				'numero_ticket'         => trim($data_request["numero_ticket"]), 
				'tipo'                  => trim($data_request["tipo"]), 
				'tipo_pago'          	=> trim($data_request["tipo_pago"]), 
				'dias_credito'         	=> (isset($data_request["dias_credito"])) ? trim($data_request["dias_credito"]) : null, 
				'kilometraje'           => trim($data_request["kilometraje"]), 
				'peso'                  => trim($data_request["peso"]), 
				'galones'               => trim($data_request["galones"]), 
				'costo_galon'         	=> trim($data_request["costo_galon"]),
				'importe'         		=> $importe,
				'observacion'           => trim($data_request["observacion"]),
				'id_moneda'         	=> trim($data_request["id_moneda"]),
				'tipo_cambio'         	=> (isset($data_request["tipo_cambio"])) ? trim($data_request["tipo_cambio"]) : null,
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$data["serie"] = trim($data_request["serie"]);
				$data["numero"] = str_pad(trim($data_request["numero"]),  8, "0", STR_PAD_LEFT);
				$data["fl_estado"] = 1;
				$data["id_empresa"] = ID_EMPRESA;
				$data["id_usuario"] = ID_USUARIO;
			}

			if($id_caja != null)
			{
				$data["id_caja"] = $id_caja;
			}			

			$this->Vale_combustible_m->save($data);

			$id_vale_combustible = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			/****************** SAVE CENTINELA *****************/
			$vale = $this->Vale_combustible_m->find($id_vale_combustible);

			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'VALES DE COMBUSTIBLE',
				'accion'		=> (isset($data_request["id"])) ? 'EDITAR' : 'NUEVO',
				'descripcion'	=> $vale->serie.'-'.$vale->numero
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->query('UNLOCK TABLES');
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente', 'id_caja' => $id_caja], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('operacion-vale_combustible', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$data = [
				'id'		=> $data_request["id"],
				'fl_estado'	=> 0
			];

			$this->Vale_combustible_m->save($data);

			/****************** SAVE CENTINELA *****************/
			$vale = $this->Vale_combustible_m->find($data_request["id"]);

			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'VALES DE COMBUSTIBLE',
				'accion'		=> 'ANULAR',
				'descripcion'	=> $vale->serie.'-'.$vale->numero
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
