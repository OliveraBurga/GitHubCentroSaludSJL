<?php namespace App\Controllers\Operacion;

use App\Controllers\BaseController;

use App\Models\Operacion\Gasto_operativo_model;
use App\Models\Upload_model;

class Gasto_operativo extends BaseController
{
	public function __construct()
	{
		$this->Gasto_operativo_m = new Gasto_operativo_model();
	}

	public function index()
	{		
		$data_request = $this->request->getGet();

		$response = $this->Gasto_operativo_m->select('gasto_operativo.*')
		->select('concat(v.serie, "-", v.numero) as viaje, v.id_liquidacion_gasto_operativo')
		->select('tg.nombre as tipo_gasto_operativo')
		->select('coalesce(m.simbolo, "") as simbolo_moneda, m.nombre as moneda')
		->select('pr.razon_social as proveedor')

		->join('viaje v', 'v.id = gasto_operativo.id_viaje', 'left')
		->join('tipo_gasto_operativo tg', 'tg.id = gasto_operativo.id_tipo_gasto_operativo', 'left')
		->join('static_moneda m', 'm.id = gasto_operativo.id_moneda', 'left')
		->join('proveedor pr', 'pr.id = gasto_operativo.id_proveedor', 'left')

		->where('DATE_FORMAT(gasto_operativo.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(gasto_operativo.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])
		->where('gasto_operativo.id_empresa', ID_EMPRESA);

		if(ID_PERSONAL != null)
		{
			$response->where('v.id_conductor', ID_PERSONAL);
		}

		$response = $response->findAll();

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('operacion-gasto_operativo', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('operacion-gasto_operativo', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			/* GUARDAR ARCHIVO */
			$Upload_m = new Upload_model();			
			$archivo = $Upload_m->guardar($this->request->getFile('archivo'), 'gasto_operativo', (isset($data_request["archivo_anterior"])) ? $data_request["archivo_anterior"] : null);

			/** GUARDAR */
			$data = [
				'fecha' 						=> trim($data_request["fecha"]),
				'id_tipo_gasto_operativo'		=> trim($data_request["id_tipo_gasto_operativo"]),
				'detalle'						=> trim($data_request["detalle"]),
				'id_viaje'						=> trim($data_request["id_viaje"]),
				'numero_documento'  			=> trim($data_request["numero_documento"]),
				'importe'						=> trim($data_request["importe"]),
				'id_moneda'						=> trim($data_request["id_moneda"]),
				'archivo'						=> $archivo,
				'fl_comprobante_fiscal'			=> (isset($data_request["fl_comprobante_fiscal"])) ? 1 : 0,
				'detalle_comprobante_fiscal'	=> (isset($data_request["detalle_comprobante_fiscal"])) ? $data_request["detalle_comprobante_fiscal"] : '',
				'id_proveedor'					=> (isset($data_request["id_proveedor"])) ? $data_request["id_proveedor"] : null,
				'tipo_pago'						=> trim($data_request["tipo_pago"]),
				'dias_pago'						=> (isset($data_request["dias_pago"])) ? $data_request["dias_pago"] : null,
				'tipo_cambio'					=> (isset($data_request["tipo_cambio"])) ? $data_request["tipo_cambio"] : null,
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$data["id_usuario"] = ID_USUARIO;
				$data["id_empresa"] = ID_EMPRESA;
			}

			$this->Gasto_operativo_m->save($data);

			$id_gasto_operativo = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('operacion-gasto_operativo', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$gasto_operativo = $this->Gasto_operativo_m->select('concat(v.serie, "-", v.numero) as viaje')
			->select('tg.nombre as gasto')
			->join('viaje v', 'v.id = gasto_operativo.id_viaje')
			->join('tipo_gasto_operativo tg', 'tg.id = gasto_operativo.id_tipo_gasto_operativo')	
			->where('gasto_operativo.id', $data_request["id"])
			->first();

			$this->Gasto_operativo_m->where('id', $data_request["id"])->delete();     

			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'GASTOS OPERATIVOS',
				'accion'		=> 'ELIMINAR',
				'descripcion'	=> $gasto_operativo->gasto.', '.$gasto_operativo->viaje
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
