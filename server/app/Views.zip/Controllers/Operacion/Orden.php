<?php namespace App\Controllers\Operacion;

use App\Controllers\BaseController;

use App\Models\Operacion\Orden_model;
use App\Models\Operacion\Viaje_ayudante_model;
use App\Models\Operacion\Viaje_model;
use App\Models\Operacion\Viaje_guia_model;
use App\Models\Configuracion\Vehiculo_model;
use App\Models\Operacion\Viaje_orden_model;
use App\Models\Operacion\Viaje_concepto_tercerizado_model;
use App\Models\Operacion\Viaje_escolta_model;
use App\Models\Configuracion\Subcliente_model;
use App\Models\Configuracion\View_datatable_model;
use App\Models\Configuracion\Config_modulo_model;
use App\Models\Configuracion\Tarifa_model;

class Orden extends BaseController
{
	public function __construct()
	{
		$this->Orden_m = new Orden_model();

		$this->Viaje_m = new Viaje_model();
		$this->Viaje_guia_m = new Viaje_guia_model();
		$this->Vehiculo_m = new Vehiculo_model();
		$this->Viaje_ayudante_m = new Viaje_ayudante_model();
		$this->Viaje_orden_m = new Viaje_orden_model();
		$this->Viaje_concepto_tercerizado_m = new Viaje_concepto_tercerizado_model();
		$this->Subcliente_m = new Subcliente_model();
		$this->Config_modulo_m = new Config_modulo_model();
		$this->Tarifa_m = new Tarifa_model();
		$this->Viaje_escolta_m = new Viaje_escolta_model();
	}

	function get_configuracion()
	{
		$config_modulo = $this->Config_modulo_m->where('id_empresa', ID_EMPRESA)
		->first();

		$response = [
			'view_datatable'	=> $config_modulo->dt_operacion_orden_trabajo,
			'form'				=> $config_modulo->form_operacion_orden_trabajo
		];

		return $this->respond($response, 200);
	}

	public function get_select_tipo_carga()
	{

		$response = $this->Orden_m->distinct('tipo_carga')
		->select("tipo_carga as text")
		->where('id_empresa', ID_EMPRESA)
		->findAll();

		return $this->respond($response, 200);
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response =	$this->Orden_m->select("id, concat(serie, ' - ', numero) as text");

		$serie_numero = explode('-', $data_request["buscar"]);
		$fecha = explode('/', $data_request["buscar"]);

		if(count($serie_numero) == 2)
		{
			/** SERIE NUMERO */
			$response->where('serie', $serie_numero[0]);
			$response->like('numero', '%'.$serie_numero[1]);
		}

		if(count($fecha) == 3)
		{
			/** FECHA */
			if($fecha[2] == '')
			{          
				$fecha[2] = date("Y");          
			}
			
			$response->where('DATE_FORMAT(fecha, "%Y-%m-%d")', $fecha[2].'-'.$fecha[1].'-'.$fecha[0]);
		}
		
		$response = $response->where('id_empresa', ID_EMPRESA)
		->findAll();
		
		return $this->respond($response, 200);
	}

	public function get_correlativo($serie)
	{
		$secuencia = $this->Orden_m->get_correlativo($serie);

		return $this->respond($secuencia, 200);
	}

	public function get_sin_facturar()
	{		
		$response = $this->Orden_m->distinct('viaje_orden.id_orden')
		->select('orden.*, concat(orden.serie,"-",orden.numero) as orden, orden.id as id_orden')
		->select('coalesce(c.razon_social, "") as cliente, c.id_documento as cliente_id_documento, c.numero_documento as cliente_numero_documento ,c.direccion as cliente_direccion, c.id_ubigeo as cliente_ubigeo')
		->select('sc.razon_social as subcliente')
		->select('concat(r.punto_inicio," - ",r.punto_final) as ruta')
		->select('m.nombre as moneda, m.simbolo as moneda_simbolo')
		->select('coalesce(concat(v.serie,"-",v.numero), "") as viaje, v.estado_operacion, v.id as id_viaje')
		->join('cliente c', 'c.id = orden.id_cliente', 'left')
		->join('subcliente sc', 'sc.id = orden.id_subcliente', 'left')
		->join('ruta r', 'r.id = orden.id_ruta', 'left')
		->join('static_moneda m', 'm.id = orden.id_moneda')
		->join('viaje_orden', 'viaje_orden.id_orden = orden.id', 'left')
		->join('viaje v', 'v.id = viaje_orden.id_viaje', 'left')
		->where('orden.id_factura', null)
		->where('orden.fl_estado', 1)
		->where('orden.id_empresa', ID_EMPRESA)		
		->findAll();

		foreach ($response as $row) {

			if($row->id_viaje != null)
			{
				$guias = $this->Viaje_guia_m->where('(id_orden = '.$row->id_orden.' or id_viaje = '.$row->id_viaje.')')->where('fl_estado', 1)->findAll();
			}
			else
			{
				$guias = $this->Viaje_guia_m->where('id_orden', $row->id_orden)->where('fl_estado', 1)->findAll();
			}

			$guia_remitente = [];
			$guia_transportista = [];
			$guia_tercero = [];

			foreach ($guias as $guia) {
				
				switch ($guia->tipo) {
					case 'REMITENTE':
						$guia_remitente[] = $guia->serie.'-'.$guia->numero;
					break;
					
					case 'TRANSPORTISTA':
						$guia_transportista[] = $guia->serie.'-'.$guia->numero;
					break;

					case 'TERCERO':
						$guia_tercero[] = $guia->serie.'-'.$guia->numero;
					break;
				}
			}

			$row->guia_remitente = implode(', ', $guia_remitente);
			$row->guia_transportista = implode(', ', $guia_transportista);
			$row->guia_tercero = implode(', ', $guia_tercero);
		}

		

		return $this->respond($response, 200);
	}

	public function sin_viaje()
	{		
		$data_request = $this->request->getGet();
		
		$response = $this->Orden_m->select('orden.*, concat(serie,"-",numero) as orden')
		->select('c.razon_social as cliente')
		->select('concat(r.punto_inicio," - ",r.punto_final) as ruta')
		->select('m.nombre as moneda')
		->select('t.tipo_medida')
		->join('cliente c', 'c.id = orden.id_cliente', 'left')
		->join('ruta r', 'r.id = orden.id_ruta', 'left')
		->join('tarifa t', 't.id = orden.id_tarifa', 'left')
		->join('static_moneda m', 'm.id = orden.id_moneda', 'left')
		->where('orden.id not in  (SELECT id_orden FROM viaje_orden where id_orden = orden.id)')
		->where('orden.fl_estado', 1)
		->where('orden.id_empresa', ID_EMPRESA)		
		->findAll();

		foreach ($response as $row) {
			$guias = $this->Viaje_guia_m->where('id_orden', $row->id)
			->where('fl_estado', 1)
			->findAll();

			$array_guia = [];

			foreach ($guias as $guia) {
				$array_guia[] = $guia->serie.'-'.$guia->numero;
			}

			$row->guia_remitente = implode(', ', $array_guia);
		}

		return $this->respond(['data' => $response], 200);
	}

	public function get_multiple()
	{
		$data_request = $this->request->getPost();

		$response = [];

		foreach (json_decode($data_request["detalle"]) as $row) {
			$response[] = $this->get_unique($row->id_orden, true);
		}

		return $this->respond($response, 200);
	}

	public function get_unique($id_orden, $return = false)
	{		
		$response = $this->Orden_m->distinct('viaje_orden.id_orden')
		->select('orden.*, concat(orden.serie,"-",orden.numero) as orden, orden.id as id_orden')
		->select('c.razon_social as cliente, c.id_documento as cliente_id_documento, c.numero_documento as cliente_numero_documento ,c.direccion as cliente_direccion, c.id_ubigeo as cliente_ubigeo')
		->select('sc.razon_social as subcliente')
		->select('concat(r.punto_inicio," - ",r.punto_final) as ruta')
		->select('m.nombre as moneda')
		->select('coalesce(concat(v.serie,"-",v.numero), "") as viaje, v.estado_operacion, v.id as id_viaje')
		->join('cliente c', 'c.id = orden.id_cliente', 'left')
		->join('subcliente sc', 'sc.id = orden.id_subcliente', 'left')
		->join('ruta r', 'r.id = orden.id_ruta', 'left')
		->join('static_moneda m', 'm.id = orden.id_moneda')
		->join('viaje_orden', 'viaje_orden.id_orden = orden.id', 'left')
		->join('viaje v', 'v.id = viaje_orden.id_viaje', 'left')
		->where('orden.id', $id_orden)	
		->where('orden.id_empresa', ID_EMPRESA)		
		->first();

		if($response->id_viaje != null)
		{
			$guias = $this->Viaje_guia_m->where('(id_orden = '.$response->id_orden.' or id_viaje = '.$response->id_viaje.')')->where('fl_estado', 1)->findAll();
		}
		else
		{
			$guias = $this->Viaje_guia_m->where('id_orden', $response->id_orden)->where('fl_estado', 1)->findAll();
		}

		$guia_remitente = [];
		$guia_transportista = [];
		$guia_tercero = [];

		foreach ($guias as $guia) {
			
			switch ($guia->tipo) {
				case 'REMITENTE':
					$guia_remitente[] = $guia->serie.'-'.$guia->numero;
				break;
				
				case 'TRANSPORTISTA':
					$guia_transportista[] = $guia->serie.'-'.$guia->numero;
				break;

				case 'TERCERO':
					$guia_tercero[] = $guia->serie.'-'.$guia->numero;
				break;
			}
		}

		$response->guia_remitente = implode(', ', $guia_remitente);
		$response->guia_transportista = implode(', ', $guia_transportista);
		$response->guia_tercero = implode(', ', $guia_tercero);

		if($return == true)
		{
			return $response;
		}

		return $this->respond($response, 200);
	}

	public function index()
	{		 
		$data_request = $this->request->getGet();

		$response = $this->Orden_m->distinct('viaje_orden.id_orden')
		->select('orden.*, concat(orden.serie,"-",orden.numero) as orden, orden.id as id_orden')
		->select('c.razon_social as cliente')
		->select('sc.razon_social as subcliente, sc.distrito as subcliente_distrito, sc.segmento as subcliente_segmento, sc.vendedor as subcliente_vendedor, sc.atencion_tipo as subcliente_atencion_tipo, sc.atencion_horario as subcliente_atencion_horario, sc.tienda as subcliente_tienda')
		->select('concat(r.punto_inicio," - ",r.punto_final) as ruta')
		->select('m.nombre as moneda, m.simbolo as moneda_simbolo')
		->select('coalesce(concat(v.serie,"-",v.numero), "") as viaje, v.estado_operacion, v.id as id_viaje')
		->select('coalesce(concat(f.serie,"-",f.numero), "") as factura')
		->select('coalesce(vh.placa, "") as vehiculo')
		->select('coalesce(l.descripcion, "") as local')
		
		->join('cliente c', 'c.id = orden.id_cliente', 'left')
		->join('subcliente sc', 'sc.id = orden.id_subcliente', 'left')
		->join('ruta r', 'r.id = orden.id_ruta', 'left')
		->join('static_moneda m', 'm.id = orden.id_moneda')
		->join('viaje_orden', 'viaje_orden.id_orden = orden.id', 'left')
		->join('viaje v', 'v.id = viaje_orden.id_viaje', 'left')
		->join('vehiculo vh', 'vh.id = v.id_vehiculo', 'left')
		->join('factura f', 'f.id = orden.id_factura', 'left')
		->join('local l', 'l.id = orden.id_local', 'left')

		->where('DATE_FORMAT(orden.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(orden.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])
		->where('orden.id_empresa', ID_EMPRESA)		
		->findAll();

		foreach ($response as $row) {

			$row->guias_remitente = $this->Viaje_guia_m->where('id_orden', $row->id)->findAll();

			if($row->id_viaje != null)
			{
				$guias = $this->Viaje_guia_m->where('(id_orden = '.$row->id_orden.' or id_viaje = '.$row->id_viaje.')')->where('fl_estado', 1)->findAll();
			}
			else
			{
				$guias = $this->Viaje_guia_m->where('id_orden', $row->id_orden)->where('fl_estado', 1)->findAll();
			}

			$guia_remitente = [];
			$guia_transportista = [];
			$guia_tercero = [];

			foreach ($guias as $guia) {
				
				switch ($guia->tipo) {
					case 'REMITENTE':
						$guia_remitente[] = $guia->serie.'-'.$guia->numero;
					break;
					
					case 'TRANSPORTISTA':
						$guia_transportista[] = $guia->serie.'-'.$guia->numero;
					break;

					case 'TERCERO':
						$guia_tercero[] = $guia->serie.'-'.$guia->numero;
					break;
				}
			}
 
			$row->guia_remitente = implode(', ', $guia_remitente);
			$row->guia_transportista = implode(', ', $guia_transportista);
			$row->guia_tercero = implode(', ', $guia_tercero);
		}

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('operacion-orden', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('operacion-orden', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->query('SET AUTOCOMMIT = 0');
			$db->transStart();
			$db->query('LOCK TABLES orden write,  viaje write, viaje_guia write, viaje_ayudante write, viaje_orden write, centinela write, viaje_concepto_tercerizado write, ajuste_avanzado read, tarifa write, viaje_escolta write');

			/****** GUARDAR TARIFA A CLIENTE */

			$tarifa = $this->Tarifa_m->find($data_request["id_tarifa"]);

			$id_tarifa = trim($data_request["id_tarifa"]);

			if($tarifa->id_cliente != $data_request["id_cliente"])
			{
				$data_tarifa = [
					'id_ruta'              	=> $tarifa->id_ruta,
					'tipo_servicio'        	=> $tarifa->tipo_servicio,
					'tipo_medida'          	=> $tarifa->tipo_medida,
					'costo_medida'         	=> $tarifa->costo_medida,
					'id_vehiculo_modelo'	=> $tarifa->id_vehiculo_modelo,
					'id_cliente'			=> $data_request["id_cliente"]
				];

				$this->Tarifa_m->save($data_tarifa);

				$id_tarifa = $db->insertID();
			}


			/** GUARDAR */
			$data = [
				'fecha' 					=> trim($data_request["fecha"]),
				'id_moneda'					=> trim($data_request["id_moneda"]),
				'id_cliente'				=> trim($data_request["id_cliente"]),
				'id_subcliente'				=> (isset($data_request["id_subcliente"]) && $data_request["id_subcliente"] != '') ? trim($data_request["id_subcliente"]) : null,
				'id_cliente_contacto'		=> (isset($data_request["id_cliente_contacto"]) && $data_request["id_cliente_contacto"] != '') ? trim($data_request["id_cliente_contacto"]) : null,
				'id_ruta'					=> trim($data_request["id_ruta"]),
				'id_tarifa'					=> $id_tarifa,
				'orden_servicio'			=> trim($data_request["orden_servicio"]),
				'costo_medida'				=> trim($data_request["costo_medida"]),
				'cantidad_medida'			=> trim($data_request["cantidad_medida"]),
				'total_orden'				=> trim($data_request["total_orden"]),
				'numero_contenedor'			=> (isset($data_request["numero_contenedor"])) ? trim($data_request["numero_contenedor"]) : null,
				'direccion_llegada'			=> trim($data_request["direccion_llegada"]),
				'referencia_carga_cliente'	=> trim($data_request["referencia_carga_cliente"]),
				'producto'					=> trim($data_request["producto"]),
				'tipo_cambio'				=> (isset($data_request["tipo_cambio"])) ? $data_request["tipo_cambio"] : null
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$correlativo = $this->Orden_m->get_correlativo(trim($data_request["serie"]));

				$data["serie"] = $correlativo->serie;
				$data["numero"] = $correlativo->numero;

				$data["total_detraccion"] = 0;
				$data["fl_liquidacion"] = 0;
				$data["fl_estado"] = 1;				
				$data["fecha_sistema"] = date("Y-m-d H:i:s");
				$data["id_empresa"] = ID_EMPRESA;
				$data["id_usuario"] = ID_USUARIO;
				$data["id_local"] = ID_LOCAL;
			}

			$this->Orden_m->save($data);

			$id_orden = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			/*** SAVE GUIAS */
			/** REMITENTE */
			$this->Viaje_guia_m->where('id_orden', $id_orden)->delete();

			$data_detalle_guia = [];

			foreach (json_decode($data_request["detalle_guia_remitente"]) as $row) {
				$data_detalle_guia[] = [
					'id_orden'			=> $id_orden,
					'tipo'				=> 'REMITENTE',
					'serie'				=> strtoupper($row->serie),
					'numero'			=> $row->numero,
					'punto_origen'		=> $row->punto_origen,
					'punto_destino'		=> $row->punto_destino,
					'fl_estado'			=> 1
				];
			}

			if(count($data_detalle_guia) > 0)
			{
				$this->Viaje_guia_m->insertbatch($data_detalle_guia);
			}


			/****************** SAVE CENTINELA *****************/
			$orden = $this->Orden_m->find($id_orden);

			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'ÓRDENES DE TRABAJO',
				'accion'		=> (isset($data_request["id"])) ? 'EDITAR' : 'NUEVO',
				'descripcion'	=> $orden->serie.'-'.$orden->numero
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */

			/*** SAVE VIAJE */
			if(isset($data_request["fl_viaje"]) && !isset($data_request["id"]))
			{
				$data = [
					'fecha'								=> trim($data_request["fecha_viaje"]),
					'id_vehiculo'						=> trim($data_request["id_vehiculo"]),
					'id_remolque'						=> (isset($data_request["id_remolque"]) && $data_request["id_remolque"] != '') ? trim($data_request["id_remolque"]) : null,
					'id_conductor'						=> trim($data_request["id_conductor"]),
					'id_ruta'							=> trim($data_request["id_ruta"]),
					'modalidad'							=> trim($data_request["modalidad"]),
					'tipo_carga'						=> trim($data_request["tipo_carga"]),
					'cantidad'							=> trim($data_request["cantidad"]),
					'numero_contenedor'					=> isset($data_request["numero_contenedor"]) ? trim($data_request["numero_contenedor"]) : null,
					'id_moneda_tercerizado'				=> (isset($data_request["id_moneda"])) ? trim($data_request["id_moneda"]) : null,
					'tipo_cambio_tercerizado'			=> (isset($data_request["tipo_cambio"])) ? $data_request["tipo_cambio"] : null,
					'costo_flete_tercerizado'			=> isset($data_request["costo_flete_tercerizado"]) ? trim($data_request["costo_flete_tercerizado"]) : 0,
					'costo_tercerizado'					=> isset($data_request["costo_tercerizado"]) ? trim($data_request["costo_tercerizado"]) : 0,
					'monto_gasto_operativo'				=> trim($data_request["monto_gasto_operativo"]),
					'descripcion_gasto_operativo'		=> trim($data_request["descripcion_gasto_operativo"]),
					'monto_adelanto_tercerizado'		=> (isset($data_request["monto_adelanto_tercerizado"]) && $data_request["monto_adelanto_tercerizado"] != '') ? trim($data_request["monto_adelanto_tercerizado"]) : 0,
					'porc_detraccion_tercerizado'		=> isset($data_request["porc_detraccion_tercerizado"]) ? trim($data_request["porc_detraccion_tercerizado"]) : 0,
					'mas_inc_igv_tercerizado'			=> isset($data_request["mas_inc_igv_tercerizado"]) ? trim($data_request["mas_inc_igv_tercerizado"]) : null,

					'id_proveedor_escolta'				=> (is_numeric($data_request["id_proveedor_escolta"])) ? trim($data_request["id_proveedor_escolta"]) : null,
					'id_moneda_escolta'					=> isset($data_request["id_moneda_escolta"]) ? trim($data_request["id_moneda_escolta"]) : null,
					'tipo_cambio_escolta'				=> isset($data_request["tipo_cambio_escolta"]) ? trim($data_request["tipo_cambio_escolta"]) : null,
					'costo_escolta'						=> isset($data_request["costo_escolta"]) ? trim($data_request["costo_escolta"]) : null,
					'monto_adelanto_escolta'			=> (isset($data_request["monto_adelanto_escolta"]) && $data_request["monto_adelanto_escolta"] != '') ? trim($data_request["monto_adelanto_escolta"]) : 0,
					'porc_detraccion_escolta'			=> isset($data_request["porc_detraccion_escolta"]) ? trim($data_request["porc_detraccion_escolta"]) : 0,
					'mas_inc_igv_escolta'				=> isset($data_request["mas_inc_igv_escolta"]) ? trim($data_request["mas_inc_igv_escolta"]) : null,
				];

				$ajuste = $this->Ajuste_avanzado_m->find(ID_EMPRESA);

				$serie_viaje = ($ajuste->operacion_serie_viaje != null && $ajuste->operacion_serie_viaje != '') ? $ajuste->operacion_serie_viaje : date("Y");
				$correlativo = $this->Viaje_m->get_correlativo($serie_viaje);

				$data["serie"] = $correlativo->serie;
				$data["numero"] = $correlativo->numero;

				$data["fl_estado"] = 1;	
				$data["estado_operacion"] = 'REGISTRADO';				
				$data["fecha_sistema"] = date("Y-m-d H:i:s");
				$data["id_empresa"] = ID_EMPRESA;
				$data["id_usuario"] = ID_USUARIO;
	
				$this->Viaje_m->save($data);
	
				$id_viaje = $db->insertID();
	
				/*** SAVE GUIAS */	
				/** TRANSPORTISTA */
	
				$data_detalle_guia = [];
	
				foreach (json_decode($data_request["detalle_guia_transportista"]) as $row) {
					$data_detalle_guia[] = [
						'id_viaje'			=> $id_viaje,
						'tipo'				=> 'TRANSPORTISTA',
						'serie'				=> strtoupper($row->serie),
						'numero'			=> $row->numero,
						'punto_origen'		=> $row->punto_origen,
						'punto_destino'		=> $row->punto_destino,
						'fl_estado'			=> 1
					];
				}
	
				if(count($data_detalle_guia) > 0)
				{
					$this->Viaje_guia_m->insertbatch($data_detalle_guia);
				}
	
				/** TERCERO */
				$data_detalle_guia = [];
	
				foreach (json_decode($data_request["detalle_guia_tercero"]) as $row) {
					$data_detalle_guia[] = [
						'id_viaje'			=> $id_viaje,
						'tipo'				=> 'TERCERO',
						'serie'				=> strtoupper($row->serie),
						'numero'			=> $row->numero,
						'punto_origen'		=> $row->punto_origen,
						'punto_destino'		=> $row->punto_destino,
						'fl_estado'			=> 1
					];
				}
	
				if(count($data_detalle_guia) > 0)
				{
					$this->Viaje_guia_m->insertbatch($data_detalle_guia);
				}

				/** AYUDANTE */
				$data_detalle_ayudante = [];
				$this->Viaje_ayudante_m->where('id_viaje', $id_viaje)->delete();

				foreach (json_decode($data_request["detalle_ayudante"]) as $row) {
					$data_detalle_ayudante[] = [
						'id_viaje'			=> $id_viaje,
						'tipo'				=> $row->tipo,
						'nombre'			=> $row->nombre,
					];
				}

				if(count($data_detalle_ayudante) > 0)
				{
					$this->Viaje_ayudante_m->insertbatch($data_detalle_ayudante);
				}

				/** CONCEPTOS TERCERIZADOS */
				$data_detalle_concepto_tercerizado = [];
				$this->Viaje_concepto_tercerizado_m->where('id_viaje', $id_viaje)->delete();

				foreach (json_decode($data_request["detalle_concepto_tercerizado"]) as $row) {
					$data_detalle_concepto_tercerizado[] = [
						'id_viaje'			=> $id_viaje,
						'concepto'			=> $row->concepto,
						'monto'				=> $row->monto,
					];
				}

				if(count($data_detalle_concepto_tercerizado) > 0)
				{
					$this->Viaje_concepto_tercerizado_m->insertbatch($data_detalle_concepto_tercerizado);
				}
				
	 
				/*** VIAJE ORDEN */

				$data_viaje_orden = [
					'id_viaje'						=> $id_viaje,
					'id_orden'						=> $id_orden,
					'id_vehiculo_compartimiento'	=> (isset($data_request["id_vehiculo_compartimiento"])) ? $data_request["id_vehiculo_compartimiento"] : null,
				];

				$this->Viaje_orden_m->save($data_viaje_orden);


				/*** VIAJE ESCOLTA	 */
				$data_detalle = [];
				$this->Viaje_escolta_m->where('id_viaje', $id_viaje)->delete();

				foreach (json_decode($data_request["detalle_escolta"]) as $row) {

					$data_detalle[] = [
						'id_viaje'						=> $id_viaje,
						'vehiculo'						=> $row->vehiculo,
						'descripcion'					=> $row->descripcion,
					];				
				}

				if(count($data_detalle) > 0)
				{
					$this->Viaje_escolta_m->insertbatch($data_detalle);
				}


				/****************** SAVE CENTINELA *****************/
				$viaje = $this->Viaje_m->find($id_viaje);

				$data_centinela = [
					'modulo'		=> 'OPERACIONES',
					'menu'			=> 'ÓRDENES DE VIAJE',
					'accion'		=> 'NUEVO',
					'descripcion'	=> $viaje->serie.'-'.$viaje->numero
				];

				$this->Centinela_m->registrar($data_centinela);
				/*************************************************** */
				
			}
			
			$db->query('UNLOCK TABLES');
        	$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('operacion-orden', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$data = [
				'id'		=> $data_request["id"],
				'fl_estado'	=> 0
			];

			$this->Orden_m->save($data);

			/****************** SAVE CENTINELA *****************/
			$orden = $this->Orden_m->find($data_request["id"]);

			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'ÓRDENES DE TRABAJO',
				'accion'		=> 'ANULADO',
				'descripcion'	=> $orden->serie.'-'.$orden->numero
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}

	public function save_importacion()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('configuracion-vehiculo', 'new');

		$respuesta = explode(".", $_FILES["archivo"]['name']);
		$extension = $respuesta[(count($respuesta))-1];
	
		if($extension == 'xlsx')
		{
			require_once APPPATH."Libraries/phpexcel/PHPExcel.php";

			$tmpfname = $_FILES["archivo"]['tmp_name'];
			$excelReader = \PHPExcel_IOFactory::createReaderForFile($tmpfname);
			$excelObj = $excelReader->load($tmpfname);
			$hoja = $excelObj->getSheet(0);

			$ultima_fila = $hoja->getHighestRow();
			$total_registros = 0;
			$detalle = Array();

			try {
				
				$db = \Config\Database::connect();
				$db->query('SET AUTOCOMMIT = 0');
				$db->transStart();
				$db->query('LOCK TABLES orden write,  viaje write, viaje_guia write, viaje_ayudante write, viaje_orden write, vehiculo read, subcliente write');

				$array_batch = [];					

				for ($fila = 7; $fila <= $ultima_fila; $fila++) {

					$placa = $hoja->getCell('C'.$fila)->getValue();

					if($placa != '')
					{
						/**** IDENTIFICAR SI LLEVA NUMERAL QUE IDENTIFICA RECARGA NO ALTERAR LA PLACA DE VALIDACION */
						$placa_ultimo_char = substr($placa, -1);

						if($placa_ultimo_char == '#')
						{
							$placa = substr($placa, 0, -1);
						}

						/*** IDENTIFICAR VEHICULO */	
						$vehiculo = $this->Vehiculo_m->where('placa', $placa)->where('id_empresa', ID_EMPRESA)->first();
						if(!is_object($vehiculo))
						{
							return $this->respond(['tipo' => 'warning', 'mensaje' => 'El vehículo de placa: '.$placa.' no existe en la base de datos'], 400);
							exit;
						}

						/*** IDENTIFICAR SUBCLIENTECLIENTE O GUARDAR NUEVO */	
						$codigo_subcliente = $hoja->getCell('E'.$fila)->getValue();
						$subcliente = $this->Subcliente_m->where('codigo', $codigo_subcliente)
						->where('id_cliente', $data_request["id_cliente"])
						->first();

						if(!is_object($subcliente))
						{
							$data_subcliente = [
								'id_cliente'		=> $data_request["id_cliente"],
								'codigo'			=> $codigo_subcliente,
								'razon_social'		=> $hoja->getCell('F'.$fila)->getValue(),
								'distrito'			=> $hoja->getCell('G'.$fila)->getValue(),
								'direccion'			=> $hoja->getCell('H'.$fila)->getValue(),
								'imagen'			=> 'sin_imagen.jpg',	
								'mapa_latitud'		=> $hoja->getCell('K'.$fila)->getValue(),
								'mapa_longitud'		=> $hoja->getCell('L'.$fila)->getValue(),
								'segmento'			=> $hoja->getCell('M'.$fila)->getValue(),
								'vendedor'			=> $hoja->getCell('N'.$fila)->getValue(),
								'atencion_tipo'		=> $hoja->getCell('R'.$fila)->getValue(),
								'atencion_horario'	=> $hoja->getCell('S'.$fila)->getValue(),
								'tienda'			=> $hoja->getCell('W'.$fila)->getValue(),
							];

							$this->Subcliente_m->save($data_subcliente);

							$id_subcliente = $db->insertID();
						}
						else
						{
							$id_subcliente = $subcliente->id;
						}

						$data_save = (object) [
							'fecha'				=>	trim($data_request["fecha"]),
							'id_moneda'			=> 	1, /*** SIEMPRE MONEDA NATAL */
							'id_vehiculo'		=> 	$vehiculo->id,
							'id_cliente'		=> 	$data_request["id_cliente"],
							'id_subcliente'		=> 	$id_subcliente,
							'direccion_llegada'	=> 	$hoja->getCell('G'.$fila)->getValue(),
							'cantidad_medida'	=> 	$hoja->getCell('Q'.$fila)->getValue(),
							'costo_medida'		=> 	($vehiculo->tipo_flete == 'FLETE FIJO') ?  $vehiculo->costo_flete : 0,
							'tipo_carga'		=> 	'PAQUETES',
							'tipo_movimiento'	=> 	$hoja->getCell('I'.$fila)->getValue(),
						];

						$array_batch[] = $data_save;
					}	
					else
					{
						break;
					}					

				}


				if(count($array_batch) > 0)
				{										
					$fecha_sistema = date("Y-m-d H:i:s");

					foreach ($array_batch as $row) {						

						$correlativo = $this->Orden_m->get_correlativo(date("Y"));
						
						/** GUARDAR ORDEN*/
						$data = [
							'serie'				=> $correlativo->serie,
							'numero'			=> $correlativo->numero,
							'fl_liquidacion'	=> 0,
							'fl_estado'			=> 1,			
							'fecha_sistema'		=> $fecha_sistema,
							'id_empresa'		=> ID_EMPRESA,

							'fecha' 			=> $row->fecha,
							'id_moneda'			=> $row->id_moneda,
							'id_cliente'		=> $row->id_cliente,
							'id_subcliente'		=> $row->id_subcliente,
							'id_ruta'			=> null,
							'id_tarifa'			=> null,
							'orden_servicio'	=> '',
							'cantidad_medida'	=> $row->cantidad_medida,
							'costo_medida'		=> $row->costo_medida,							
							'total_orden'		=> $row->costo_medida,
							'numero_contenedor'	=> null,
							'direccion_llegada'	=> $row->direccion_llegada,
							'producto'			=> ''
						];

						$this->Orden_m->save($data);

						$id_orden = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

						/*** SAVE VIAJE */

						$correlativo = $this->Viaje_m->get_correlativo(date("Y"));

						$data = [
							'serie'								=> 	$correlativo->serie,
							'numero'							=>	$correlativo->numero,
							'fl_estado'							=> 	1,
							'estado_operacion'					=> 	'REGISTRADO',
							'fecha_sistema'						=> 	$fecha_sistema,
							'id_empresa'						=> 	ID_EMPRESA,

							'fecha'								=> 	$row->fecha,
							'id_vehiculo'						=> 	$row->id_vehiculo,
							'modalidad'							=> 	'SOLO IDA',
							'tipo_carga'						=> 	$row->tipo_carga,
							'cantidad'							=> 	$row->cantidad_medida
						];
			
						$this->Viaje_m->save($data);
			
						$id_viaje = $db->insertID();
						
			
						/*** VIAJE ORDEN */

						$data_viaje_orden = [
							'id_viaje'						=> $id_viaje,
							'id_orden'						=> $id_orden
						];

						$this->Viaje_orden_m->save($data_viaje_orden);						
						
					}


					$db->query('UNLOCK TABLES');
					$db->transComplete();

					return $this->respond(['tipo' => 'success', 'mensaje' => 'Excelente!'], 200);
				}
				else
				{
					return $this->respond(['tipo' => 'warning', 'mensaje' => 'No hay datos para guardar'], 400);
				}					

			} catch (\Exception $e) {
				return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
			}
			
		}
		else
		{
			return $this->respond(['tipo' => 'danger', 'mensaje' => 'Archivo con formato incorrecto'], 400);
		}
	}

	public function save_configuracion()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('configuracion-ajuste_avanzado', 'edit');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			/** GUARDAR */

			/**** CAMPOS FORM */
			$data = [
				'form_operacion_orden_trabajo'    	=> trim($data_request["config_modulo"]),
				'dt_operacion_orden_trabajo'    	=> trim($data_request["view_datatable"]),
				'id_empresa'						=> ID_EMPRESA
			];

			$this->Config_modulo_m->save($data);

			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'ORDEN DE TRABAJO',
				'accion'		=> 'CONFIGURAR',
				'descripcion'	=> 'Configuración'
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
