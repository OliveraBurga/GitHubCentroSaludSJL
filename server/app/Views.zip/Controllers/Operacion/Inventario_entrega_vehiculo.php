<?php namespace App\Controllers\Operacion;

use App\Controllers\BaseController;

use App\Models\Operacion\Inventario_entrega_vehiculo_model;
use App\Models\Operacion\Inventario_entrega_vehiculo_detalle_model;
use App\Models\Configuracion\Empresa_model;

class Inventario_entrega_vehiculo extends BaseController
{
	public function __construct()
	{
		$this->Inventario_entrega_vehiculo_m = new Inventario_entrega_vehiculo_model();
		$this->Inventario_entrega_vehiculo_detalle_m = new Inventario_entrega_vehiculo_detalle_model();
		$this->Empresa_m = new Empresa_model();
	}

	public function print($id)
	{
		$response = $this->Inventario_entrega_vehiculo_m->select('inventario_entrega_vehiculo.*')
		->select('v.placa as vehiculo')
		->select('coalesce(vr.placa, "") as remolque')
		->select('cond.nombre_completo as conductor, cond.numero_licencia')
		->join('vehiculo v', 'v.id = inventario_entrega_vehiculo.id_vehiculo', 'left')
		->join('vehiculo vr', 'vr.id = inventario_entrega_vehiculo.id_remolque', 'left')
		->join('personal cond', 'cond.id = inventario_entrega_vehiculo.id_conductor', 'left')
		->where('inventario_entrega_vehiculo.id', $id)
		->where('inventario_entrega_vehiculo.id_empresa', ID_EMPRESA)		
		->first();

		$response->detalle =  $this->Inventario_entrega_vehiculo_detalle_m->where('id_inventario_entrega_vehiculo', $id)->findAll();
		$response->empresa =  $this->Empresa_m->find(ID_EMPRESA);

		return $this->respond($response, 200);
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response = $this->Inventario_entrega_vehiculo_m->select("id, concat(serie, ' - ', numero) as text");

		$response = $response
		->where('id_empresa', ID_EMPRESA)
		->findAll();
		
		return $this->respond($response, 200);
	}

	public function index()
	{		
		$data_request = $this->request->getGet();

		$response = $this->Inventario_entrega_vehiculo_m->select('inventario_entrega_vehiculo.*')
		->select('v.placa as vehiculo')
		->select('vr.placa as remolque')
		->select('cond.nombre_completo as conductor')
		->join('vehiculo v', 'v.id = inventario_entrega_vehiculo.id_vehiculo', 'left')
		->join('vehiculo vr', 'vr.id = inventario_entrega_vehiculo.id_remolque', 'left')
		->join('personal cond', 'cond.id = inventario_entrega_vehiculo.id_conductor', 'left')
		->where('DATE_FORMAT(inventario_entrega_vehiculo.fecha, "%Y-%m-%d") >=', $data_request["fecha_inicio"])
        ->where('DATE_FORMAT(inventario_entrega_vehiculo.fecha, "%Y-%m-%d") <=', $data_request["fecha_fin"])
		->where('inventario_entrega_vehiculo.id_empresa', ID_EMPRESA)		
		->findAll();

		foreach ($response as $row) {
			$row->detalle =  $this->Inventario_entrega_vehiculo_detalle_m->where('id_inventario_entrega_vehiculo', $row->id)->findAll();
		}

		return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('operacion-inventario_entrega_vehiculo', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('operacion-inventario_entrega_vehiculo', 'new');
		} 

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			/** GUARDAR */
			$data = [
				'id_vehiculo'         	=> trim($data_request["id_vehiculo"]),
				'fecha'               	=> trim($data_request["fecha"]),
				'id_vehiculo'  			=> trim($data_request["id_vehiculo"]),
				'id_remolque'			=> ($data_request["id_remolque"] != '') ? trim($data_request["id_remolque"]) : null,
				'id_conductor'  		=> trim($data_request["id_conductor"]),
				'descripcion'         	=> trim($data_request["descripcion"]),
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$correlativo = $this->Inventario_entrega_vehiculo_m->get_correlativo(date("Y"));

				$data["serie"] = $correlativo->serie;
				$data["numero"] = $correlativo->numero;
				$data["fl_estado"] = 1;

				$data["fecha_sistema"] = date("Y-m-d H:i:s");
				$data["id_empresa"] = ID_EMPRESA;
			}

			$this->Inventario_entrega_vehiculo_m->save($data);

			$id_inventario_entrega_vehiculo = (isset($data_request["id"])) ? $data_request["id"] : $db->insertID();

			/*** SAVE DETALLE */
			$this->Inventario_entrega_vehiculo_detalle_m->where('id_inventario_entrega_vehiculo', $id_inventario_entrega_vehiculo)->delete();

			$data_detalle = [];

			foreach (json_decode($data_request["detalle"]) as $row) {
				$data_detalle[] = [
					'id_inventario_entrega_vehiculo'			=> $id_inventario_entrega_vehiculo,
					'descripcion'								=> $row->descripcion,
					'estado'									=> $row->estado,
					'cantidad'									=> $row->cantidad,
					'valor'										=> $row->valor,
					'observacion'								=> $row->observacion
				];
			}

			if(count($data_detalle) > 0)
			{
				$this->Inventario_entrega_vehiculo_detalle_m->insertbatch($data_detalle);
			}


			/****************** SAVE CENTINELA *****************/
			$inventario = $this->Inventario_entrega_vehiculo_m->select('inventario_entrega_vehiculo.*, v.placa')
			->join('vehiculo v', 'v.id = inventario_entrega_vehiculo.id_vehiculo')
			->where('inventario_entrega_vehiculo.id', $id_inventario_entrega_vehiculo)
			->first();

			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'INVENTARIO DE ENTREGA DE VEHÍCULO',
				'accion'		=> (isset($data_request["id"])) ? 'EDITAR' : 'NUEVO',
				'descripcion'	=> $inventario->serie.'-'.$inventario->numero.', Vehículo: '.$inventario->placa
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente', 'id'	=> $id_inventario_entrega_vehiculo], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('operacion-inventario_entrega_vehiculo', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$data = [
				'id'		=> $data_request["id"],
				'fl_estado'	=> 0
			];

			$this->Inventario_entrega_vehiculo_m->save($data); 

			/****************** SAVE CENTINELA *****************/
			$inventario = $this->Inventario_entrega_vehiculo_m->select('inventario_entrega_vehiculo.*, v.placa')
			->join('vehiculo v', 'v.id = inventario_entrega_vehiculo.id_vehiculo')
			->where('inventario_entrega_vehiculo.id', $data_request["id"])
			->first();

			$data_centinela = [
				'modulo'		=> 'OPERACIONES',
				'menu'			=> 'INVENTARIO DE ENTREGA DE VEHÍCULO',
				'accion'		=> 'ANULAR',
				'descripcion'	=> $inventario->serie.'-'.$inventario->numero.', Vehículo: '.$inventario->placa
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
