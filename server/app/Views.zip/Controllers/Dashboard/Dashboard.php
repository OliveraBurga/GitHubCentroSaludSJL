<?php namespace App\Controllers\Dashboard;

use App\Controllers\BaseController;

use App\Models\Operacion\Orden_model;
use App\Models\Operacion\Viaje_model;
use App\Models\Configuracion\Cliente_model;
use App\Models\Configuracion\Proveedor_model;
use App\Models\Configuracion\Vehiculo_model;
use App\Models\Documento\Documento_vehiculo_model;
use App\Models\Documento\Documento_personal_model;

class Dashboard extends BaseController
{
	public function __construct()
	{
		$this->Orden_m = new Orden_model();
        $this->Viaje_m = new Viaje_model();
        $this->Cliente_m = new Cliente_model();
        $this->Proveedor_m = new Proveedor_model();
        $this->Vehiculo_m = new Vehiculo_model();
	}

    public function get_cantidades()
	{		
        $response = [
            'cantidad_ordenes'  => $this->Orden_m->where('id_empresa', ID_EMPRESA)->countAllResults(),
            'cantidad_viajes'  => $this->Viaje_m->where('id_empresa', ID_EMPRESA)->countAllResults(),
            'cantidad_clientes'  => $this->Cliente_m->where('id_empresa', ID_EMPRESA)->countAllResults(),
            'cantidad_proveedores'  => $this->Proveedor_m->where('id_empresa', ID_EMPRESA)->countAllResults(),
            'cantidad_vehiculos'  => $this->Vehiculo_m->where('id_empresa', ID_EMPRESA)->countAllResults(),
			'cantidad_viaje_realizado'  => $this->Viaje_m->where('estado_operacion','FINALIZADO')->where('id_empresa', ID_EMPRESA)->countAllResults(),
        ];

		return $this->respond($response, 200);
	}

	public function get_ultimas_ordenes()
	{		
		$response = $this->Orden_m->select('orden.*, concat(orden.serie,"-",orden.numero) as orden')
		->select('c.razon_social as cliente, c.id_documento as cliente_id_documento, c.numero_documento as cliente_numero_documento ,c.direccion as cliente_direccion, c.id_ubigeo as cliente_ubigeo')
		->select('sc.razon_social as subcliente')
		->select('concat(r.punto_inicio," - ",r.punto_final) as ruta')
		->join('cliente c', 'c.id = orden.id_cliente', 'left')
		->join('subcliente sc', 'sc.id = orden.id_subcliente', 'left')
		->join('ruta r', 'r.id = orden.id_ruta', 'left')
		->limit(5)	
		->orderBy('orden.id', 'desc')	
		->where('orden.id_empresa', ID_EMPRESA)		
		->get()->getResult();

		return $this->respond($response, 200);
	}

    public function get_ultimos_viajes()
	{		
		$response = $this->Viaje_m->select('viaje.*, concat(serie,"-",numero) as viaje')
		->select('cond.nombre_completo as conductor')
		->select('concat(r.punto_inicio," - ",r.punto_final) as ruta')
		->select('v.placa as vehiculo')
		->select('vr.placa as remolque')
		->select('coalesce(p.razon_social, "") as proveedor')
		->join('personal cond', 'cond.id = viaje.id_conductor', 'left')
		->join('ruta r', 'r.id = viaje.id_ruta', 'left')
		->join('vehiculo v', 'v.id = viaje.id_vehiculo', 'left')
		->join('vehiculo vr', 'vr.id = viaje.id_remolque', 'left')
		->join('proveedor p', 'p.id = v.id_proveedor', 'left')

		->limit(5)	
		->orderBy('viaje.id', 'desc')	
		->where('viaje.id_empresa', ID_EMPRESA)		
		->get()->getResult();

		return $this->respond($response, 200);
	} 

	public function get_documento_vehiculo_vencido()
	{
		$Documento_vehiculo_m = new Documento_vehiculo_model();

		$documentos = $Documento_vehiculo_m->select('documento_vehiculo.*')
		->select('v.placa as vehiculo')
		->select('td.nombre as tipo_documento')
		->join('vehiculo v', 'v.id = documento_vehiculo.id_vehiculo')
		->join('tipo_documento td', 'td.id = documento_vehiculo.id_tipo_documento')
		->where('fecha_vencimiento < date_add(NOW(), INTERVAL +15 DAY)')
		->where('documento_vehiculo.id_empresa', ID_EMPRESA)
		->findAll();

		$response = array();
		
		foreach ($documentos as $row) {

		
			/** CALCULAR DIAS RESNTANTE DE PAGO */

			$now = time(); // or your date as well
			$your_date = strtotime($row->fecha_vencimiento);
			$datediff =  $your_date - $now;

			$dias_restantes = round($datediff / (60 * 60 * 24));

			if($dias_restantes < 0)
			{
				$row->estado = 'VENCIDO';
			}
			else if($dias_restantes < 15)
			{
				$row->estado = 'POR VENCER';
			}
			else 
			{
				$row->estado = 'VIGENTE';
			}        

			/**** */
			$response[] = $row;
		}

		return $this->respond($response, 200);
	} 

	public function get_documento_personal_vencido()
	{
		$Documento_personal_m = new Documento_personal_model();

		$documentos = $Documento_personal_m->select('documento_personal.*')
		->select('p.nombre_completo as personal')
		->select('td.nombre as tipo_documento')
		->join('personal p', 'p.id = documento_personal.id_personal')
		->join('tipo_documento td', 'td.id = documento_personal.id_tipo_documento')
		->where('fecha_vencimiento < date_add(NOW(), INTERVAL +15 DAY)')
		->where('documento_personal.fl_no_caduca', 0)
		->where('documento_personal.id_empresa', ID_EMPRESA)
		->findAll();

		$response = array();
		
		foreach ($documentos as $row) {

		
			/** CALCULAR DIAS RESNTANTE DE PAGO */

			$now = time(); // or your date as well
			$your_date = strtotime($row->fecha_vencimiento);
			$datediff =  $your_date - $now;

			$dias_restantes = round($datediff / (60 * 60 * 24));

			if($dias_restantes < 0)
			{
				$row->estado = 'VENCIDO';
			}
			else if($dias_restantes < 15)
			{
				$row->estado = 'POR VENCER';
			}
			else 
			{
				$row->estado = 'VIGENTE';
			}        

			/**** */
			$response[] = $row;
		}

		return $this->respond($response, 200);
	} 


		
}
