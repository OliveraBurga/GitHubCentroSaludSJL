<?php namespace App\Controllers\Almacen;

use App\Controllers\BaseController;

use App\Models\Almacen\Articulo_model;
use App\Models\Image_model;

class Articulo extends BaseController
{
	public function __construct()
	{
		$this->Articulo_m = new Articulo_model();
	}

	public function get_select()
	{
		$data_request = $this->request->getGet();

		$response = $this->Articulo_m->select("id, nombre as text")
		->like('nombre', '%'.$data_request["buscar"])
		->where('id_empresa', ID_EMPRESA)
		->findAll(); 

		return $this->respond($response, 200);
	}

	public function get_unique($id_articulo)
	{
		$response = $this->Articulo_m->select('alm_articulo.*')
		->select('coalesce(um.nombre, "-") as unidad_medida')
		->join('alm_unidad_medida um', 'um.id = alm_articulo.id_unidad_medida', 'left')
		->find($id_articulo);

		return $this->respond($response, 200);
	}

	public function index()
	{		
		$data_request = $this->request->getGet();

		$response = $this->Articulo_m->select('alm_articulo.*')
		->select('coalesce(m.nombre, "") as marca')
		->select('coalesce(l.nombre, "") as linea')
		->select('coalesce(sl.nombre, "") as sublinea')
		->select('coalesce(um.nombre, "") as unidad_medida')
		->select('coalesce(ta.nombre, "") as tipo_articulo')

		->join('alm_marca m', 'm.id = alm_articulo.id_marca', 'left')
		->join('alm_linea l', 'l.id = alm_articulo.id_linea', 'left')
		->join('alm_sublinea sl', 'sl.id = alm_articulo.id_sublinea', 'left')
		->join('alm_unidad_medida um', 'um.id = alm_articulo.id_unidad_medida', 'left')
		->join('alm_tipo_articulo ta', 'ta.id = alm_articulo.id_tipo_articulo', 'left')

		->where('alm_articulo.id_empresa', ID_EMPRESA)
		->findAll();

        return $this->respond(['data' => $response], 200);
	}

	public function save()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		if (isset($data_request["id"])) {
			$this->Helper->validar_permisos('almacen-articulo', 'edit');
		}
		else
		{
			$this->Helper->validar_permisos('almacen-articulo', 'new');
		} 
 
		try {

			$db = \Config\Database::connect();
			$db->transStart();

			/** GUARDAR IMAGEN */
			$Imagen_upload = new Image_model();			
			$imagen = $Imagen_upload->guardar($this->request->getFile('imagen'), 'proveedor', (isset($data_request["imagen_anterior"])) ? $data_request["imagen_anterior"] : null);

			/** GUARDAR */
			$data = [
				'imagen'          	=> $imagen,
				'nombre'			=> trim($data_request["nombre"]),
				'id_tipo_articulo'	=> ($data_request["id_tipo_articulo"] != '') ? trim($data_request["id_tipo_articulo"]) : null,
				'id_linea'			=> ($data_request["id_linea"] != '') ? trim($data_request["id_linea"]) : null,
				'id_sublinea'		=> ($data_request["id_sublinea"] != '') ? trim($data_request["id_sublinea"]) : null,
				'descripcion'		=> trim($data_request["descripcion"]),
				'id_unidad_medida'	=> trim($data_request["id_unidad_medida"]),
				'id_marca'			=> ($data_request["id_marca"] != '') ? trim($data_request["id_marca"]) : null,
				'cantidad_minimo'	=> trim($data_request["cantidad_minimo"]),
				'observacion'		=> trim($data_request["observacion"]),
				'codigo_barra'		=> trim($data_request["codigo_barra"]),
			];

			if(isset($data_request["id"]))
			{
				$data["id"] = $data_request["id"];
			}
			else
			{
				$data["fecha_sistema"] = date("Y-m-d H:i:s");
				$data["id_empresa"] = ID_EMPRESA;
				$data["id_membresia"] = ID_MEMBRESIA;
				$data["id_usuario"] = ID_USUARIO;
				$data["fl_estado"] = 1;
				$data["cantidad"] = 0;
				$data["costo"] = 0;
			}

			$this->Articulo_m->save($data);

			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'ALMACÉN',
				'menu'			=> 'ARTÍCULO',
				'accion'		=> (isset($data_request["id"])) ? 'EDITAR' : 'NUEVO',
				'descripcion'	=> trim($data_request["nombre"])
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
			
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Guardado Correctamente'], 200);

		} catch (\Exception $e)
		{
		  return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
	

	public function delete()
	{
		$data_request = $this->request->getPost();

		/* VALIDAR PERMISO */
		$this->Helper->validar_permisos('almacen-articulo', 'delete');

		try {

			$db = \Config\Database::connect();
			$db->transStart();

			$articulo = $this->Articulo_m->find($data_request["id"]);

			$this->Articulo_m->where('id', $data_request["id"])
			->delete();

			/** ELIMINAR IMAGEN */
			$Imagen_upload = new Image_model();
			$Imagen_upload->eliminar($articulo->imagen);
			
			/****************** SAVE CENTINELA *****************/
			$data_centinela = [
				'modulo'		=> 'ALMACÉN',
				'menu'			=> 'ARTÍCULO',
				'accion'		=> 'ELIMINAR',
				'descripcion'	=> $articulo->nombre
			];

			$this->Centinela_m->registrar($data_centinela);
			/*************************************************** */
            
			$db->transComplete();

			return $this->respond(['tipo' => 'success', 'mensaje' => 'Eliminado Correctamente'], 200);

		} catch (\Exception $e) {
			return $this->respond(['tipo' => 'danger', 'mensaje' => $this->Helper->mensaje_cath($e)], 400);
		}
	}
		
}
